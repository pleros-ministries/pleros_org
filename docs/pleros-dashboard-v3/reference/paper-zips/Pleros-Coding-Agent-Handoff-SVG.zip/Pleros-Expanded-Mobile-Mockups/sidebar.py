"""Open navigation state; profile access moves out of the compact home header."""
from core import *


def sidebar_open():
    d=Draw()
    d.base(left_clock=False)
    d.ic('bell',350,54,20,INK);d.circle(367,54,2.5,BLUE)
    # The dimmed underlay shows only the edge of the current blue learning card.
    # Keep its body text out of the drawer state so native editable imports do not
    # lift obscured background labels above the drawer.
    d.rect(20,218,350,228,BLUE,16)
    d.rect(40,386,310,48,'#FFFFFF',11)
    d.raw('<rect x="0" y="0" width="390" height="844" fill="#172B47" opacity=".22"/>')
    d.rect(0,0,330,844,'#FFFFFF')
    d.text(27,26,'9:41',13,INK,600)
    d.text(20,84,'Menu',24,INK,500)
    d.hit(270,54,'Close menu');d.ic('close',282,66,20,INK)
    d.raw('<g role="button" aria-label="Open profile and settings">')
    d.rect(20,112,290,72,'none',12)
    d.av(20,126,'TO','blue',36)
    d.text(68,140,'Tolu',15,INK,500)
    d.text(68,164,'Profile & settings',14,BLUE,500)
    d.ic('right',290,138,16,MUTED)
    d.raw('</g>')
    d.line(20,198,310,198)
    for y,label,icon,active in [(220,'You','grid',True),(280,'Community','people',False)]:
        d.raw(f'<g role="button" aria-label="{label}">')
        d.rect(20,y,290,48,'#E4EBFD' if active else '#FFFFFF',10)
        d.ic(icon,32,y+14,20,BLUE if active else MUTED)
        d.text(64,y+30,label,14,BLUE if active else INK,500 if active else 400)
        d.raw('</g>')
    d.line(20,352,310,352)
    d.text(20,390,'Your workspace',13,MUTED,500)
    for i,(label,icon) in enumerate([('My learning','book'),('My disciples','leaf'),('Saved contacts','people'),('Church oversight','building')]):
        y=410+i*56
        d.raw(f'<g role="button" aria-label="{label}">')
        d.rect(20,y,290,48,'none',10);d.ic(icon,32,y+14,20,MUTED)
        d.text(64,y+30,label,14,INK);d.ic('right',290,y+16,16,MUTED)
        d.raw('</g>')
    d.rect(135,832,120,4,'#1D2E48',3)
    return d.svg()


if __name__=='__main__':
    render_svg('Pleros-sidebar-open',sidebar_open())
