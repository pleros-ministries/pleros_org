from pathlib import Path
import runpy
from core import render_svg
from originals import lesson,report,oversight,disciple
p=Path(__file__).resolve().parent
for script in ['sidebar.py','preview.py','sogp.py','hierarchy.py','contacts.py']:
    runpy.run_path(str(p/script),run_name='__main__')
if (p/'church_setup.py').exists():runpy.run_path(str(p/'church_setup.py'),run_name='__main__')
for name,fn in [('lesson',lesson),('report',report),('oversight',oversight),('disciple',disciple)]:render_svg('Pleros-'+name,fn())
for script in ['adaptive_home.py','onboarding.py','tracklist_builder.py','ministry_forms.py','meeting_forms.py','meeting_selection.py','consolidation_support.py','consolidation_reviews.py','consolidation_invitations.py','consolidation_learning.py']:
    if (p/script).exists():runpy.run_path(str(p/script),run_name='__main__')
from core import board
from adaptive_home import home_start
from onboarding import choose_commitment,preview_thirty
board('Pleros-Start-SOGP-Board','Start with a pace you can keep.','A clear entry point, a daily commitment and a path preview.', [('You · Start SOGP',home_start()),('Choose your daily commitment',choose_commitment()),('30 min/day · Preview',preview_thirty())], 'SOGP / START YOUR JOURNEY')
from originals import you
board('Pleros-You-SOGP-States','Your learning starts here.','Start SOGP on You, then continue your selected learning path in the same place.', [('You · Before enrolment',home_start()),('SOGP · Choose your daily commitment',choose_commitment()),('You · Already enrolled',you())], 'YOU / START & CONTINUE')
from sidebar import sidebar_open
board('Pleros-Header-Sidebar-Board','One row. Your space to grow.','Centred You / Community tabs, notifications and profile access in the sidebar.', [('You · Start SOGP',home_start()),('You · Continue learning',you()),('Menu · Profile & settings',sidebar_open())], 'COMPACT HEADER / SIDEBAR')
from meeting_forms import prayer_attendee,prayer_led,teaching_attendee,teaching_led
from meeting_selection import selection,missing
board('Pleros-Meeting-Reporting-Board','Create it once. Then report your part.','The person who led creates the shared meeting before workers or disciples add their reports.', [('Teaching · Create meeting',teaching_led()),('Prayer · Create meeting',prayer_led()),('Choose an existing meeting',selection())], 'REPORTING / SHARED MEETINGS')
board('Pleros-Meeting-Joining-Board','One meeting. Your own attendance report.','Meeting details stay read-only. Record your attendance and the people you brought.', [('Teaching · Worker report',teaching_attendee()),('Prayer · Disciple report',prayer_attendee()),('Meeting not listed yet',missing())], 'REPORTING / JOIN A MEETING')
runpy.run_path(str(p/'package.py'),run_name='__main__')
