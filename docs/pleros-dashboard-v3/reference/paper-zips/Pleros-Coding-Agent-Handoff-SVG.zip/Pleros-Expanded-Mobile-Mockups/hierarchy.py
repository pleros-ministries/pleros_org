from core import PILL_STYLES, Draw, BLUE, INK, MUTED, LINE, SOFT, render_svg, board


def pill(d,x,y,label,w,style='blue'):
    token=PILL_STYLES[style];bg,fg=token['background'],token['text']
    d.rect(x,y,w,28,bg,8);d.text(x+w/2,y+19,label,12,fg,500,anchor='middle')


def scope(d,y,label='Lagos branch only'):
    d.ic('shield',16,y-14,18,BLUE);d.text(42,y,label,13,BLUE,400)


def field(d,y,label,value,right='lock'):
    d.text(16,y,label,14,INK,500);d.rect(16,y+12,358,48,'#fff',12,LINE)
    d.text(32,y+43,value,16,INK,400)
    if right:d.ic(right,339,y+28,18,MUTED)


def info(d,y,lines,icon='shield',style='blue'):
    bg,fg=(SOFT,MUTED) if style=='blue' else ('#FAF4E9','#937039')
    d.rect(16,y,358,len(lines)*20+32,bg,12);d.ic(icon,32,y+16,18,fg)
    for i,line in enumerate(lines):d.text(62,y+30+i*20,line,13,fg,400)


def button(d,x,y,w,label,icon='arrow',secondary=False,disabled=False):
    fill='#E9ECEF' if disabled else SOFT if secondary else BLUE
    color='#989DA5' if disabled else BLUE if secondary else '#fff'
    d.rect(x,y,w,44,fill,12);d.text(x+16,y+28,label,14,color,500)
    if icon:d.ic(icon,x+w-34,y+13,18,color)


def footer(d,label,sub=None,icon='check',disabled=False):
    d.rect(0,742 if sub else 758,390,76 if sub else 60,'#FFFFFF')
    d.line(16,742 if sub else 758,374,742 if sub else 758)
    if sub:d.text(195,763,sub,12,MUTED,400,anchor='middle')
    button(d,16,774,358,label,icon,disabled=disabled);d.bottom()


def checkbox(d,x,y,selected=False):
    d.rect(x,y,22,22,BLUE if selected else '#fff',6,BLUE if selected else LINE)
    if selected:d.ic('check',x+3,y+3,16,'#fff')


def pastor_hierarchy():
    d=Draw();d.root('community')
    d.text(16,159,'Church structure',24,INK,500)
    scope(d,186,'Pastor · Manage all branches')
    d.rect(16,210,358,105,SOFT,14)
    d.text(32,239,'Fullness of Christ Church',15,INK,500)
    for x,v,l in [(32,'3','Branches'),(151,'8','Units'),(270,'40','Workers')]:
        d.text(x,274,v,22,INK,500);d.text(x,299,l,13,MUTED)
    d.text(16,343,'Branches',15,INK,500);d.text(374,343,'Manage',14,BLUE,500,anchor='end')
    d.rect(16,359,358,245,'#fff',14,LINE)
    d.tile('building',32,375,'blue',36);d.text(80,389,'Lagos',14,INK,500)
    d.text(80,411,'Bayo Adeyemi · Branch pastor',13,MUTED);d.ic('down',340,385,18,MUTED)
    pill(d,32,427,'3 of 4 ready',112,'amber');d.text(158,446,'22 workers',13,MUTED)
    d.line(32,467,358,467)
    d.line(45,483,45,565,LINE,2);d.line(45,503,62,503,LINE,2);d.line(45,559,62,559,LINE,2)
    d.av(64,483,'RA','mint',36);d.text(112,497,'Hospitality',14,INK,500);d.text(112,518,'Ruth Akinola · 6 workers',13,MUTED)
    d.av(64,539,'NA','lilac',36);d.text(112,553,'Media',14,INK,500);d.text(112,574,'Nkechi Amadi · 4 workers',13,MUTED)
    for y,title,name,nums,col in [(616,'Ibadan','Miriam Bello','2 units · 10 workers','green'),(708,'Ife','Obinna Eze','2 units · 8 workers','lilac')]:
        d.rect(16,y,358,80,'#fff',12,LINE);d.tile('building',32,y+16,col,36)
        d.text(80,y+24,title,14,INK,500);d.text(80,y+45,name,13,MUTED);d.text(80,y+65,nums,13,MUTED);d.ic('right',340,y+29,18,MUTED)
    d.bottom();return d.svg()


def branch_workspace():
    d=Draw();d.back('My branches')
    d.text(16,124,'Branch workspace',24,INK,500)
    scope(d,151,'Branch pastor · 2 assigned branches')
    # Only assigned branches appear in this scoped selector.
    d.rect(16,171,358,48,'#F1F3F5',12)
    d.rect(20,175,173,40,'#fff',9,LINE)
    d.text(106,201,'Lagos',14,BLUE,500,anchor='middle')
    d.text(281,201,'Ibadan',14,MUTED,400,anchor='middle')
    d.rect(16,243,358,104,SOFT,14)
    d.text(32,271,'Weekend setup',15,INK,500);pill(d,239,253,'3 of 4 ready',119,'amber')
    d.text(32,302,'Children’s team needs a leader.',14,INK)
    d.rect(32,324,326,5,'#DEE4F0',3);d.rect(32,324,244,5,BLUE,3)
    d.text(16,378,'Lagos units',15,INK,500);d.text(374,378,'4 unassigned workers',13,MUTED,anchor='end')
    rows=[(394,'Hospitality','Ruth Akinola · 6 workers','RA','mint',True),(468,'Worship','Kunle Adebayo · 5 workers','KA','apricot',True),(542,'Media','Nkechi Amadi · 4 workers','NA','lilac',True),(616,'Children’s team','No leader · 3 workers','','blue',False)]
    for y,title,sub,initials,col,ready in rows:
        d.rect(16,y,358,62,'#fff',12,LINE)
        if initials:d.av(32,y+13,initials,col,36)
        else:d.tile('people',32,y+13,'blue',36)
        d.text(80,y+26,title,14,INK,500);d.text(80,y+47,sub,13,MUTED)
        d.ic('circlecheck' if ready else 'right',339,y+23,18,'#688269' if ready else BLUE)
    button(d,16,702,358,'Assign workers in Lagos','people',secondary=True)
    footer(d,'Appoint a unit leader','',icon='plus');return d.svg()


def edit_appointment():
    d=Draw();d.back('Unit appointment')
    d.text(16,126,'Appoint a unit leader',24,INK,500)
    scope(d,154,'Lagos branch only')
    d.rect(16,178,358,84,SOFT,14);d.tile('people',32,194,'blue',36)
    d.text(80,206,'Children’s team',15,INK,500);d.text(80,229,'3 workers · No leader yet',13,MUTED)
    d.text(16,298,'Choose unit leader',14,INK,500)
    d.rect(16,314,358,72,'#fff',12,BLUE);d.av(32,332,'AO','mint',36)
    d.text(80,343,'Ada Okafor',14,INK,500);d.text(80,365,'Lagos branch',13,MUTED);d.ic('down',340,341,18,BLUE)
    field(d,421,'Role','Unit leader')
    field(d,517,'Assigned scope','Children’s team · Lagos')
    d.text(16,614,'This role can view',15,INK,500)
    d.ic('check',18,633,18,'#688269');d.text(47,648,'Their unit and direct workers',14,INK)
    d.ic('check',18,669,18,'#688269');d.text(47,684,'Their own reporting line',14,INK)
    d.text(16,724,'Assignments stay with the branch pastor.',13,MUTED)
    footer(d,'Save appointment','Only Children’s team in Lagos');return d.svg()


def assign_workers():
    d=Draw();d.back('Assign workers')
    d.text(16,126,'Add to Media',24,INK,500);scope(d,154,'Lagos branch only')
    d.rect(16,178,358,92,SOFT,14);d.av(32,194,'NA','lilac',36)
    d.text(80,207,'Media team',15,INK,500);d.text(80,229,'Nkechi Amadi · Unit leader',13,MUTED);d.text(80,250,'4 workers currently assigned',13,MUTED)
    d.search(294,'Search Lagos workers')
    d.text(16,369,'Available workers',15,INK,500);pill(d,270,350,'2 selected',104)
    for y,name,init,col,chosen in [(394,'Maryam Ali','MA','apricot',True),(468,'Emeka Ibe','EI','mint',True),(542,'Rotimi Sanni','RS','blue',False),(616,'John Lawal','JL','lilac',False)]:
        d.rect(16,y,358,62,SOFT if chosen else '#fff',12,'#D6DDED' if chosen else LINE)
        d.av(32,y+13,init,col,36);d.text(80,y+26,name,14,INK,500);d.text(80,y+47,'Unassigned',13,MUTED);checkbox(d,336,y+20,chosen)
    d.text(16,714,'Media will have 6 workers.',14,MUTED)
    footer(d,'Assign 2 workers','Reporting to Nkechi Amadi · Lagos');return d.svg()


def unit_team():
    d=Draw();d.back('My unit')
    d.text(16,126,'Media team',24,INK,500);pill(d,270,105,'View only',104,'neutral')
    scope(d,154,'Unit leader · Media, Lagos')
    d.rect(16,178,358,108,SOFT,14);d.av(32,194,'NA','lilac',36)
    d.text(80,207,'Nkechi Amadi',14,INK,500);d.text(80,230,'Unit leader · Media',13,MUTED)
    d.line(32,243,358,243);d.text(32,270,'Reports to Bayo Adeyemi',14,INK)
    d.text(16,322,'Direct workers',15,INK,500);d.text(374,322,'6 workers',13,MUTED,anchor='end')
    people=[('Ebuka Eze','EE','blue'),('Qudus Bello','QB','mint'),('Amina Yusuf','AY','lilac'),('Tunde Balogun','TB','apricot'),('Maryam Ali','MA','apricot'),('Emeka Ibe','EI','mint')]
    for i,(name,init,col) in enumerate(people):
        y=346+i*62;d.av(16,y,init,col,36);d.text(64,y+14,name,14,INK,500);d.text(64,y+36,'Worker · Media',13,MUTED);d.ic('right',348,y+11,18,MUTED)
        if i<5:d.line(64,y+49,374,y+49)
    info(d,737,['Appointments and assignments are','managed by your branch pastor.'],icon='lock')
    d.bottom();return d.svg()


def worker_placement():
    d=Draw();d.back('My placement')
    d.av(16,114,'MA','apricot',36);d.text(64,130,'Maryam Ali',24,INK,500);d.text(64,156,'Worker',13,MUTED)
    pill(d,278,117,'View only',96,'neutral')
    d.rect(16,182,358,76,SOFT,14);d.ic('building',32,200,24,BLUE)
    d.text(72,211,'You serve in Media',15,INK,500);d.text(72,235,'Lagos branch',13,MUTED)
    d.text(16,295,'Your reporting line',15,INK,500)
    d.line(34,335,34,622,LINE,2)
    d.circle(34,342,18,SOFT);d.ic('building',24,332,20,BLUE)
    d.text(70,336,'Fullness of Christ Church',14,INK,500);d.text(70,359,'Tolu Olawale · Pastor',13,MUTED)
    for y,name,title,init,col in [(410,'Lagos branch','Bayo Adeyemi · Branch pastor','BA','blue'),(496,'Media team','Nkechi Amadi · Unit leader','NA','lilac')]:
        d.av(16,y,init,col,36);d.text(70,y+14,name,14,INK,500);d.text(70,y+37,title,13,MUTED)
    d.rect(16,582,358,76,SOFT,14,LINE);d.av(32,600,'MA','apricot',36)
    d.text(80,614,'Maryam Ali',14,INK,500);d.text(80,637,'Worker · Media',13,MUTED);pill(d,310,598,'You',48)
    info(d,698,['Need a placement change?','Speak with your branch pastor.'],icon='people')
    d.bottom();return d.svg()


SCREENS=[('Pleros-church-pastor',pastor_hierarchy),('Pleros-church-branch',branch_workspace),('Pleros-church-appointment',edit_appointment),('Pleros-church-allocation',assign_workers),('Pleros-church-unit',unit_team),('Pleros-church-worker',worker_placement)]

if __name__=='__main__':
    rendered={name:f() for name,f in SCREENS}
    for name,content in rendered.items():render_svg(name,content)
    board('Pleros-Church-Board-01','A church structure ready to serve.','Concept · All-branch oversight, assigned-branch switching and scoped appointments.',[
        ('Pastor · All branches',rendered['Pleros-church-pastor']),('Branch pastor · Assigned branches',rendered['Pleros-church-branch']),('Branch pastor · Appoint a leader',rendered['Pleros-church-appointment']),
    ],section='CHURCH LEADERSHIP')
    board('Pleros-Church-Board-02','Clear roles. Clear reporting.','Concept · Branch-only allocation and read-only views for unit leaders and workers.',[
        ('Branch pastor · Assign workers',rendered['Pleros-church-allocation']),('Unit leader · Direct workers',rendered['Pleros-church-unit']),('Worker · My placement',rendered['Pleros-church-worker']),
    ],section='CHURCH ROLE FLOWS')
