from core import *

# Member roots and detail views use the shared, neutral-white mobile system.
# Every screen is a single viewport; longer lists continue through explicit links.


def you():
 d=Draw(height=1000);d.root('you')
 d.text(20,182,'Good morning, Tolu',21,INK,500,-.4)
 d.text(20,238,'Continue learning',15,INK,500);d.text(370,238,'View plan',13,BLUE,500,anchor='end')
 d.rect(20,262,350,228,BLUE,16)
 d.text(40,292,'SOGP · 1 hr/day',13,'#D8E4FF')
 d.text(40,330,'The life of faith',24,'#FFFFFF',500,-.4)
 
 d.rect(40,380,310,4,'#537EDF',2);d.rect(40,380,64.1,4,'#DDE6F6',2)
 d.text(40,407,'12:24 elapsed',13,'#E1EAFF');d.text(350,407,'1:00:00 total',13,'#E1EAFF',anchor='end')
 d.btn(40,430,310,'Continue lesson','play',fill='#FFFFFF',color=BLUE)
 d.ic('book',20,519,20,MUTED);d.text(56,529,'Plan & weekly reviews',14,INK,500);d.text(56,551,'7 of 24 tracks complete',13,MUTED);d.ic('right',354,527,16,MUTED);d.hit(338,513,'Open your SOGP journey')
 d.line(20,579,370,579)
 d.text(20,623,'My reports',15,INK,500);d.text(370,623,'View day',13,BLUE,500,anchor='end')
 rows=[('book','Devotional','3 activities logged','Not confirmed','amber',120),('heart','Ministry','No activity declared','Nil declared','neutral',94),('people','Meetings','1 meeting recorded','Reported','green',84)]
 for i,(icon,title,sub,state,style,width) in enumerate(rows):
  y=647+i*72
  d.ic(icon,20,y+15,20,MUTED);d.text(56,y+25,title,14,INK,500);d.text(56,y+47,sub,13,MUTED);d.chip(370-width,y+8,state,style,width)
  if i<2:d.line(56,y+66,370,y+66)
 d.text(20,900,'My support',15,INK,500);d.av(20,924,'ED','mint',36);d.text(68,936,'Efe Daniels',14,INK,500);d.text(68,958,'Your discipler · Connected',13,MUTED);d.hit(326,919,'Message Efe');d.text(370,946,'Message',14,BLUE,500,anchor='end')
 d.bottom();return d.svg()


def community():
    d = Draw(height=1020)
    d.root('community')
    d.raw('<g transform="translate(0,16)">')
    d.text(16, 166, 'Growing together.', 24, INK, 500, spacing=-0.5)
    d.text(16, 192, 'Your people. Your shared journey.', 14, MUTED)
    d.raw('</g>')
    d.raw('<g transform="translate(0,36)">')
    d.rect(16, 216, 358, 72, SOFT, 12)
    d.tile('chat', 32, 234, 'blue', 36)
    d.text(80, 245, 'Messages', 15, INK, 500)
    d.text(80, 267, '2 unread conversations', 13, MUTED)
    d.circle(338, 252, 12, BLUE)
    d.text(338, 257, '2', 12, '#FFFFFF', 500, anchor='middle')

    d.raw('</g>')
    d.raw('<g transform="translate(0,46)">')
    d.text(16, 326, 'Needs a response', 15, INK, 500)
    d.text(374, 326, 'View all', 13, BLUE, 500, anchor='end')
    d.rect(16, 342, 358, 140, '#FFFFFF', 12, LINE)
    d.av(32, 358, 'AO', 'apricot', 36)
    d.text(80, 372, 'Amara Okafor', 15, INK, 500)
    d.text(80, 393, 'New private check-in', 14, MUTED)
    d.ic('arrow', 336, 367, 22, BLUE)
    d.text(32, 421, 'Your discipleship group · 20 min ago', 13, MUTED)
    d.line(32, 438, 358, 438, LINE)
    d.ic('lock', 32, 451, 16, MUTED)
    d.text(56, 464, 'Private between you and Amara', 13, MUTED)

    d.raw('</g>')
    d.raw('<g transform="translate(0,68)">')
    d.text(16, 520, 'People you support', 15, INK, 500)
    d.rect(16, 536, 358, 144, '#FFFFFF', 12, LINE)
    for i, (icon, style, title, sub) in enumerate([
        ('leaf', 'lilac', 'My disciples', '8 people · You lead'),
        ('building', 'blue', 'Church oversight', 'Lagos · Direct workers'),
    ]):
        y = 536 + i * 72
        d.tile(icon, 32, y + 18, style, 36)
        d.text(80, y + 29, title, 15, INK, 500)
        d.text(80, y + 51, sub, 13, MUTED)
        d.ic('right', 342, y + 27, 18, MUTED)
        if i == 0:
            d.line(32, y + 72, 358, y + 72, LINE)

    d.raw('</g>')
    d.raw('<g transform="translate(0,96)">')
    d.text(16, 718, 'My groups', 15, INK, 500)
    d.text(374, 718, 'See all', 13, BLUE, 500, anchor='end')
    d.tile('people', 16, 742, 'blue', 36)
    d.text(64, 755, 'Lagos community', 15, INK, 500)
    d.text(64, 778, 'Location community · Member', 13, MUTED)
    d.ic('right', 351, 751, 18, MUTED)
    d.line(16,800,374,800)
    d.tile('leaf',16,820,'lilac',36)
    d.text(64,835,'Tolu’s discipleship group',15,INK,500)
    d.text(64,858,'Discipleship group · You lead',13,MUTED)
    d.ic('right',351,831,18,MUTED)
    d.raw('</g>')
    d.bottom()
    return d.svg()


def lesson():
    d = Draw()
    d.back('SOGP')
    d.text(16, 121, 'Level 2 · Track 08 of 24', 13, MUTED)
    d.text(16, 159, 'The life of faith', 24, INK, 500, spacing=-0.5)
    d.text(16, 185, 'Learn to live by what God has said.', 14, MUTED)
    d.rect(16,209,358,171,'#FFFFFF',16,LINE)
    d.text(32,239,'TRADITIONAL TRACK',12,MUTED,500)
    d.text(32,284,'Track 08',24,INK,500)
    d.text(32,313,'The life of faith',15,INK,500)
    d.text(32,350,'1 hr/day · Audio teaching',13,MUTED)

    d.rect(16, 404, 358, 4, LINE, 2)
    d.rect(16, 404, 74, 4, BLUE, 2)
    d.circle(90, 406, 5, BLUE)
    d.text(16, 433, '12:24', 13, MUTED)
    d.text(374, 433, '1:00:00', 13, MUTED, anchor='end')
    d.text(39, 484, '1×', 14, INK, 500, anchor='middle')
    for x, icon, label in [(112,'rewind','Back 15 seconds'),(278,'forward','Forward 15 seconds')]:
        d.hit(x-22,455,label);d.ic(icon,x-12,465,24,MUTED)
        d.text(x,513,'15s',12,MUTED,anchor='middle')
    d.circle(195, 477, 28, BLUE)
    d.ic('play', 182, 464, 26, '#FFFFFF')
    d.ic('download', 340, 466, 22, MUTED)
    d.ic('circlecheck', 137, 527, 16, '#507255')
    d.text(161, 540, 'Position saved', 13, '#507255')

    for x, title, selected in [(16, 'Overview', True), (142, 'My notes', False), (270, 'Transcript', False)]:
        d.text(x, 582, title, 14, BLUE if selected else MUTED, 500 if selected else 400)
    d.line(16, 599, 374, 599, LINE)
    d.rect(16, 597, 71, 2, BLUE, 1)
    d.text(16, 633, 'Faith begins with the Word', 15, INK, 500)
    d.text(16, 659, 'Hear, trust and act on God’s Word', 14, MUTED)
    d.text(16, 681, 'in everyday life.', 14, MUTED)
    d.rect(16, 705, 358, 72, '#FFFFFF', 12, LINE)
    d.tile('edit', 32, 723, 'lilac', 36)
    d.text(80, 734, 'Your response & quiz', 15, INK, 500)
    d.text(80, 757, 'Continue after this lesson', 13, MUTED)
    d.ic('right', 342, 732, 18, MUTED)
    d.text(16, 807, 'All 24 tracks', 13, BLUE, 500)
    d.ic('arrow', 108, 794, 18, BLUE)
    d.bottom()
    return d.svg()


def report():
    d = Draw()
    d.back('My reports')
    d.text(16, 120, 'Selected day · Lagos time', 13, MUTED)
    d.text(16, 155, 'Tuesday, 13 October', 24, INK, 500, spacing=-0.5)
    d.rect(330, 125, 44, 44, '#FFFFFF', 10, LINE)
    d.ic('calendar', 342, 137, 20, MUTED)
    d.rect(16, 185, 358, 94, SOFT, 12)
    d.circle(49, 217, 18, 'none', LINE)
    d.raw('<path d="M49 199a18 18 0 1 1-17.6 21" fill="none" stroke="#2056D6" stroke-width="3" stroke-linecap="round"/>')
    d.text(49, 221, '2/3', 12, BLUE, 500, anchor='middle')
    d.text(81, 211, '2 of 3 categories reported', 15, INK, 500)
    d.text(81, 237, 'Nil: saved no-activity declaration.', 13, MUTED)
    d.text(81, 258, 'Missing: no report submitted.', 13, MUTED)

    d.rect(16, 295, 358, 317, '#FFFFFF', 12, LINE)
    d.tile('book', 32, 311, 'blue', 36)
    d.text(80, 325, 'Devotional', 15, INK, 500)
    d.chip(238, 311, 'Not confirmed', 'amber', 120)
    d.text(80, 353, '3 activities logged for today', 13, MUTED)
    d.line(32, 369, 358, 369, LINE)
    for i, (title, sub) in enumerate([
        ('Prayer Watch', '6 am session · 30 minutes'),
        ('Bible reading', 'Romans 8 · 15 minutes'),
        ('Podcast', 'Walking in love · 22 minutes'),
    ]):
        y = 383 + i * 48
        d.ic('circlecheck', 32, y - 2, 18, '#507255')
        d.text(62, y + 11, title, 14, INK, 500)
        d.text(62, y + 31, sub, 13, MUTED)
        d.ic('right', 342, y + 5, 16, MUTED)
    d.text(32, 539, 'Confirm this day’s activities.', 14, INK)
    d.btn(32, 552, 326, 'Confirm devotional report', 'check', BLUE, '#FFFFFF', 44)

    for y, icon, style, title, sub, state, state_style, width in [
        (624, 'heart', 'green', 'Ministry', 'No activity declared', 'Nil declared', 'neutral', 94),
        (706, 'people', 'lilac', 'Meetings', '1 meeting recorded', 'Reported', 'green', 84),
    ]:
        d.rect(16, y, 358, 70, '#FFFFFF', 12, LINE)
        d.tile(icon, 32, y + 17, style, 36)
        d.text(80, y + 27, title, 15, INK, 500)
        d.text(80, y + 49, sub, 13, MUTED)
        d.chip(358 - width, y + 13, state, state_style, width)
    d.text(195, 806, 'View report history →', 13, BLUE, 500, anchor='middle')
    d.bottom()
    return d.svg()


def oversight():
    d = Draw()
    d.back('Church oversight')
    d.rect(16, 112, 358, 100, SOFT, 12)
    d.tile('building', 32, 140, 'blue', 36)
    d.text(84, 137, 'Lagos branch', 13, MUTED)
    d.text(84, 162, 'Welcome team', 15, INK, 500)
    d.text(84, 187, '12 directly assigned workers', 13, MUTED)
    d.text(16, 253, 'Daily reports', 24, INK, 500, spacing=-0.5)
    d.rect(270, 223, 104, 44, '#FFFFFF', 10, LINE)
    d.text(286, 250, '13 Oct', 13, INK)
    d.ic('calendar', 340, 235, 20, MUTED)
    d.text(16, 313, '8', 28, INK, 500)
    d.text(37, 313, '/ 12', 15, MUTED)
    d.text(81, 297, 'All categories', 13, MUTED)
    d.text(81, 318, 'reported', 13, MUTED)
    d.line(200, 282, 200, 329, LINE)
    d.text(224, 313, '4', 28, INK, 500)
    d.text(261, 297, 'Need a', 13, MUTED)
    d.text(261, 318, 'report', 13, MUTED)
    d.rect(16, 355, 196, 44, '#EAF0FF', 10)
    d.text(32, 382, 'Needs a report · 4', 14, BLUE, 500)
    d.text(374, 382, 'View all 12', 13, BLUE, 500, anchor='end')

    for i, (initials, color, name, states, reminded) in enumerate([
        ('DE', 'blue', 'Dayo Eze', [('Missing', 'amber', 72), ('Nil', 'neutral', 40), ('Reported', 'green', 84)], True),
        ('NM', 'lilac', 'Nneka Musa', [('Reported', 'green', 84), ('Missing', 'amber', 72), ('Nil', 'neutral', 40)], False),
    ]):
        y = 415 + i * 182
        d.rect(16, y, 358, 170, '#FFFFFF', 12, LINE)
        d.av(32, y + 16, initials, color, 36)
        d.text(80, y + 39, name, 15, INK, 500)
        d.ic('right', 340, y + 25, 18, MUTED)
        for x, category, state in zip([32, 158, 274], ['Devotional', 'Ministry', 'Meetings'], states):
            label, style, width = state
            d.text(x, y + 76, category, 13, MUTED)
            d.chip(x, y + 89, label, style, width)
        if reminded:
            d.ic('circlecheck', 32, y + 133, 18, MUTED)
            d.text(58, y + 148, 'Reminder sent today', 13, MUTED)
        else:
            d.ic('bell', 32, y + 133, 18, BLUE)
            d.text(58, y + 148, 'Send reminder', 14, BLUE, 500)
    d.ic('shield', 21, 792, 16, MUTED)
    d.text(45, 805, 'Only reports in your assigned scope', 13, MUTED)
    d.bottom()
    return d.svg()


def disciple():
    d = Draw()
    d.back('My disciples')
    d.av(177, 112, 'AO', 'apricot', 36)
    d.text(195, 185, 'Amara Okafor', 24, INK, 500, spacing=-0.5, anchor='middle')
    d.text(195, 210, 'Tolu’s discipleship group', 13, MUTED, anchor='middle')
    d.chip(151, 226, 'Connected', 'green', 88)
    d.btn(16, 274, 172, 'Message Amara', 'chat', BLUE, '#FFFFFF', 44)
    d.btn(200, 274, 174, 'Log follow-up', 'plus', SOFT, INK, 44)

    d.text(16, 357, 'Overview', 14, BLUE, 500)
    d.text(144, 357, 'Check-ins', 14, MUTED)
    d.chip(220, 339, '1', 'blue', 24)
    d.text(300, 357, 'Reviews', 14, MUTED)
    d.line(16, 374, 374, 374, LINE)
    d.rect(16, 372, 71, 2, BLUE, 1)
    d.rect(16, 398, 358, 180, '#F5F1F8', 12, '#E6DEEC')
    d.tile('heart', 32, 414, 'lilac', 36)
    d.text(80, 428, 'New check-in', 15, INK, 500)
    d.text(80, 450, 'Today, 9:20 am', 13, MUTED)
    d.circle(349, 427, 3, BLUE)
    d.text(32, 482, 'Make space for a conversation.', 14, MUTED)
    d.text(32, 518, 'Open private check-in', 14, BLUE, 500)
    d.ic('arrow', 336, 503, 20, BLUE)
    d.line(32, 536, 358, 536, '#E6DEEC')
    d.ic('lock', 32, 550, 16, MUTED)
    d.text(56, 563, 'Private to you and Amara', 13, MUTED)

    d.text(16, 616, 'Learning progress', 15, INK, 500)
    d.rect(16, 632, 358, 119, '#FFFFFF', 12, LINE)
    d.tile('book', 32, 648, 'blue', 36)
    d.text(80, 661, 'SOGP · Level 2', 15, INK, 500)
    d.text(80, 683, '7 of 24 tracks complete', 13, MUTED)
    for i in range(24):
        d.rect(32 + i * 13.6, 700, 10.6, 5, BLUE if i < 7 else LINE, 2)
    d.text(32, 732, 'Last learning activity', 13, MUTED)
    d.text(358, 732, 'Today', 13, '#507255', anchor='end')
    d.text(16, 791, 'Follow-up history', 14, INK, 500)
    d.text(329, 791, '11 Oct', 13, MUTED, anchor='end')
    d.ic('right', 350, 777, 18, MUTED)
    d.bottom()
    return d.svg()
