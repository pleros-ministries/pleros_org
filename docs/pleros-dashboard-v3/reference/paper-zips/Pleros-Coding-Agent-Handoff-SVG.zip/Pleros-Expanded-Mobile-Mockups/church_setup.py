from core import Draw, BLUE, INK, MUTED, LINE, SOFT, render_svg, board
from hierarchy import pill, scope, field, info, button, footer


def step(d,y,n):
    labels=[('Branch',''),('Branch','pastor'),('Unit','leaders'),('Workers','')]
    for i,(line1,line2) in enumerate(labels,1):
        x=16+(i-1)*92
        if i<4:d.line(x+30,y+12,x+86,y+12,LINE,2)
        d.circle(x+14,y+12,12,BLUE if i<=n else '#F1F3F5')
        if i<n:d.ic('check',x+7,y+5,14,'#fff')
        else:d.text(x+14,y+16,str(i),12,'#fff' if i==n else MUTED,500,anchor='middle')
        d.text(x,y+44,line1,12,BLUE if i==n else MUTED,500 if i==n else 400)
        if line2:d.text(x,y+62,line2,12,BLUE if i==n else MUTED,500 if i==n else 400)


def create_branch():
    d=Draw();d.back('Church setup')
    d.text(16,126,'Create a branch',24,INK,500);scope(d,154,'Pastor · Manage all branches')
    step(d,182,1)
    d.rect(16,278,358,84,SOFT,14);d.tile('building',32,294,'blue',36)
    d.text(80,307,'Fullness of Christ Church',15,INK,500)
    d.text(80,333,'Add the branch name and location.',13,MUTED)
    field(d,398,'Branch name','Osogbo',right=None)
    field(d,490,'Location','Osun State',right=None)
    info(d,586,['Next: appoint a branch pastor,','then unit leaders and workers.'],icon='people')
    d.text(16,706,'Optional: bulk import',14,BLUE,500);pill(d,260,686,'Proposed',114,'neutral')
    footer(d,'Create branch','Step 1 of 4 · Next: branch pastor',icon='plus');return d.svg()


def appoint_branch_pastor():
    d=Draw();d.back('Church setup')
    d.text(16,126,'Appoint a branch pastor',24,INK,500)
    scope(d,154,'Pastor · Manage all branches');step(d,182,2)
    d.rect(16,278,358,74,SOFT,14);d.tile('building',32,294,'blue',36)
    d.text(80,307,'Osogbo',15,INK,500);d.text(80,330,'Osun State · New branch',13,MUTED)
    d.search(376,'Search eligible people')
    d.text(16,454,'Choose a church member',15,INK,500)
    for y,name,initials,col,chosen in [(470,'Lara Fagbemi','LF','mint',True),(544,'Michael Udo','MU','blue',False),(618,'Wale Eze','WE','apricot',False)]:
        d.rect(16,y,358,62,SOFT if chosen else '#fff',12,'#D6DDED' if chosen else LINE)
        d.av(32,y+13,initials,col,36);d.text(80,y+26,name,14,INK,500);d.text(80,y+47,'Church member',13,MUTED)
        d.circle(347,y+31,10,BLUE if chosen else '#fff',BLUE if chosen else LINE)
        if chosen:d.circle(347,y+31,3,'#fff')
    d.text(16,714,'Appointment scope: Osogbo only',14,INK)
    footer(d,'Appoint branch pastor','Step 2 of 4 · Next: unit leaders');return d.svg()


def review_hierarchy_import():
    d=Draw();d.back('Proposed bulk import')
    d.text(16,120,'Optional setup alternative',13,MUTED)
    d.text(16,151,'Review church import',24,INK,500)
    scope(d,179,'Pastor · All branches in this import')
    d.rect(16,203,358,112,SOFT,14)
    d.ic('download',32,219,20,BLUE);d.text(64,235,'church-structure.csv',14,INK,500)
    for x,v,l in [(32,'2','Branches'),(151,'5','Units'),(270,'24','Workers')]:
        d.text(x,274,v,22,INK,500);d.text(x,299,l,13,MUTED)
    d.text(16,351,'Validation checks',15,INK,500);pill(d,247,331,'1 issue to fix',127,'amber')
    checks=[(389,'No duplicate people',True),(429,'No reporting cycles',True),(469,'Branches are within your scope',True),(509,'1 worker is missing a unit',False)]
    for y,label,ok in checks:
        d.ic('circlecheck' if ok else 'people',17,y-16,20,'#688269' if ok else '#937039')
        d.text(49,y,label,14,INK)
        if y<509:d.line(49,y+16,374,y+16)
    d.rect(16,541,358,137,'#FAF4E9',14,'#E6D8BF')
    d.text(32,569,'Row 18 · Missing unit',12,'#937039',500)
    d.text(32,598,'Maryam Ali',14,INK,500);d.text(32,621,'Worker · Osogbo',13,MUTED)
    button(d,277,581,81,'Fix','right',secondary=True)
    d.text(32,654,'Choose a unit before saving.',14,'#937039')
    d.text(16,714,'No changes are saved until all rows are valid.',13,MUTED)
    footer(d,'Save church structure','Resolve 1 issue to continue',icon='lock',disabled=True);return d.svg()


SCREENS=[('Pleros-create-branch',create_branch),('Pleros-appoint-branch-pastor',appoint_branch_pastor),('Pleros-review-hierarchy-import',review_hierarchy_import)]

if __name__=='__main__':
    rendered={name:f() for name,f in SCREENS}
    for name,svg in rendered.items():render_svg(name,svg)
    board('Pleros-Church-Setup-Board','Build the church, branch by branch.','Four-step setup · Branch, branch pastor, unit leaders, workers. Bulk import is an optional proposed alternative.',[
        ('Pastor · Create a branch',rendered['Pleros-create-branch']),('Pastor · Appoint a branch pastor',rendered['Pleros-appoint-branch-pastor']),('Optional concept · Review bulk import',rendered['Pleros-review-hierarchy-import']),
    ],section='CHURCH SETUP CONCEPT')
