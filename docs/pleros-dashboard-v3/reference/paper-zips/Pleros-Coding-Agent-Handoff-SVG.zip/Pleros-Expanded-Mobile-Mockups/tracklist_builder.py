from core import *

# Four design-only screens for the editable 30-day SOGP podcast tracklist.
# Suggested app order, not a newly published YouTube playlist.
# Source: /workspace/shared/pleros-podcast-verified-catalog.json (2026-10-13).
# The 15-minute branch uses 30 slots / 1 episode a day; the 30-minute
# branch uses 60 slots / 2 episodes a day. Daily time is approximate.
HEIGHT = 1100
EPISODES = [
    (1, '15:33', 'https://www.youtube.com/watch?v=dEcREef63Y0'),
    (2, '14:13', 'https://www.youtube.com/watch?v=1SYZubaMsHw'),
    (3, '13:34', 'https://www.youtube.com/watch?v=-HaBww89bFQ'),
    (4, '14:11', 'https://www.youtube.com/watch?v=UjLNXnLf5kA'),
]


def _header(step, title, lines):
    d = Draw(height=HEIGHT)
    d.back('Build your tracklist')
    d.text(16, 126, f'YOUR 30-DAY PLAN · STEP {step} OF 3', 13, MUTED, 500)
    d.text(16, 166, title, 24, INK, 500, -.4)
    for i, line in enumerate(lines):
        d.text(16, 198 + 22 * i, line, 14, MUTED)
    return d


def _outline_button(d, y, label, icon='edit'):
    d.raw(f'<g role="button" aria-label="{label}" tabindex="0">')
    d.rect(16, y, 358, 44, '#FFFFFF', 11, LINE)
    d.ic(icon, 32, y + 12, 20, MUTED)
    d.text(64, y + 28, label, 14, INK, 500)
    d.ic('right', 338, y + 14, 16, MUTED)
    d.raw('</g>')


def _series(d, y, number, first, second, subtitle, divider=True):
    # Plain ordinal + selected state within one divided group, not icon tiles.
    d.text(42, y + 29, number, 13, MUTED, anchor='middle')
    d.text(64, y + 29, first, 14, INK, 500)
    d.text(64, y + 49, second, 14, INK, 500)
    d.text(64, y + 75, subtitle, 13, MUTED)
    d.ic('check', 338, y + 18, 20, BLUE)
    if divider:
        d.line(32, y + 92, 358, y + 92)


def _handle(d, y):
    # Canonical Lucide grip, centered in a 44 x 44 reorder hit target.
    d.raw('<g role="button" aria-label="Reorder episode" tabindex="0">')
    d.rect(20, y + 22, 44, 44, 'none')
    d.ic('grip-vertical', 32, y + 34, 20, MUTED)
    d.raw('</g>')


def _episode(d, y, episode, draggable=False):
    number, duration, url = episode
    if draggable:
        _handle(d, y)
    else:
        d.text(42, y + 29, f'{number:02}', 13, MUTED, anchor='middle')
    x = 64
    d.raw(f'<a xlink:href="{url}" aria-label="The Reality of God’s Purpose (Part {number})">')
    d.text(x, y + 29, 'The Reality of God’s', 14, INK, 500)
    d.text(x, y + 49, f'Purpose (Part {number})', 14, INK, 500)
    d.ic('headphones', x, y + 62, 16, MUTED)
    d.text(x + 28, y + 75, f'Podcast · {duration}', 13, MUTED)
    d.raw('</a>')


def _day(d, y, number, total, episodes, draggable=False):
    d.section(y, f'Day {number}')
    count = len(episodes)
    d.text(374, y, f'{count} episode{"s" if count != 1 else ""} · {total}', 13, MUTED, anchor='end')
    top = y + 24
    d.rect(16, top, 358, 96 * count, '#FFFFFF', 12, LINE)
    for i, episode in enumerate(episodes):
        _episode(d, top + 96 * i, episode, draggable)
        if i < count - 1:
            d.line(32, top + 96 * (i + 1), 358, top + 96 * (i + 1))


def _daily_aim(d, minutes, count):
    d.rect(16, 252, 358, 160, '#FFFFFF', 12, LINE)
    d.text(32, 280, 'YOUR DAILY AIM', 13, MUTED, 500)
    d.text(32, 318, f'{minutes} min/day', 24, INK, 500, -.4)
    d.text(32, 344, f'{count} podcast episode{"s" if count != 1 else ""} each day', 14, MUTED)
    d.line(32, 364, 358, 364)
    d.ic('calendar', 32, 380, 16, MUTED)
    d.text(60, 393, '30 days', 14, INK, 500)
    d.ic('headphones', 204, 380, 16, MUTED)
    d.text(232, 393, f'{count * 30} episodes', 14, INK, 500)


def _ready(d, y, slots):
    # The blue check communicates completion; no ornamental coloured tile.
    d.ic('circlecheck', 16, y + 1, 20, BLUE)
    d.text(48, y + 16, 'Your tracklist is ready', 15, INK, 500)
    d.text(48, y + 40, f'{slots}/{slots} episodes selected', 13, MUTED)
    d.text(48, y + 62, 'Ordered across all 30 days', 13, MUTED)


def _duration_note(d, y):
    d.ic('clock', 16, y + 1, 20, MUTED)
    d.text(48, y + 16, 'Your daily aim is approximate.', 13, MUTED)
    d.text(48, y + 38, 'Individual episode durations vary.', 13, MUTED)


def suggested_tracklist():
    d = _header(1, 'Make it your tracklist', [
        'Purpose is an optional starting point.',
        'Choose any episodes from the library.',
    ])
    d.rect(16, 252, 358, 92, '#FFFFFF', 12, LINE)
    d.text(32, 280, '30 min/day', 13, MUTED)
    d.text(32, 318, '30 days', 24, INK, 500, -.4)
    d.line(184, 296, 184, 323)
    d.text(204, 318, '60 episodes', 24, INK, 500, -.4)

    d.section(388, 'Suggested plan')
    d.text(374, 388, '60/60 selected', 13, BLUE, 500, anchor='end')
    d.rect(16, 412, 358, 276, '#FFFFFF', 12, LINE)
    _series(d, 412, '01', 'The Reality of God’s', 'Purpose', 'Parts 1–12 · Days 1–6')
    _series(d, 504, '02', 'The Pursuit of God’s', 'Purpose', 'Parts 1–12 · Days 7–12')
    _series(d, 596, '03', 'How to Fulfill God’s', 'Purpose', 'Parts 1–12 · Days 13–18', False)

    d.section(732, 'Then continue with')
    d.text(16, 764, 'The Mind of Man', 14, INK, 500)
    d.text(374, 764, '18 episodes', 13, MUTED, anchor='end')
    d.line(16, 780, 374, 780)
    d.text(16, 808, 'Faith Stand', 14, INK, 500)
    d.text(374, 808, '6 episodes', 13, MUTED, anchor='end')

    d.text(16, 854, 'Your starting plan is filled. Swap episodes', 13, MUTED)
    d.text(16, 876, 'from the library or change their order next.', 13, MUTED)
    _outline_button(d, 912, 'Edit episodes')
    d.bottom_cta('Use suggested plan', '2 episodes each day · You can make it yours', icon='arrow')
    return d.svg()


def reorder_tracklist():
    d = _header(2, 'Put each day in order', [
        'Your episodes, arranged across 30 days.',
        'Move any episode to make the plan yours.',
    ])
    d.rect(16, 252, 358, 76, '#FFFFFF', 12, LINE)
    d.ic('calendar', 32, 269, 20, MUTED)
    d.text(64, 281, '30 days · 60 episodes', 15, INK, 500)
    d.text(64, 305, '2 episodes each day · 30 min/day', 13, MUTED)

    d.text(16, 374, 'Drag the handles to reorder episodes.', 14, MUTED)
    _day(d, 420, 1, '29:46', EPISODES[:2], True)
    _day(d, 680, 2, '27:45', EPISODES[2:], True)

    _outline_button(d, 928, 'View days 3–30', icon='calendar')
    d.bottom_cta('Review tracklist', '60/60 episodes selected · All 30 days filled', icon='arrow')
    return d.svg()


def review_tracklist():
    d = _header(3, 'Your next 30 days, ready', [
        'A little time, set aside every day.',
        'Your chosen episodes, in your own order.',
    ])
    _daily_aim(d, 30, 2)
    _day(d, 456, 1, '29:46', EPISODES[:2])
    _ready(d, 704, 60)
    _outline_button(d, 812, 'Edit episodes or reorder')
    _duration_note(d, 888)
    d.bottom_cta('Start day 1', 'Your first two episodes · 29 min 46 sec', icon='play')
    return d.svg()


def review_tracklist_fifteen():
    d = _header(3, 'Your next 30 days, ready', [
        'A little time, set aside every day.',
        'Your chosen episodes, in your own order.',
    ])
    _daily_aim(d, 15, 1)
    _day(d, 456, 1, '15:33', EPISODES[:1])

    d.section(620, 'Your suggested order')
    d.text(16, 646, 'The Reality of God’s Purpose · Parts 1–12', 13, MUTED)
    d.text(16, 672, 'The Pursuit of God’s Purpose · Parts 1–12', 13, MUTED)
    d.text(16, 698, 'How to Fulfill God’s Purpose · Parts 1–6', 13, MUTED)

    _ready(d, 734, 30)
    _outline_button(d, 842, 'Edit episodes or reorder')
    _duration_note(d, 918)
    d.bottom_cta('Start day 1', 'Your first episode · 15 min 33 sec', icon='play')
    return d.svg()


SCREENS = {
    'tracklist-suggested': suggested_tracklist,
    'tracklist-reorder': reorder_tracklist,
    'tracklist-review': review_tracklist,
    'tracklist-review-15min': review_tracklist_fifteen,
}


if __name__ == '__main__':
    for name, fn in SCREENS.items():
        render_svg('Pleros-' + name, fn())
    board(
        'Pleros-Tracklist-Builder-Board',
        'A suggested start. A plan that is yours.',
        'Choose the Purpose-first suggestion, edit your episodes and arrange 30 days of listening.',
        [('Choose a suggested starting plan', suggested_tracklist()),
         ('Reorder your daily listening', reorder_tracklist()),
         ('Review your 30-day tracklist', review_tracklist())],
        'SOGP / TRACKLIST BUILDER'
    )
