"""Private contact capture and explicit group-invitation flows.

Fictional design fixtures only. Saving a contact, selecting an account,
assignment, sending an invitation, and accepted membership remain distinct.
"""
from core import Draw, BLUE, INK, MUTED, LINE, SOFT, render_svg, board

GROUP = 'Tolu’s discipleship group'


def _heading(d, title, subtitle):
    d.text(16,133,title,24,INK,500,-.4)
    d.text(16,160,subtitle,14,MUTED)


def _group(d,y):
    d.rect(16,y,358,84,'#FFFFFF',12,LINE)
    d.text(32,y+30,GROUP,14,INK,500)
    d.text(32,y+56,'Led by Tolu Adeyemi',13,MUTED)


def invite_existing_account():
    d=Draw(height=1000);d.back('Invite to a group')
    _heading(d,'Invite Daniel Okon','Review the person and group before sending.')
    d.chip(16,192,'In-app invitation','blue')
    d.section(250,'Saved contact')
    d.rect(16,268,358,96,'#FFFFFF',12,LINE)
    d.text(32,296,'Daniel Okon',14,INK,500)
    d.text(32,319,'+234 800 000 0103',14,MUTED)
    d.text(32,343,'Private to you · Follow up collection',13,MUTED)
    d.section(406,'Recipient account','Change')
    d.rect(16,424,358,80,'#FFFFFF',12,LINE)
    d.text(32,454,'Daniel Okon',14,INK,500)
    d.text(32,478,'daniel.okon@example.com',13,MUTED)
    d.text(16,542,'Confirm this is the right person.',14,INK)
    d.text(16,566,'Matching details don’t link accounts automatically.',13,MUTED)
    d.section(614,'Discipleship group')
    _group(d,632)
    d.note(748,['Daniel must accept before joining.','Your saved contact notes stay private.'])
    d.text(16,852,'The invitation will be sent in Pleros.',13,MUTED)
    d.bottom_cta('Send in-app invitation',icon='send')
    return d.svg()


def invitation_pending():
    d=Draw(height=920);d.back('Group invitation')
    _heading(d,'Waiting for Daniel','Invitation sent in Pleros.')
    d.chip(16,192,'Pending acceptance','amber')
    d.section(250,'Sent to')
    d.rect(16,268,358,100,'#FFFFFF',12,LINE)
    d.text(32,296,'Daniel Okon',14,INK,500)
    d.text(32,320,'daniel.okon@example.com',13,MUTED)
    d.text(32,345,'Today · 10:35 AM',13,MUTED)
    d.section(410,'Discipleship group')
    _group(d,428)
    d.section(560,'Not a member yet')
    d.text(16,591,'Daniel can accept or decline the invitation.',14,INK)
    d.text(16,614,'He’ll join the group only after accepting.',14,INK)
    d.section(670,'Your saved contact')
    d.text(16,701,'Daniel’s contact details and notes remain',14,INK)
    d.text(16,724,'private to you.',14,INK)
    d.text(16,763,'Contact collection: Follow up',13,MUTED)
    d.bottom_cta('View saved contact',icon='arrow')
    return d.svg()


def accept_group_invitation():
    d=Draw(height=944);d.back('Group invitation')
    _heading(d,'You’re invited','Tolu Adeyemi invited you to join.')
    d.chip(16,192,'Group invitation','blue')
    d.rect(16,250,358,112,'#FFFFFF',12,LINE)
    d.text(32,279,'Discipleship group',13,MUTED)
    d.text(32,309,GROUP,14,INK,500)
    d.text(32,337,'Led by Tolu Adeyemi',13,MUTED)
    d.section(410,'Before you join')
    d.text(16,442,'Accepting makes you a member of this group.',14,INK)
    d.text(16,465,'You can also decline this invitation.',14,INK)
    d.section(521,'Your learning continues')
    d.text(16,553,'Your SOGP follow-up assignment is separate',14,INK)
    d.text(16,576,'from joining this group.',14,INK)
    d.text(16,624,'You haven’t joined this group yet.',13,MUTED)
    d.line(16,776,374,776)
    d.btn(16,792,358,'Accept invitation','check')
    d.btn(16,856,358,'Decline',None,fill=SOFT,color=INK)
    d.bottom()
    return d.svg()


def share_whatsapp_invitation():
    d=Draw(height=1000);d.back('Share group invitation')
    _heading(d,'Invite Adaeze','Share a group invitation link.')
    d.chip(16,192,'No message sent','neutral')
    d.rect(16,250,358,96,'#FFFFFF',12,LINE)
    d.text(32,278,'Adaeze Bello',14,INK,500)
    d.text(32,301,'+234 800 000 0102',14,MUTED)
    d.text(32,324,'No Pleros account · Private saved contact',13,MUTED)
    d.section(390,'Discipleship group')
    _group(d,408)
    d.section(536,'Message preview')
    d.rect(16,554,358,190,SOFT,12)
    for y,line in [(584,'Hi Adaeze, join Tolu’s'),(607,'discipleship group on Pleros.'),(651,'Create an account, then accept'),(674,'the group invitation when you’re ready.')]:
        d.text(32,y,line,14,INK)
    d.text(32,716,'pleros.example/invite/demo',13,BLUE)
    d.text(16,782,'An account alone doesn’t make them a member.',13,MUTED)
    d.text(16,804,'They must accept the group invitation.',13,MUTED)
    d.text(16,826,'Your saved contact notes stay private.',13,MUTED)
    d.text(16,870,'Choose a chat and send it in WhatsApp.',13,MUTED)
    d.bottom_cta('Share on WhatsApp',icon='send')
    return d.svg()


SCREENS = [
    ('Pleros-invite-existing-account',invite_existing_account),
    ('Pleros-group-invitation-pending',invitation_pending),
    ('Pleros-group-invitation-accept',accept_group_invitation),
    ('Pleros-invite-whatsapp-link',share_whatsapp_invitation),
]

if __name__ == '__main__':
    for name,fn in SCREENS:render_svg(name,fn())
    board('Pleros-Group-Invitation-Board','An invitation. Then their choice.','Existing accounts receive an in-app invitation. Membership begins only after acceptance.',[
        ('Sender · Review invitation',invite_existing_account()),
        ('Sender · Pending acceptance',invitation_pending()),
        ('Recipient · Accept or decline',accept_group_invitation()),
    ],'CONTACTS / GROUP INVITATIONS')
    from contacts import add_contact
    board('Pleros-WhatsApp-Invitation-Board','Keep the contact. Share when ready.','Saving stays private. The sender chooses a WhatsApp chat and sends the group invitation link.',[
        ('Save · No automatic invitation',add_contact()),
        ('Share · WhatsApp preview',share_whatsapp_invitation()),
        ('Recipient · Acceptance required',accept_group_invitation()),
    ],'CONTACTS / WHATSAPP INVITATIONS')
