from core import *

# Source-verified podcast metadata: podcast-catalog.json.
# The user chooses a commitment, then edits a suggested 30-day tracklist.
# Daily podcast commitments are approximate; episode runtimes remain exact.
# Playback positions are illustrative and saved independently per episode.

REALITY = 'The Reality of God’s Purpose'
PART_ONE_URL = 'https://www.youtube.com/watch?v=dEcREef63Y0'
PART_TWO_URL = 'https://www.youtube.com/watch?v=1SYZubaMsHw'


def _header(title='Start SOGP', height=1040):
    d = Draw(height=height)
    d.back(title)
    return d


def _radio(d, x, y):
    d.circle(x, y, 10, '#FFFFFF', '#8B929B')


def _commitment_card(d, y, title, description, icon):
    # Retained for compatibility with the screen generator's existing helpers.
    # The commitment chooser below is the exact approved pilot implementation.
    d.raw('<g role="radio" aria-checked="false">')
    d.rect(16, y, 358, 80, '#FFFFFF', 12, LINE)
    d.text(32, y + 31, title, 15, INK, 500)
    d.text(32, y + 54, description, 13, MUTED)
    _radio(d, 348, y + 40)
    d.raw('</g>')


def _footer(d, label, hint=None, enabled=True, icon='arrow'):
    y = d.height - 116
    d.rect(0, y, 390, 90, CANVAS)
    d.line(16, y + 1, 374, y + 1)
    if hint:
        d.text(195, y + 26, hint, 13, MUTED, anchor='middle')
    if enabled:
        d.btn(16, y + 36, 358, label, icon, h=48)
    else:
        d.raw('<g role="button" aria-disabled="true">')
        d.btn(16, y + 36, 358, label, None, fill=SOFT, color='#8A9098', h=48)
        d.raw('</g>')
    d.bottom()


def _plan_summary(d, y, commitment, mapping, icon, podcast=True):
    d.rect(16, y, 358, 128, '#FFFFFF', 16, LINE)
    d.text(32, y + 30, 'Daily time aim' if podcast else 'Daily commitment', 13, MUTED)
    d.text(32, y + 66, commitment, 24, INK, 500, -.4)
    d.text(32, y + 102, mapping, 14, MUTED)


def _podcast_preview_row(d, y, part, duration):
    d.raw(f'<g data-source-url="{PART_ONE_URL if part == 1 else PART_TWO_URL}">')
    d.text(32, y + 22, f'{part:02}', 13, MUTED)
    d.text(64, y + 22, REALITY, 14, INK, 500)
    d.text(64, y + 48, f'Part {part} · Podcast · {duration}', 13, MUTED)
    d.raw('</g>')


def choose_commitment():
 d=Draw();d.back('Start SOGP');d.label(126,'YOUR DAILY COMMITMENT');d.text(16,167,'Make room to grow',24,INK,500,-.4);d.text(16,200,'How much time will you set aside each day?',14,MUTED)
 d.section(244,'Choose one option')
 for y,title,description in [(268,'1 hr/day','Traditional one-hour tracks'),(364,'30 min/day','2 podcast episodes/day'),(460,'15 min/day','1 podcast episode/day')]:
  d.raw('<g role="radio" aria-checked="false">');d.rect(16,y,358,80,'#FFFFFF',12,LINE);d.text(32,y+31,title,15,INK,500);d.text(32,y+54,description,13,MUTED);d.circle(348,y+40,10,'#FFFFFF','#8B929B');d.raw('</g>')
 d.text(16,588,'Choose the time you can commit to.',14,MUTED)
 y=d.height-116;d.line(16,y+1,374,y+1);d.text(195,y+26,'Select one option to continue',13,MUTED,anchor='middle');d.raw('<g role="button" aria-disabled="true">');d.btn(16,y+36,358,'Continue',None,fill=SOFT,color='#8A9098',h=48);d.raw('</g>');d.bottom();return d.svg()


def preview_thirty():
    d = _header('Preview your plan', height=960)
    d.label(126, '30-MINUTE PATH')
    d.text(16, 167, 'Two episodes each day', 24, INK, 500, -.4)
    d.text(16, 200, 'Build your own 30-day podcast tracklist.', 14, MUTED)
    _plan_summary(d, 232, '30 min/day', '2 podcast episodes/day', 'headphones')
    d.section(404, 'Suggested first day')
    d.text(374, 404, '29:46 total', 13, MUTED, anchor='end')
    _podcast_preview_row(d, 420, 1, '15:33')
    d.line(64, 488, 374, 488)
    _podcast_preview_row(d, 504, 2, '14:13')
    d.line(16, 580, 374, 580)
    d.text(16, 624, 'Purpose is a suggested start', 15, INK, 500)
    d.text(16, 654, 'Use this suggestion or choose other episodes;', 14, MUTED)
    d.text(16, 678, 'edit and reorder all 60 episode slots.', 14, MUTED)
    d.text(16, 722, 'Individual podcast durations vary.', 13, MUTED)
    _footer(d, 'Build my 30-day tracklist', '30 days · 60 episode slots')
    return d.svg()


def _skip(d, x, y, forward=False):
    label = 'Forward 15 seconds' if forward else 'Rewind 15 seconds'
    d.raw(f'<g role="button" aria-label="{label}">')
    d.rect(x - 10, y - 10, 44, 56, 'none')
    d.ic('forward' if forward else 'rewind', x, y, 24, MUTED)
    d.text(x + 12, y + 42, '15s', 13, MUTED, anchor='middle')
    d.raw('</g>')


def _queue_item(d, y, part, duration, position, active=False):
    d.raw(f'<g data-source-url="{PART_ONE_URL if part == 1 else PART_TWO_URL}" data-playback-position="{position}" aria-current="{str(active).lower()}">')
    d.text(16, y + 24, f'{part:02}', 13, BLUE if active else MUTED, 500)
    d.text(48, y + 24, REALITY, 14, INK, 500)
    d.text(48, y + 50, f'Part {part} · {duration}', 13, MUTED)
    d.text(48, y + 78, f'Playing · Saved at {position}' if active else f'Saved at {position}', 13, BLUE if active else MUTED)
    d.hit(330, y + 36, f'{"Pause" if active else "Play"} episode {part}')
    d.ic('pause' if active else 'play', 340, y + 46, 24, BLUE)
    d.line(48, y + 100, 374, y + 100)
    d.raw('</g>')


def first_day():
    d = _header('Your SOGP plan', height=1100)
    d.label(126, 'DAY 01 OF 30 · YOUR TRACKLIST')
    d.text(16, 167, 'Your first day', 24, INK, 500, -.4)
    d.text(16, 200, '2 episodes · 30 min/day', 14, MUTED)
    d.text(16, 248, 'Today’s listening', 13, MUTED)
    d.text(374, 248, '04:20 / 29:46', 13, INK, 500, anchor='end')
    d.rect(16, 272, 358, 4, LINE, 2)
    d.rect(16, 272, 358 * 260 / 1786, 4, BLUE, 2)
    d.section(324, 'Now playing')
    d.text(374, 324, 'Episode 01 of 02', 13, MUTED, anchor='end')
    d.raw(f'<g data-source-url="{PART_ONE_URL}" data-playback-position="04:20">')
    d.rect(16, 340, 358, 316, '#FFFFFF', 16, LINE)
    d.text(36, 372, 'Podcast · 15:33', 13, MUTED)
    d.text(36, 408, 'The Reality of', 24, INK, 500, -.4)
    d.text(36, 438, 'God’s Purpose', 24, INK, 500, -.4)
    d.text(36, 466, 'Part 1', 13, MUTED)
    d.rect(36, 492, 318, 4, LINE, 2)
    d.rect(36, 492, 318 * 260 / 933, 4, BLUE, 2)
    d.circle(36 + 318 * 260 / 933, 494, 5, BLUE)
    d.text(36, 524, '04:20', 13, MUTED)
    d.text(354, 524, '15:33', 13, MUTED, anchor='end')
    d.raw('<g role="button" aria-label="Playback speed, 1 times"><rect x="26" y="550" width="44" height="44" fill="none"/>')
    d.text(48, 578, '1×', 14, INK, 500, anchor='middle')
    d.raw('</g>')
    _skip(d, 101, 560)
    d.circle(195, 572, 26, BLUE)
    d.hit(173, 550, 'Pause episode')
    d.ic('pause', 183, 560, 24, '#FFFFFF')
    _skip(d, 265, 560, True)
    d.hit(320, 550, 'More playback options')
    d.ic('more', 332, 562, 20, MUTED)
    d.raw('</g>')
    d.section(704, 'Today’s episodes', 'View tracklist')
    _queue_item(d, 724, 1, '15:33', '04:20', active=True)
    _queue_item(d, 840, 2, '14:13', '00:00')
    d.bottom()
    return d.svg()


def preview_hour():
    d = _header('Preview your plan', height=960)
    d.label(126, 'ONE-HOUR PATH')
    d.text(16, 167, 'The traditional track', 24, INK, 500, -.4)
    d.text(16, 200, 'Set aside one hour for SOGP each day.', 14, MUTED)
    _plan_summary(d, 232, '1 hr/day', 'Traditional one-hour tracks', 'book', podcast=False)
    d.section(404, 'Your first day')
    d.text(374, 404, '1:00:00 total', 13, MUTED, anchor='end')
    d.text(16, 450, 'Track 01', 15, INK, 500)
    d.text(16, 478, 'Traditional track · 60 min', 13, MUTED)
    d.line(16, 510, 374, 510)
    d.text(16, 554, 'Your daily format', 15, INK, 500)
    d.text(16, 584, 'Follow the traditional SOGP tracks,', 14, MUTED)
    d.text(16, 608, 'with one hour set aside each day.', 14, MUTED)
    _footer(d, 'Confirm this plan', '1 hr/day · Traditional tracks', icon='check')
    return d.svg()


def preview_fifteen():
    d = _header('Preview your plan', height=960)
    d.label(126, '15-MINUTE PATH')
    d.text(16, 167, 'One episode each day', 24, INK, 500, -.4)
    d.text(16, 200, 'Build your own 30-day podcast tracklist.', 14, MUTED)
    _plan_summary(d, 232, '15 min/day', '1 podcast episode/day', 'headphones')
    d.section(404, 'Suggested first day')
    d.text(374, 404, '15:33 total', 13, MUTED, anchor='end')
    _podcast_preview_row(d, 420, 1, '15:33')
    d.line(16, 504, 374, 504)
    d.text(16, 548, 'Purpose is a suggested start', 15, INK, 500)
    d.text(16, 578, 'Use this suggestion or choose other episodes;', 14, MUTED)
    d.text(16, 602, 'edit and reorder all 30 episode slots.', 14, MUTED)
    d.text(16, 646, 'Individual podcast durations vary.', 13, MUTED)
    _footer(d, 'Build my 30-day tracklist', '30 days · 30 episode slots')
    return d.svg()


def plan_ready():
    d = _header('Review your plan', height=1040)
    d.label(126, 'YOUR SOGP PLAN')
    d.text(16, 167, 'Your plan is ready', 24, INK, 500, -.4)
    d.text(16, 200, 'Your 30-day tracklist is ready to begin.', 14, MUTED)
    _plan_summary(d, 232, '30 min/day', '2 podcast episodes/day', 'headphones')
    d.section(404, 'Your first day', 'Edit tracklist')
    _podcast_preview_row(d, 420, 1, '15:33')
    d.line(64, 488, 374, 488)
    _podcast_preview_row(d, 504, 2, '14:13')
    d.line(16, 580, 374, 580)
    d.text(16, 624, '30 days · 60 episodes', 15, INK, 500)
    d.text(16, 654, 'Your selection · 2 episodes each day', 13, MUTED)
    d.text(16, 710, 'Your follow-up person', 14, INK, 500)
    d.hit(330, 680, 'View your follow-up person')
    d.ic('right', 342, 694, 16, MUTED)
    _footer(d, 'Start day 1', 'Today: 29:46 · Podcast durations vary', icon='play')
    return d.svg()


SCREENS = {
    'onboarding-choice': choose_commitment,
    'onboarding-30min': preview_thirty,
    'onboarding-day-one': first_day,
    'onboarding-1hour': preview_hour,
    'onboarding-15min': preview_fifteen,
    'onboarding-ready': plan_ready,
}


if __name__ == '__main__':
    for name, fn in SCREENS.items():
        render_svg('Pleros-' + name, fn())
    board(
        'Pleros-Onboarding-Board-01',
        'A daily commitment. A plan that fits.',
        'Choose your time, build your own 30-day tracklist and listen to your selected episodes.',
        [('Choose a daily commitment', choose_commitment()),
         ('30 minutes · build your tracklist', preview_thirty()),
         ('Day one · personal playback queue', first_day())],
        'SOGP / ONBOARDING'
    )
    board(
        'Pleros-Onboarding-Board-02',
        'Three commitments. Your own starting point.',
        'Choose traditional tracks or build a personal 30-day podcast tracklist, with an optional Purpose-first suggestion.',
        [('1 hour · traditional tracks', preview_hour()),
         ('15 minutes · build your tracklist', preview_fifteen()),
         ('Review your tracklist · start day 1', plan_ready())],
        'SOGP / DAILY PLAN OPTIONS'
    )
