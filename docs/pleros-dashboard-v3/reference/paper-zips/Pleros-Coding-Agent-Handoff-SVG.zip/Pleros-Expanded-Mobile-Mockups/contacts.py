"""Pleros mobile saved contacts and proposed private contact collections."""
from core import PILL_STYLES, Draw, BLUE, INK, MUTED, LINE, SOFT, render_svg, board

G=16
W=358
PAPER='#FFFFFF'
PALE='#F3F6FD'


def _heading(d, title, sub, y=133):
    d.text(G,y,title,24,INK,500,spacing=-.4)
    d.text(G,y+27,sub,14,MUTED,400)


def _section(d,y,label,link=None):
    d.text(G,y,label,15,INK,500)
    if link:d.text(374,y,link,13,BLUE,500,anchor='end')


def _badge(d,x,y,label,kind='neutral',w=None):
    token=PILL_STYLES[kind];bg,fg=token['background'],token['text']
    w=w or 16+len(label)*6.7
    d.rect(x,y,w,26,bg,7)
    d.text(x+8,y+18,label,12,fg,500)
    return w


def _segment(d,y,left,right,selected=0):
    d.rect(G,y,W,44,'#F1F4FA',11)
    d.rect(20 if selected==0 else 195,y+4,175,36,PAPER,8)
    d.text(107,y+28,left,13,BLUE if selected==0 else MUTED,500 if selected==0 else 400,anchor='middle')
    d.text(282,y+28,right,13,BLUE if selected==1 else MUTED,500 if selected==1 else 400,anchor='middle')


def _field(d,y,label,value):
    d.text(G,y,label,13,INK,400)
    d.rect(G,y+12,W,44,PAPER,11,LINE)
    d.text(32,y+41,value,16,INK,400)


def _search(d,y,label):
    d.rect(G,y,W,44,'#F5F6FA',11)
    d.ic('search',32,y+13,18,MUTED)
    d.text(62,y+28,label,14,MUTED,400)


def _note(d,y,lines,icon='shield'):
    d.rect(G,y,W,32+20*len(lines),PALE,16)
    d.ic(icon,32,y+17,18,'#7590B8')
    for i,line in enumerate(lines):d.text(62,y+29+20*i,line,13,'#70829D',400)


def _cta(d,label,icon='check'):
    d.bottom_cta(label,icon=icon)


def _contact(d,y,name,initials,collection,status,color='blue',kind='neutral'):
    d.av(G,y+4,initials,color,36)
    d.text(64,y+19,name,14,INK,500)
    d.text(64,y+41,collection,13,MUTED,400)
    _badge(d,64,y+53,status,kind)
    d.ic('right',352,y+28,16,MUTED)
    d.line(64,y+94,374,y+94)


def _timeline(d,y,title,sub,icon='clock',active=False,last=False):
    d.circle(30,y+14,14,'#EAF1FF' if active else '#F1F4F9')
    d.ic(icon,22,y+6,16,BLUE if active else '#8A9DB4')
    if not last:d.line(30,y+32,30,y+60,'#E1E9F4',1.5)
    d.text(58,y+13,title,14,INK,500)
    d.text(58,y+35,sub,13,MUTED,400)


def contacts_groups():
    d=Draw();d.root('community')
    _heading(d,'My disciples','Saved contacts and private collections.',163)
    _segment(d,214,'Contacts · 8','Collections · 2',1)
    _section(d,294,'Contact collections','+ New')
    d.text(G,319,'Editable examples. Make them your own.',13,MUTED,400)
    for y,title,count,initials in [(343,'New contacts','4 saved contacts','NC'),(451,'Follow up','2 saved contacts','FU')]:
        d.rect(G,y,W,96,PAPER,16,LINE)
        d.av(32,y+16,initials,'blue',36)
        d.text(80,y+33,title,15,INK,500)
        d.text(80,y+56,count,13,MUTED,400)
        d.text(80,y+78,'Private contact collection',13,MUTED,400)
        d.ic('right',342,y+39,16,MUTED)
    d.rect(G,571,W,76,PALE,16)
    d.text(32,599,'Collections help you organise contacts.',14,INK,400)
    d.text(32,621,'They don’t enrol anyone in a group.',13,MUTED,400)
    d.ic('people',20,678,20,'#7F94B0')
    d.text(52,690,'2 contacts still to organise',14,INK,400)
    d.text(52,715,'View unfiled contacts',13,BLUE,500)
    _cta(d,'Add contact','plus')
    return d.svg()


def saved_contacts():
    d=Draw();d.back('Saved contacts')
    _heading(d,'People, kept close','8 contacts · 2 still to organise')
    _search(d,184,'Search contacts')
    _badge(d,16,248,'All 8','blue',52)
    _badge(d,76,248,'Unlinked 4','neutral',84)
    _badge(d,168,248,'Pending 2','amber',87)
    _badge(d,263,248,'Linked 2','green',76)
    _contact(d,294,'Adaeze Bello','AB','No collection yet','Unlinked contact','apricot')
    _contact(d,400,'Daniel Okon','DO','Follow up','Invitation pending','blue','amber')
    _contact(d,506,'Ruth Eze','RE','Follow up','Account linked','blue','green')
    _contact(d,612,'Samuel Musa','SM','New contacts','Unlinked contact','blue')
    d.text(G,739,'Inviting a contact is a separate step.',13,MUTED,400)
    _cta(d,'Add contact','plus')
    return d.svg()


def add_contact():
    d=Draw(height=1000);d.back('Add contact')
    _heading(d,'Save a private contact','No Pleros account needed.')
    def entry(y,label,value):
        d.text(16,y,label,13,INK,500)
        d.rect(16,y+12,358,44,PAPER,11,LINE)
        d.text(32,y+40,value,14,INK)
    entry(196,'Full name · required','Adaeze Bello')
    entry(284,'Phone number · required','+234 800 000 0102')
    entry(372,'Email · optional','adaeze@example.com')
    d.text(G,460,'Note · optional',13,INK,500)
    d.rect(G,472,W,116,PAPER,11,LINE)
    d.text(32,502,'Met at the community gathering.',14,INK)
    d.text(32,524,'Follow up about meeting next week.',14,INK)
    d.text(G,616,'Stored privately with this saved contact.',13,MUTED)
    d.rect(G,648,W,76,SOFT,12)
    d.text(32,676,'Choose a collection after saving',14,INK,500)
    d.text(32,699,'Private collections only organise contacts.',13,MUTED)
    d.note(756,['This contact is private to you.','Saving won’t create an account,','send an invite or join a group.'])
    _cta(d,'Save contact','check')
    return d.svg()


def contact_history():
    d=Draw();d.back('Contact details')
    d.av(G,118,'AB','apricot',36)
    d.text(64,137,'Adaeze Bello',24,INK,500,spacing=-.4)
    d.text(64,162,'+234 800 000 0102',14,MUTED,400)
    _badge(d,G,187,'Unlinked contact','neutral',121)
    d.rect(G,237,W,84,'#F5F7FB',16)
    d.text(32,262,'CONTACT COLLECTION',13,MUTED,400)
    d.text(32,293,'No collection yet',14,INK,500)
    d.text(358,293,'Move',13,BLUE,500,anchor='end')
    _section(d,357,'Note','Edit')
    d.rect(G,377,W,100,PAPER,16,LINE)
    d.text(32,404,'Met at the community gathering.',14,INK,400)
    d.text(32,426,'Follow up about meeting next week.',14,INK,400)
    d.text(32,459,'Stored with this saved contact.',13,MUTED,400)
    _section(d,513,'Activity history')
    d.text(G,540,'Today · 13 October',13,MUTED,400)
    _timeline(d,564,'Note added','10:24 AM · Added by you','edit',True)
    _timeline(d,632,'Contact saved','10:24 AM · Added by you','people',False,True)
    d.text(G,726,'Moving keeps notes and history together.',13,MUTED,400)
    _cta(d,'Move to collection','arrow')
    return d.svg()


def move_contact():
    d=Draw();d.back('Move contact')
    _heading(d,'Choose a collection','Organise this saved contact.')
    d.rect(G,184,W,80,'#F5F7FB',16)
    d.av(32,201,'AB','apricot',36)
    d.text(80,216,'Adaeze Bello',14,INK,500)
    d.text(80,241,'Unlinked · No collection yet',13,MUTED,400)
    _search(d,288,'Find a collection')
    d.text(G,366,'PRIVATE CONTACT COLLECTIONS',13,MUTED,400)
    for y,title,count,selected in [(388,'New contacts','4 saved contacts',True),(484,'Follow up','2 saved contacts',False)]:
        d.rect(G,y,W,84,'#F3F6FF' if selected else PAPER,16,BLUE if selected else LINE,1.25 if selected else 1)
        d.ic('people',32,y+27,22,'#6F8DBD')
        d.text(72,y+34,title,15,INK,500)
        d.text(72,y+58,count,13,MUTED,400)
        d.circle(342,y+42,10,BLUE if selected else PAPER,None if selected else '#C5D2E4')
        if selected:d.ic('check',335,y+35,14,'#fff')
    d.ic('plus',18,591,20,BLUE)
    d.text(50,608,'Create a collection',14,BLUE,500)
    _note(d,636,['Notes and history stay with this contact.','No invitation or message will be sent.'])
    _cta(d,'Move to New contacts','arrow')
    return d.svg()


def contact_moved():
    d=Draw();d.back('Contact details')
    d.rect(G,108,W,64,PALE,16)
    d.ic('circlecheck',32,127,22,BLUE)
    d.text(66,134,'Contact moved',14,INK,500)
    d.text(66,157,'Saved in New contacts',13,MUTED,400)
    d.av(G,196,'AB','apricot',36)
    d.text(64,215,'Adaeze Bello',24,INK,500,spacing=-.4)
    d.text(64,240,'+234 800 000 0102',14,MUTED,400)
    d.rect(G,264,W,80,'#F5F7FB',16)
    d.text(32,290,'CONTACT COLLECTION',13,MUTED,400)
    d.text(32,320,'New contacts',14,INK,500)
    d.text(358,320,'Change',13,BLUE,500,anchor='end')
    _badge(d,G,364,'Unlinked contact','neutral',121)
    d.text(G,414,'No invitation sent. No group enrolment.',13,MUTED,400)
    d.rect(G,438,W,64,PAPER,16,LINE)
    d.ic('send',32,459,20,BLUE)
    d.text(68,464,'Invite to Pleros',14,BLUE,500)
    d.text(68,488,'Send an invitation when you’re ready.',13,MUTED,400)
    d.ic('right',344,459,16,MUTED)
    _section(d,538,'Activity history')
    _timeline(d,562,'Moved to New contacts','10:26 AM · From no collection','people',True)
    _timeline(d,626,'Note added','10:24 AM · Added by you','edit')
    _timeline(d,690,'Contact saved','10:24 AM · Added by you','people',False,True)
    _cta(d,'Done','check')
    return d.svg()


SCREENS = [
    ('contacts_groups',contacts_groups),
    ('saved_contacts',saved_contacts),
    ('add_contact',add_contact),
    ('contact_history',contact_history),
    ('move_contact',move_contact),
    ('contact_moved',contact_moved),
]

if __name__=='__main__':
    for name,fn in SCREENS:render_svg(name,fn())
    board('contacts-save-board','Keep people at the heart of it','Proposed private contact collections · Editable example names and fictional counts',[
        ('Contacts & collections',contacts_groups()),('Saved contacts',saved_contacts()),('Save without an account',add_contact())],section='CONTACTS / SAVE')
    board('contacts-move-board','Every relationship keeps its story','Proposed private contact collections · Organising a contact does not enrol them in a group',[
        ('Contact details & history',contact_history()),('Move to a collection',move_contact()),('Moved, still unlinked',contact_moved())],section='CONTACTS / ORGANISE')
