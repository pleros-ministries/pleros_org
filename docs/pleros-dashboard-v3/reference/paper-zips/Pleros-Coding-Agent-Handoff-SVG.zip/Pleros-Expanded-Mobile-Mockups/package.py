from pathlib import Path
import zipfile,json
from html import escape
p=Path(__file__).resolve().parent
sections=[
('Refined roots & control centre',[('Pleros-you','You · Your day'),('Pleros-community','Community · Your people'),('Pleros-control-centre','SOGP coordinator · Control centre'),('Pleros-sidebar-open','Menu · Profile & settings')]),
('SOGP people & assignment',[('Pleros-enrollee-details','Enrollee details'),('Pleros-change-owner','Change follow-up owner'),('Pleros-my-enrollees','My enrollees')]),
('Referral journeys',[('Pleros-referral-code','Referral code · Assigned'),('Pleros-referral-link','Referral link · Choose'),('Pleros-reassignment-pending','Reassignment request · Pending')]),
('Church leadership',[('Pleros-church-pastor','Pastor · All branches'),('Pleros-church-branch','Branch pastor · Launch setup'),('Pleros-church-appointment','Branch pastor · Unit appointment')]),
('Church role flows',[('Pleros-church-allocation','Branch pastor · Assign workers'),('Pleros-church-unit','Unit leader · Direct workers'),('Pleros-church-worker','Worker · My placement')]),
('Save contacts',[('contacts_groups','Contacts & collections'),('saved_contacts','Saved contacts'),('add_contact','Add contact without an account')]),
('Organise contacts',[('contact_history','Contact details & history'),('move_contact','Move to a contact collection'),('contact_moved','Moved · Still unlinked')]),
('Retained detail screens',[('Pleros-lesson','SOGP · Audio lesson'),('Pleros-report','Personal daily reports'),('Pleros-oversight','Direct-worker report oversight'),('Pleros-disciple','Private discipleship')])]
if (p/'church_setup.py').exists():sections.insert(5,('Populate the church',[('Pleros-create-branch','Pastor · Create branch'),('Pleros-appoint-branch-pastor','Pastor · Appoint branch pastor'),('Pleros-review-hierarchy-import','Pastor · Review hierarchy import')]))
if (p/'onboarding.py').exists():
 sections.extend([
  ('Start SOGP', [('Pleros-home-start-sogp','You · Start SOGP'),('Pleros-onboarding-choice','Choose your daily commitment'),('Pleros-onboarding-30min','30 min/day · Build your tracklist')]),
  ('Daily plan options', [('Pleros-onboarding-1hour','1 hr/day · Traditional tracks'),('Pleros-onboarding-15min','15 min/day · One episode'),('Pleros-onboarding-ready','Your plan · Ready to start')]),
  ('Adaptive home & player', [('Pleros-home-1hour','1 hr/day · Resume a traditional track'),('Pleros-home-30min','30 min/day · Two-episode queue'),('Pleros-home-15min','15 min/day · Resume one episode'),('Pleros-onboarding-day-one','Day one · Selected podcast playback')])
 ])
if (p/'tracklist_builder.py').exists():
 sections.append(('Build your 30-day tracklist',[('Pleros-tracklist-suggested','Purpose-first suggested plan'),('Pleros-tracklist-reorder','Arrange your daily listening'),('Pleros-tracklist-review','30 min/day · Review 60 episodes'),('Pleros-tracklist-review-15min','15 min/day · Review 30 episodes')]))
if (p/'ministry_forms.py').exists():
 sections.append(('Ministry reporting',[('Pleros-report-ministry-evangelism','Evangelism · Unified form'),('Pleros-report-ministry-discipleship','Discipleship · Unified form'),('Pleros-report-inline-add-contact','Add contact inline'),('Pleros-report-ministry-outcomes','Optional ministry outcomes')]))
if (p/'meeting_forms.py').exists():
 sections.append(('Meeting reporting',[('Pleros-report-teaching-led','Teaching · Create the shared meeting'),('Pleros-report-prayer-led','Prayer · Create the shared meeting'),('Pleros-report-meeting-select','Choose an existing meeting'),('Pleros-report-teaching-attendee','Worker · Report attendance'),('Pleros-report-prayer-attendee','Disciple · Report attendance'),('Pleros-report-meeting-missing','Meeting not listed yet')]))
if (p/'Pleros-my-sogp.svg').exists():
 sections.append(('My SOGP & follow-up',[('Pleros-my-sogp','My SOGP · Plan and weekly reviews'),('Pleros-share-referral','Every enrollee · Share referral'),('Pleros-request-reassignment','Request a different follow-up person')]))
if (p/'Pleros-review-learner-list.svg').exists():
 sections.append(('Weekly group reviews',[('Pleros-review-learner-list','Learner · Weekly group reviews'),('Pleros-review-discipler-schedule','Discipler · Schedule a review'),('Pleros-review-leader-attendance','Session leader · Confirm attendance')]))
 sections.append(('Review make-up & certification',[('Pleros-review-missed-makeup','Learner · Make up a missed review'),('Pleros-review-certification','Learner · Certification readiness')]))
if (p/'Pleros-invite-existing-account.svg').exists():
 sections.append(('Group invitations',[('Pleros-invite-existing-account','Existing account · Invite in-app'),('Pleros-group-invitation-pending','Invitation sent · Acceptance pending'),('Pleros-group-invitation-accept','Recipient · Accept or decline'),('Pleros-invite-whatsapp-link','No account · Share WhatsApp link')]))
if (p/'Pleros-learning-podcast-library.svg').exists():
 sections.append(('Edit your learning plan',[('Pleros-learning-podcast-library','Podcast library · Choose episodes'),('Pleros-learning-edit-full-plan','Edit remaining episodes across the plan'),('Pleros-learning-switch-one-episode','Switch pace · Regroup remaining episodes')]))
 sections.append(('Learning history & episode completion',[('Pleros-learning-switch-traditional','Switch path · Preserve distinct histories'),('Pleros-learning-listen-two-episodes','Mark each episode listened'),('Pleros-learning-optional-question','Ask a question · Optional')]))
count=sum(len(ss) for _,ss in sections)
head='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pleros · Mobile mockups</title><style>@font-face{font-family:BeVietnam;src:url(assets/BeVietnamPro-Regular.ttf);font-weight:400}@font-face{font-family:BeVietnam;src:url(assets/BeVietnamPro-Medium.ttf);font-weight:500}@font-face{font-family:BeVietnam;src:url(assets/BeVietnamPro-SemiBold.ttf);font-weight:600}@font-face{font-family:BeVietnam;src:url(assets/BeVietnamPro-Bold.ttf);font-weight:700}*{box-sizing:border-box}body{margin:0;background:#FFFFFF;color:#252B33;font-family:BeVietnam,Arial,sans-serif}header{max-width:1400px;margin:auto;padding:42px 32px 28px}h1{font-size:32px;letter-spacing:-1px;margin:10px 0}header img{width:85px}p{color:#63676D;font-size:13px;line-height:1.6}nav{display:flex;flex-wrap:wrap;gap:8px;margin-top:24px}nav a{font-size:11px;border:1px solid #dbe5f2;padding:8px 10px;border-radius:6px;text-decoration:none;color:#34557f}section{max-width:1400px;margin:auto;padding:12px 32px 30px}h2{font-size:17px;letter-spacing:-.2px;margin:28px 0 18px}.screens{display:flex;flex-wrap:wrap;gap:36px}figure{margin:0;width:min(390px,100%)}figure img{display:block;width:100%;border-radius:31px;border:1px solid #d8e1ed;background:white}figcaption{font-size:12px;padding:12px 2px;display:flex;justify-content:space-between;gap:8px}figcaption a{color:#2056d6}footer{max-width:1400px;margin:auto;padding:0 32px 40px;font-size:12px;color:#63676D}</style></head><body><header><img src="assets/pleros-logo-dark.png" alt="Pleros"><h1>More room to lead. More ways to care.</h1>'''
html=head+f'<p>{count} mobile screens · Concept visuals · Fictional people and demo data<br>Open a PNG at full resolution, or edit the matching SVG. These are static screens.</p><nav>'
for i,(title,ss) in enumerate(sections):html+=f'<a href="#section-{i}">{escape(title)}</a>'
html+='</nav></header>'
for i,(title,ss) in enumerate(sections):
 html+=f'<section id="section-{i}"><h2>{escape(title)}</h2><div class="screens">'
 for name,label in ss:html+=f'<figure><a href="{name}.png"><img src="{name}.svg" alt="{escape(label)}" loading="lazy"></a><figcaption><span>{escape(label)}</span><span><a href="{name}.png">PNG</a> · <a href="{name}.svg">SVG</a></span></figcaption></figure>'
 html+='</div></section>'
html+='<footer>Actual Pleros logo sourced from the Pleros repository. Contact collections and bulk import are proposed interactions; group membership remains a separate step.</footer></body></html>'
(p/'index.html').write_text(html)
(p/'screen-index.json').write_text(json.dumps(sections,indent=2))
readme=f'''PLEROS — EXPANDED MOBILE MOCKUPS
13 October 2026

Start with Pleros-Design-Implementation-Contract-2026-10-13.md for implementation rules and design acceptance checks.
Use Pleros-Current-Truth-Addendum-2026-10-13.md for settled product decisions.
Open index.html for the visual gallery.
{count} individual mobile screens. Root and new onboarding content can scroll beyond an 844px viewport. Board and phone exports show the full design content.
PNGs are exported at 2×. Phone screens are 390 CSS pixels wide; content heights vary. Boards contain full-content previews.
SVGs are editable. Python source and original logo/font assets are included.
paper_native.py is the optional SVG-to-native-HTML import converter (requires lxml), supplied for typography and import-reference context.

DESIGN CHANGES
- A single-row home header centres the text-only You / Community tabs between menu and notification controls. Profile access lives in the sidebar.
- Home headers omit the redundant logo; centred You / Community tabs remain the primary navigation. Actual Pleros branding is retained on presentation boards and in the asset pack.
- On You, a prominent blue Start SOGP card appears before enrolment; a blue Continue lesson card occupies the learning area once enrolled. White buttons restore the preferred earlier treatment without decorative flourishes.
- SOGP control centre, ownership, referrals and personal enrollee lists.
- Start SOGP → required daily commitment → path preview → tracklist builder (podcast paths) → first day.
- 1 hr/day = traditional one-hour tracks; 30 min/day = two podcasts/day; 15 min/day = one podcast/day.
- Editable 30-day podcast defaults optionally begin with the verified Purpose series: 60 episode slots for the 30-minute path, 30 slots for the 15-minute path.
- The You learning card and player depend on the selected path, with saved playback positions for each content item.
- Status pills use a stronger pastel adaptation of verified EOS web semantic colours. Amber marks pending states, green marks completed states, and neutral labels retain Nil/Not reported/Unlinked distinctions. The shared palette is in pill-palette.json.
- Canonical Lucide icons use a constant 1.75px visible stroke at 16/20/24px. Decorative sun, stars, orbital curves and lesson artwork are removed.
- Major section gap 32px, heading-to-content 12px, within-section gaps 12/16px; scrolling is allowed. Home uses 20px gutters/card padding. Primary actions are 48px high.
- Unified Evangelism/Discipleship entry and inline Add contact, with optional outcomes still proposed.
- Leader-first shared meetings: the person who led creates the record; workers and disciples select it and report personal attendance/people brought without editing meeting details. Teaching has Meeting subject; Prayer has venue/time and no subject. Total attendance is creator-only. Missing records show Meeting not listed yet.
- Pastor, branch pastor, unit leader and ordinary worker views.
- Saved contacts, proposed editable contact collections, and a move flow retaining history.

INTERACTION BOUNDARIES
- Code join: automatic assignment to the code owner, without the link-specific acceptance prompt.
- Link join: automatic assignment to the link owner, followed by Accept / Request someone else.
- Follow-up assignment and accepted group membership are separate.
- Pastor manages all branches. Branch pastors manage their assigned branches. Unit leaders view direct workers; they do not appoint leaders or assign workers. Workers see their own placement/reports.
- Church hierarchy does not grant access to private discipleship notes, check-ins or contact history.
- Name and phone are required for saved contacts; email is optional. Contacts are private initially. Saving/moving does not automatically send a message, create an account or accept group membership.
- Existing accounts receive in-app group invitations; non-account contacts can receive a WhatsApp invitation link. Membership requires explicit acceptance.
- Direct SOGP joins route to their geographical leader. Current follow-up continues while reassignment is pending.
- Weekly group reviews are required for both paths and certification. Discipler schedules; session leader confirms attendance. Make-up does not block learning. No certificate threshold is invented.
- Missed learning waits. Path switching preserves history; one/two podcast pace changes regroup remaining content. Traditional and podcast completion do not automatically transfer.
- Each podcast episode has its own listened mark; two-episode days require both. Questions are optional; no podcast quiz/reflection is required.
- See CONSOLIDATION-REVIEW.md for design boundaries and retained-product mapping.
- Contact collections are private organisational labels, separate from community and discipleship groups. Collection names are editable examples. Bulk import is an optional proposed alternative to four-step branch, branch-pastor, unit-leader and worker setup.

People, counts and contact details are synthetic examples. Branch and group labels are informed by repository fixtures; no live database was read. Fullness of Christ Church and Pleros are the product context. No live enrolments, assignments, contacts or permissions were changed.

BRAND SOURCE
Repository: pleros-ministries/pleros_org
Commit: 939482b3d5aa8ba4486f580ee92662c2fd5dfb09
Asset: public/site/sogp/pleros-logo-dark.png
https://github.com/pleros-ministries/pleros_org/blob/939482b3d5aa8ba4486f580ee92662c2fd5dfb09/public/site/sogp/pleros-logo-dark.png

RENDERING
Requires Python 3 and Inkscape. Run python3 render_all.py. Be Vietnam Pro font files are included. For design editing, open the SVGs directly in a vector editor.
'''
(p/'README.txt').write_text(readme)
zip_path=p.parent/'Pleros-Expanded-Mobile-Mockups.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,9) as z:
 for f in sorted(p.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc' and f.name!='fonts.conf' and 'paper-native' not in f.parts and 'saas-review' not in f.parts and 'premium-stage' not in f.parts and f.name!='saas_pilot.py' and (not f.name.startswith('paper_') or f.name=='paper_native.py'):z.write(f,'Pleros-Expanded-Mobile-Mockups/'+str(f.relative_to(p)))
print(zip_path,zip_path.stat().st_size)
