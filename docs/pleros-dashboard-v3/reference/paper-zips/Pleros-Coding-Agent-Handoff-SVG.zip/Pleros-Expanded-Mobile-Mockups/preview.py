from core import *
from originals import you, community
from sogp import control_centre
for name,fn in [('you',you),('community',community),('control-centre',control_centre)]:render_svg('Pleros-'+name,fn())
board('Pleros-Mobile-First-Look','A lighter home. More room to lead.','A compact header, centred text tabs and a dedicated SOGP control centre.', [('You · your day',you()),('Community · your people',community()),('SOGP coordinator · control centre',control_centre())], 'REFINED ROOTS + SOGP')
