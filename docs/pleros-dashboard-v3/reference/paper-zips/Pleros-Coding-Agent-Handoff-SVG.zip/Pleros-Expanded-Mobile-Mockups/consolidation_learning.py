"""Settled SOGP learning flows. Static, illustrative UI; no live mutation.

Catalog titles, durations, and source links come from podcast-catalog.json.
Playback, selections, and history are clearly illustrative state examples.
Completed work is immutable in the editor; only remaining content is regrouped.
For either 1→2 or 2→1 episodes/day, preserve completions and per-episode
playback positions; regroup the same remaining sequence at the new daily pace.
No remaining episodes are dropped, reset, or skipped to meet a date target.
"""
from core import *
import json

CATALOG = json.loads((p / 'podcast-catalog.json').read_text())
EPISODES = CATALOG['suggested60EpisodeDefault']
PASTEL = '#EFF4FE'
GREEN_BG = '#EDF2EB'
GREEN = '#52694D'


def _header(title, subtitle, lines, height):
    d = Draw(height=height)
    d.back(title)
    d.text(16, 126, subtitle, 13, MUTED, 500)
    for i, line in enumerate(lines):
        d.text(16, 164 + i * 30, line, 24, INK, 500, -.4)
    return d


def _body(d, y, lines, x=16, color=MUTED):
    for i, line in enumerate(lines):
        d.text(x, y + i * 22, line, 14, color)


def _pill(d, x, y, text, width, selected=False, green=False):
    token = PILL_STYLES['green' if green else ('blue' if selected else 'neutral')]
    bg, fg = token['background'], token['text']
    d.rect(x, y, width, 28, bg, 7)
    d.text(x + 10, y + 19, text, 12, fg, 500)


def _outline(d, y, text, icon=None, x=16, width=358):
    d.rect(x, y, width, 48, '#FFFFFF', 11, LINE)
    if icon:
        d.ic(icon, x + 16, y + 14, 20, MUTED)
    d.text(x + (48 if icon else 16), y + 30, text, 14, INK, 500)
    d.raw(f'<rect x="{x}" y="{y}" width="{width}" height="48" fill="none" role="button" aria-label="{escape(text)}"/>')


def _footer(d, text, subtitle, icon='check', disabled=False):
    y = d.height - 116
    d.rect(0, y, 390, 89, '#FFFFFF')
    d.line(16, y + 1, 374, y + 1)
    d.text(195, y + 22, subtitle, 13, MUTED, anchor='middle')
    d.btn(16, y + 36, 358, text, icon,
          fill=LINE if disabled else BLUE,
          color=MUTED if disabled else '#FFFFFF', h=48)
    if disabled:
        d.raw(f'<rect x="16" y="{y+36}" width="358" height="48" fill="none" role="button" aria-label="{escape(text)}" aria-disabled="true"/>')
    d.bottom()


def _info(d, y, lines, icon='shield'):
    h = 28 + len(lines) * 22
    d.rect(16, y, 358, h, PASTEL, 12)
    d.ic(icon, 32, y + 17, 20, BLUE)
    _body(d, y + 30, lines, 64)


def _episode_title(d, y, episode, x=32, size=14, max_chars=32):
    # Exact catalog title, line-wrapped only. No fabricated episode names.
    words = episode['title'].split()
    lines = []
    line = ''
    for word in words:
        candidate = (line + ' ' + word).strip()
        if len(candidate) > max_chars and line:
            lines.append(line)
            line = word
        else:
            line = candidate
    if line:
        lines.append(line)
    d.raw(f'<a xlink:href="{episode["url"]}" aria-label="{escape(episode["title"])}">')
    for i, line in enumerate(lines):
        d.text(x, y + i * 21, line, size, INK, 500)
    d.raw('</a>')
    return y + (len(lines) - 1) * 21


def _checkbox(d, x, y, checked):
    d.rect(x, y, 22, 22, BLUE if checked else '#FFFFFF', 6, BLUE if checked else LINE)
    if checked:
        d.ic('check', x + 3, y + 3, 16, '#FFFFFF')
    d.raw(f'<rect x="{x-11}" y="{y-11}" width="44" height="44" fill="none" role="checkbox" aria-checked="{str(checked).lower()}"/>')


def podcast_library():
    d = _header('Podcast library', 'BUILD YOUR PLAN', ['Choose your episodes'], 1248)
    _body(d, 198, ['Browse the library or use a suggested start.',
                   'You can choose any available episodes.'])
    d.search(252, 'Search titles or series')
    _pill(d, 16, 312, 'All episodes', 112, selected=True)
    _pill(d, 136, 312, 'Purpose', 88)
    _pill(d, 232, 312, 'Faith', 64)
    d.rect(16, 372, 358, 160, '#FFFFFF', 12, LINE)
    d.text(32, 401, 'Purpose-first suggestion', 15, INK, 500)
    d.text(32, 425, 'Optional starting order · You can edit it', 13, MUTED)
    _outline(d, 452, 'Use Purpose-first suggestion', 'plus', x=32, width=326)
    d.section(576, 'All podcast episodes')
    d.text(374, 576, 'Browse episodes', 13, MUTED, anchor='end')
    d.text(16, 606, '60 selected · 2 episodes a day · 30 days', 13, BLUE, 500)
    # Initial viewport uses the first four verified Purpose episodes. The list
    # continues through the catalog rather than presenting a fixed curated set.
    for i, episode in enumerate(EPISODES[:4]):
        top = 626 + i * 100
        _checkbox(d, 20, top + 23, True)
        end = _episode_title(d, top + 25, episode, x=64, max_chars=30)
        d.text(64, end + 26, f'Podcast · {episode["duration"]}', 13, MUTED)
        d.ic('play', 338, top + 23, 20, MUTED)
        d.hit(326, top + 11, 'Preview episode')
        if i < 3:
            d.line(64, top + 93, 374, top + 93)
    d.text(16, 1050, 'Keep scrolling to explore the library', 13, MUTED)
    d.text(16, 1080, 'Your current plan stays active until you save.', 13, MUTED)
    _footer(d, 'Review selected episodes', '60 selected · Full plan is editable', icon='arrow')
    return d.svg()


def _editable_episode(d, y, episode, detail, locked=False):
    d.rect(16, y, 358, 110, SOFT if locked else '#FFFFFF', 12, LINE)
    d.ic('lock' if locked else 'grip-vertical', 30, y + 28, 20, MUTED)
    if not locked:
        d.hit(18, y + 16, 'Drag to reorder remaining episode')
    end = _episode_title(d, y + 29, episode, x=64, max_chars=29)
    d.text(64, end + 28, detail, 13, GREEN if locked else MUTED)
    if not locked:
        d.ic('more', 338, y + 28, 20, MUTED)
        d.hit(326, y + 16, 'Move to any day or replace episode')


def edit_full_plan():
    d = _header('Edit full plan', 'PODCAST · 30 MIN/DAY', ['Make the plan yours'], 1500)
    _body(d, 198, ['Reorder or replace remaining episodes.',
                   'Completed episodes stay in your history.'])
    d.rect(16, 252, 358, 88, PASTEL, 12)
    d.text(32, 282, 'All 30 days · 60 episodes', 15, INK, 500)
    d.text(32, 310, '1 listened · 59 remaining', 13, MUTED)
    d.text(358, 310, 'Switch path', 13, BLUE, 500, anchor='end')
    d.raw('<rect x="264" y="284" width="94" height="44" fill="none" role="button" aria-label="Switch learning path or daily pace"/>')
    d.search(372, 'Find any episode in this plan')
    d.rect(16, 432, 358, 44, '#FFFFFF', 11, LINE)
    d.text(32, 460, 'Jump to day', 14, MUTED)
    d.text(326, 460, '1 of 30', 14, INK, 500, anchor='end')
    d.ic('down', 340, 446, 16, MUTED)
    d.section(520, 'Day 1')
    d.text(374, 520, '1 of 2 listened', 13, MUTED, anchor='end')
    _editable_episode(d, 544, EPISODES[0], '15:33 · Listened · Locked', True)
    _editable_episode(d, 666, EPISODES[1], '14:13 · Saved at 04:45')
    d.section(824, 'Day 2')
    d.text(374, 824, '2 episodes · 27:45', 13, MUTED, anchor='end')
    _editable_episode(d, 848, EPISODES[2], '13:34 · Not started')
    _editable_episode(d, 970, EPISODES[3], '14:11 · Not started')
    _outline(d, 1112, 'Continue to days 3–30', 'calendar')
    _body(d, 1194, ['Use any episode’s menu to move it to',
                    'another day or replace it from the library.'])
    d.ic('lock', 16, 1244, 20, MUTED)
    d.text(48, 1260, 'Completed listens cannot be moved or replaced.', 13, MUTED)
    d.text(16, 1304, 'Playback positions stay with their episodes.', 13, MUTED)
    _footer(d, 'Save plan changes', 'Your active path stays the same', icon='check')
    return d.svg()


def _preview_episode(d, y, label, episode, detail):
    d.text(32, y + 25, label, 13, BLUE, 500)
    end = _episode_title(d, y + 53, episode, x=32, max_chars=38)
    d.text(32, end + 25, detail, 13, MUTED)


def switch_to_one_episode():
    d = _header('Switch learning pace', 'PREVIEW BEFORE SWITCHING', ['A little more space'], 1436)
    _body(d, 198, ['Move from two episodes to one each day.',
                   'Only your remaining episodes are regrouped.'])
    d.rect(16, 252, 358, 112, '#FFFFFF', 12, LINE)
    d.text(32, 281, 'CURRENT', 13, MUTED, 500)
    d.text(218, 281, 'NEW', 13, MUTED, 500)
    d.text(32, 310, '30 min/day', 20, INK, 500)
    d.ic('arrow', 174, 294, 20, MUTED)
    d.text(218, 310, '15 min/day', 20, INK, 500)
    d.text(32, 338, '2 episodes', 13, MUTED)
    d.text(218, 338, '1 episode', 13, MUTED)
    _info(d, 396, ['1 listened episode stays completed.',
                   '59 remaining episodes keep their order.',
                   'All saved playback positions stay.'])
    d.section(538, 'Your remaining plan')
    d.text(16, 568, '59 learning days · One episode each day', 14, MUTED)
    d.rect(16, 592, 358, 390, '#FFFFFF', 12, LINE)
    _preview_episode(d, 604, 'NEXT LEARNING DAY', EPISODES[1], '14:13 · Resume at 04:45')
    d.line(32, 722, 358, 722)
    _preview_episode(d, 734, 'THEN', EPISODES[2], '13:34 · Not started')
    d.line(32, 852, 358, 852)
    _preview_episode(d, 864, 'AFTER THAT', EPISODES[3], '14:11 · Not started')
    _body(d, 1028, ['No episodes are dropped to fit 30 days.',
                    'Your remaining plan takes longer at this pace.'])
    d.ic('calendar', 16, 1082, 20, MUTED)
    _body(d, 1098, ['Missed days wait for you.',
                    'Nothing skips or advances by date.'], x=48)
    _outline(d, 1166, 'Keep my current pace', 'left')
    _footer(d, 'Switch to 1 episode a day', 'You can switch again at any time', icon='check')
    return d.svg()


def switch_traditional_history():
    d = _header('Switch learning path', 'YOUR LEARNING HISTORY', ['Pick up either path'], 1332)
    _body(d, 198, ['Traditional SOGP uses full teaching tracks.',
                   'Podcasts use shorter, individual episodes.'])
    d.rect(16, 252, 358, 178, '#FFFFFF', 12, LINE)
    d.ic('headphones', 32, 271, 20, MUTED)
    d.text(64, 288, 'Podcast plan', 15, INK, 500)
    _pill(d, 272, 268, 'Current', 86, selected=True)
    d.text(32, 326, '30 min/day · 2 episodes', 14, MUTED)
    d.text(32, 354, '1 episode listened · 59 remaining', 14, INK, 500)
    d.text(32, 384, 'The Reality of God’s Purpose (Part 2)', 13, MUTED)
    d.text(32, 406, 'Playback saved at 04:45 of 14:13', 13, MUTED)
    d.rect(16, 462, 358, 190, PASTEL, 12, '#D5E1F8')
    d.ic('book', 32, 481, 20, BLUE)
    d.text(64, 498, 'Traditional SOGP', 15, INK, 500)
    d.ic('check', 336, 481, 20, BLUE)
    d.text(32, 536, '1 hr/day · Full teaching tracks', 14, MUTED)
    d.text(32, 564, '2 tracks completed', 14, INK, 500)
    d.text(32, 594, 'Track 03 is ready to resume', 14, INK, 500)
    d.text(32, 622, 'Playback saved at 18:42', 13, MUTED)
    d.section(700, 'What happens when you switch')
    d.ic('shield', 16, 726, 20, MUTED)
    _body(d, 742, ['Both paths keep their own history,',
                   'completions and playback positions.'], 48)
    d.ic('book', 16, 794, 20, MUTED)
    _body(d, 810, ['Switching doesn’t transfer completion.',
                   'Podcast listens do not complete tracks.'], 48)
    d.ic('play', 16, 862, 20, MUTED)
    _body(d, 878, ['Resume your saved traditional track',
                   'immediately after switching.'], 48)
    _info(d, 942, ['Your podcast plan is kept for you.',
                   'Switch back whenever you’re ready.'])
    _outline(d, 1054, 'Stay on my podcast plan', 'left')
    _footer(d, 'Switch & resume Track 03', 'Your path changes only when you confirm', icon='play')
    return d.svg()


def _player(d, y, episode, elapsed, seconds, done_audio=False):
    d.rect(16, y, 358, 260, '#FFFFFF', 12, LINE)
    end = _episode_title(d, y + 30, episode, x=32, max_chars=38)
    d.text(32, end + 27, f'Podcast · {episode["duration"]}', 13, MUTED)
    d.text(358, end + 27, 'Not marked listened', 13, MUTED, anchor='end')
    py = y + 118
    d.rect(32, py, 326, 4, LINE, 2)
    d.rect(32, py, 326 * seconds / episode['durationSeconds'], 4, BLUE, 2)
    d.circle(32 + 326 * seconds / episode['durationSeconds'], py + 2, 4, BLUE)
    d.text(32, py + 28, elapsed, 13, MUTED)
    d.text(358, py + 28, episode['duration'], 13, MUTED, anchor='end')
    d.ic('play', 32, y + 166, 20, BLUE)
    d.hit(20, y + 154, 'Replay episode' if done_audio else 'Resume episode')
    d.text(68, y + 182, 'Replay episode' if done_audio else 'Resume from 04:45', 14, BLUE, 500)
    d.btn(32, y + 198, 326, 'Mark listened', 'check', h=48)


def listen_two_episodes():
    d = _header('Today’s listening', 'PODCAST · 30 MIN/DAY', ['Your two episodes'], 1236)
    _body(d, 198, ['Day 1 · 29 min 46 sec of listening'])
    d.rect(16, 238, 358, 88, PASTEL, 12)
    d.text(32, 268, '0 of 2 episodes marked listened', 15, INK, 500)
    d.text(32, 296, 'Mark both listened to complete this day.', 13, MUTED)
    _player(d, 358, EPISODES[0], '15:33', 933, done_audio=True)
    _player(d, 650, EPISODES[1], '04:45', 285)
    _outline(d, 942, 'Ask a question · Optional', 'chat')
    d.text(16, 1022, 'Questions aren’t required for completion.', 13, MUTED)
    d.ic('calendar', 16, 1050, 20, MUTED)
    _body(d, 1066, ['Missed days wait. Mark both episodes',
                    'listened to complete this day.'], 48)
    d.bottom()
    return d.svg()


def optional_episode_question():
    d = _header('Ask a question', 'OPTIONAL', ['What’s on your mind?'], 1020)
    _body(d, 198, ['Ask about this episode whenever you like.'])
    d.rect(16, 252, 358, 116, SOFT, 12)
    d.ic('headphones', 32, 273, 20, MUTED)
    _episode_title(d, 284, EPISODES[1], x=64, max_chars=29)
    d.text(64, 336, '14:13 · Playback saved at 04:45', 13, MUTED)
    d.text(16, 418, 'Your question', 14, INK, 500)
    d.rect(16, 434, 358, 184, '#FFFFFF', 11, LINE)
    d.text(32, 464, 'Write your question…', 16, MUTED)
    _info(d, 686, ['This is optional. Asking a question',
                   'doesn’t change your listening progress.'], icon='chat')
    _outline(d, 790, 'Back to listening', 'left')
    _footer(d, 'Send question', 'You can keep learning without asking', icon='send', disabled=True)
    return d.svg()


SCREENS = [
    ('Pleros-learning-podcast-library', podcast_library),
    ('Pleros-learning-edit-full-plan', edit_full_plan),
    ('Pleros-learning-switch-one-episode', switch_to_one_episode),
    ('Pleros-learning-switch-traditional', switch_traditional_history),
    ('Pleros-learning-listen-two-episodes', listen_two_episodes),
    ('Pleros-learning-optional-question', optional_episode_question),
]


def render_boards():
    board('Pleros-Learning-Plan-Consolidation-Board',
          'Choose the content. Keep your progress.',
          'A real podcast library, full-plan editing and a preview before regrouping remaining episodes.',
          [('Choose from the podcast library', podcast_library()),
           ('Edit remaining work across the plan', edit_full_plan()),
           ('Preview a change of daily pace', switch_to_one_episode())],
          'SOGP / LEARNING CONSOLIDATION')
    board('Pleros-Learning-Progress-Consolidation-Board',
          'Every listen has its own place.',
          'Switch paths with history intact; mark episodes individually; ask a question only if you want to.',
          [('Keep distinct histories when switching', switch_traditional_history()),
           ('Complete both episodes for the day', listen_two_episodes()),
           ('Optional question, independent of progress', optional_episode_question())],
          'SOGP / LEARNING CONSOLIDATION')


if __name__ == '__main__':
    for name, fn in SCREENS:
        render_svg(name, fn())
    render_boards()
