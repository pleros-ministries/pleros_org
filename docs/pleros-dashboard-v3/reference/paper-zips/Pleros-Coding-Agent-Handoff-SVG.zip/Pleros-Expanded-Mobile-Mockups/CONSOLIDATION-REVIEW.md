# Pleros consolidation mockups

13 October 2026. This set extends the approved mobile design with the settled learning, follow-up, contact and review flows. All people, submissions and schedules are illustrative. Screens describe product behaviour; they do not create live data or establish implementation completion.

## Learning
- New learners can start immediately. Welcome Pack completion and receiving an overseer are not learning gates. Existing learners retain their selected path and progress.
- Initial podcast plans contain 30 or 60 episode slots across 30 learning days. Purpose is an optional suggestion. The library, full-plan editor and remaining-work controls show actual alternatives.
- Missed work waits. Switching between one and two podcasts per day regroups remaining episodes and preserves completed history and per-episode playback positions. The preview illustrates two-to-one; the inverse uses the same rule. A switched remainder is not reset to another fixed 30-day plan.
- Traditional lessons and podcasts are different content. Switching retains each history; completion does not automatically transfer between them.
- Learners mark each episode listened. Both marks are required to complete a two-episode day. Podcasts have no required quiz or reflection. A learner can optionally ask a question; question routing remains an implementation detail.

## Weekly group reviews
- Weekly group reviews are required for both paths and for certification. The discipler schedules the review; the session leader confirms attendance on that session.
- Attendance controls show illustrative recorded choices. A new attendance sheet must begin unconfirmed. Unmarked people are not automatically classified as missed.
- Missed reviews can be made up while learning continues. The make-up picker is a proposed interaction for selecting an explicitly offered make-up for the missed review. Arbitrary attendance at another session does not automatically satisfy it.
- No certificate attendance count, percentage, equivalence or cross-path formula has been invented. Make-up evidence, attendance correction permissions and scheduling exception rules still require specification.

## Follow-up and referrals
- Every enrollee has a personal code and link. Code arrival assigns the code owner. Link arrival assigns the link owner, with acceptance or a request for someone else. Group acceptance is a separate choice.
- Direct joins route to a geographical leader. My SOGP shows that assignment and a dashboard reassignment request. Current follow-up continues until reassigned.
- Unavailable or unsuitable owners and geographic-routing exceptions still need explicit rules; the mockups do not invent a fallback.

## Contacts and group invitations
- Name and phone are required; email is optional. Both standalone and inline capture show this. Contacts are initially private.
- Saving or organising a contact creates no account, message, invitation or membership.
- Existing-account invitations are sent in-app after selecting the recipient. Matching details alone do not link accounts. Non-account invitations use an explicitly shared WhatsApp link. The recipient must accept to join.
- Private contact collections remain a proposed organisational feature, separate from accepted discipleship/community groups. Contact notes are not exposed by inviting someone.

## Reporting and retained destinations
The approved unified Evangelism/Discipleship flow and leader-first shared meetings are retained. Optional outcomes and extra details remain proposals rather than final metric specifications. Teaching has Meeting subject; Prayer has venue/time and no subject. Workers and disciples select an existing meeting and report personal attendance/people brought. Only the creator reports the meeting total. Missing records show Meeting not listed yet.

Existing profile/settings, notifications, sign-in/account recovery, Welcome Pack, community/messages, Ask Pleros, traditional assessments, report history/edit/Nil/undo and staff destinations are retained product capabilities. The current package maps their entry points or representative screens, but does not redraw every existing route or every loading, empty, error, access-denied and historical state. These require implementation mapping and regression checks; they must not be deleted merely because they are not newly pictured.

The native Paper file and SVG gallery are design-review artifacts. Screen-to-screen flow intent is described in flows.json; no production navigation, submissions, messaging, scheduling or enrolment is implemented here.
