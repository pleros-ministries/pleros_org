from lxml import etree as E
from pathlib import Path
import copy,html,json,re
P=Path(__file__).parent
OUT=P/'paper-native';OUT.mkdir(exist_ok=True)
TOKENS={'font':'Be Vietnam Pro','canvas':'#F5F4F0','ink':'#172B47','accent':'#2056D6','muted':'#73869F'}
if (P/'paper-tokens.json').exists():TOKENS.update(json.loads((P/'paper-tokens.json').read_text()))
NS='{http://www.w3.org/2000/svg}'
def tr(s):
 m=re.search(r'translate\(([^)]*)',s or '')
 if not m:return (0,0)
 a=[float(i) for i in re.split('[, ]+',m[1]) if i];return (a[0],a[1] if len(a)>1 else 0)
def convert(name,label):
 root=E.parse(str(P/(name+'.svg'))).getroot();family=root.get('font-family','Be Vietnam Pro,sans-serif');g=copy.deepcopy(root); width=float(root.get('width','390'));height=float(root.get('height','844'))
 for e in list(g.iter()):
  if E.QName(e).localname in ('text','image'): e.getparent().remove(e)
 g.set('style',f'position:absolute;left:0px;top:0px;width:{width:g}px;height:{height:g}px;')
 g.set('layer-name','Editable vector decoration')
 out=[f'<div layer-name="{html.escape(label)}" style="position:relative;width:{width:g}px;height:{height:g}px;background:#ffffff;overflow:hidden;font-family:{family};">',E.tostring(g,encoding='unicode')]
 def walk(e,dx=0,dy=0):
  tx,ty=tr(e.get('transform'));dx+=tx;dy+=ty
  tag=E.QName(e).localname
  if tag=='text':
   x=float(e.get('x','0'))+dx;y=float(e.get('y','0'))+dy;size=float(e.get('font-size','12'));s=''.join(e.itertext()); anchor=e.get('text-anchor','start')
   weight=e.get('font-weight','400');fill=e.get('fill','#172B47');spacing=e.get('letter-spacing','0');line_height={12:18,13:20,14:22,15:22,16:24,21:28,24:32}.get(size,round(size*1.4)); top=y-size*.864-(line_height-size)/2
   transform=';transform:translateX(-50%)' if anchor=='middle' else ';transform:translateX(-100%)' if anchor=='end' else ''
   out.append(f'<div layer-name="{html.escape(s[:70])}" style="position:absolute;left:{x}px;top:{top}px;font-family:{family};font-size:{size}px;font-weight:{weight};line-height:{line_height}px;letter-spacing:{spacing}px;white-space:nowrap;color:{fill}{transform};">{html.escape(s)}</div>')
  elif tag=='image':
   x=float(e.get('x','0'))+dx;y=float(e.get('y','0'))+dy
   src=e.get('{http://www.w3.org/1999/xlink}href') or e.get('href')
   out.append(f'<img layer-name="Pleros logo" src="{src}" style="position:absolute;left:{x}px;top:{y}px;width:{e.get("width")}px;height:{e.get("height")}px;object-fit:contain;"/>')
  else:
   for c in e:walk(c,dx,dy)
 walk(root);out.append('</div>');return ''.join(out)
manifest=json.loads((P/'screen-index.json').read_text())
for group,items in manifest:
 for name,label in items:(OUT/(name+'.html')).write_text(convert(name,label))
print('Created',len(list(OUT.glob('*.html'))),'native import files')


# Presentation frames for native Paper page imports.
notes={
'Refined roots & control centre':'Daily life starts in You. Community holds shared relationships. Coordinators get a focused SOGP control centre.',
'SOGP people & assignment':'Open an enrollee, review their follow-up owner, then confirm assignment or reassignment.',
'Referral journeys':'A referral code assigns directly. A referral link lets the learner accept the referrer or request someone else.',
'Church leadership':'Pastor sees all branches. Branch pastors set up their own branch and appoint unit leaders.',
'Church role flows':'Branch pastor allocates workers. Unit leader sees direct workers. Worker sees their placement.',
'Save contacts':'Save a person without a Pleros account, then organise private contact collections.',
'Organise contacts':'Review history, move the saved contact into a collection, and retain the Unlinked account status.',
'Retained detail screens':'Daily learning, personal reports, direct-worker oversight, and private discipleship details.',
'Populate the church':'Create branches, appoint branch pastors, and review a hierarchy import before applying it.',
'Start SOGP':'Start from You, choose a daily commitment, then confirm your SOGP path.',
'Adaptive learning':'Continue learning adapts to the chosen style: traditional tracks, two podcasts or one podcast per day.',
'Plan previews':'Compare 1hr/day, 30min/day and 15min/day paths before starting.',
'Build your tracklist':'Build your own 30-day podcast plan from editable suggestions, beginning with the Purpose series.'}
def write_board(k,group,items):
 w=80+len(items)*390+(len(items)-1)*56
 maxh=max(float(E.parse(str(P/(name+'.svg'))).getroot().get('height','844')) for name,label in items); boardh=maxh+276
 out=[f'<div layer-name="{k:02d} · {html.escape(group)}" style="position:relative;width:{w}px;height:{boardh:g}px;background:{TOKENS["canvas"]};font-family:{TOKENS["font"]},sans-serif;">']
 out += ['<div style="position:absolute;left:40px;top:30px;font-size:12px;font-weight:600;letter-spacing:2px;color:#2056D6;">PLEROS / MOBILE APP</div>',f'<div style="position:absolute;left:40px;top:56px;font-size:32px;font-weight:600;color:#172B47;">{k:02d} · {html.escape(group)}</div>',f'<div style="position:absolute;left:40px;top:103px;font-size:14px;color:#62738a;">{html.escape(notes.get(group,group))}</div>']
 for i,(name,label) in enumerate(items):
  x=40+i*446
  out += [f'<div style="position:absolute;left:{x}px;top:147px;font-size:12px;font-weight:600;color:#3e526f;">{i+1:02d} / {html.escape(label)}</div>']
  source=(OUT/(name+'.html')).read_text().replace('position:relative;','position:absolute;left:'+str(x)+'px;top:180px;',1)
  out.append(source)
  if k in (2,7,8) and i<len(items)-1:out.append(f'<div style="position:absolute;left:{x+409}px;top:565px;font-size:23px;color:#8b9fbd;">→</div>')
 note = 'Proposed role flow · Representative names and activity' if k in (4,5,6) else 'Editable design walkthrough · 390px mobile screens · Representative names and activity'
 if k==15:note='Unified ministry reporting · Optional outcome details remain a proposal · Representative names and activity'
 if k==16:note='Proposed leader-first meeting model · Shared details are read-only for attendees · No implementation changes'
 out.append(f'<div style="position:absolute;left:40px;top:{maxh+218:g}px;font-size:12px;color:#667a95;">{note}</div></div>')
 (OUT/f'board-{k:02d}.html').write_text(''.join(out))
notes['Daily plan options']=notes['Plan previews']
notes['Adaptive home & player']=notes['Adaptive learning']
notes['Build your 30-day tracklist']=notes['Build your tracklist']
notes['Ministry reporting']='One ministry form for Evangelism and Discipleship. Add contacts inline, or report counts without names.'
notes['Meeting reporting']='Leader creates the shared meeting first. Workers and disciples choose it, then report their attendance and people brought.'
notes['My SOGP & follow-up']='Start learning immediately, resume missed work, review your path and keep current follow-up while requests are pending.'
notes['Weekly group reviews']='Required group reviews for every learning path. Disciplers schedule; session leaders confirm attendance.'
notes['Group invitations']='Invite existing accounts in-app, share a link with non-account contacts, and wait for explicit acceptance.'
notes['Review make-up & certification']='Make up missed reviews while learning continues. Certificate thresholds are not being redefined.'
notes['Edit your learning plan']='Choose your episodes and change pace at any time. Regroup unfinished episodes without erasing completed history.'
notes['Learning history & episode completion']='Traditional and podcast histories stay distinct. Mark each podcast listened; questions are optional, with no required quiz or reflection.'
for k,(group,items) in enumerate(manifest,1):write_board(k if k<14 else k+1,group,items)
print('Created',len(manifest),'presentation board imports')
