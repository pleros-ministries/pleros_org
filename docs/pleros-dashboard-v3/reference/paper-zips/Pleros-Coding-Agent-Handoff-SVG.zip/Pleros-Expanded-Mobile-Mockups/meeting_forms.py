"""Editable, role-aware Pleros meeting-report concepts.

The person who led creates the shared meeting record first. Workers and
disciples choose an existing meeting and submit personal reports without
editing its details. Teaching uses Meeting subject, replacing meeting name
and What was taught; Prayer has no subject. Reporting role labels are not
authorisation policy. Contacts do not invite or create accounts.
"""
from core import Draw, BLUE, INK, MUTED, LINE, SOFT, render_svg


def field(d, x, y, w, label, value, icon=None, placeholder=False):
    d.text(x, y, label, 13, INK, 500)
    d.rect(x, y+12, w, 44, '#FFFFFF', 10, LINE)
    d.text(x+14, y+40, value, 16, MUTED if placeholder else INK)
    if icon:
        d.ic(icon, x+w-32, y+26, 16, MUTED)
    d.raw(f'<rect x="{x}" y="{y+12}" width="{w}" height="44" fill="none" role="combobox" aria-label="{label}"/>')


def attendance(d, y):
    d.section(y, 'I attended')
    for x, label, selected in [(16, 'Yes', True), (201, 'No', False)]:
        d.rect(x, y+16, 173, 44, BLUE if selected else '#FFFFFF', 10, None if selected else LINE)
        d.text(x+86.5, y+44, label, 14, '#FFFFFF' if selected else INK, 500, anchor='middle')
        d.raw(f'<rect x="{x}" y="{y+16}" width="173" height="44" fill="none" role="radio" aria-label="{label}" aria-checked="{str(selected).lower()}"/>')
    return y+60


def people_brought(d, y, teaching=False):
    d.section(y, 'People I brought')
    d.rect(16, y+16, 214, 44, SOFT, 10)
    d.ic('search', 30, y+30, 16, MUTED)
    d.text(56, y+44, 'Search contacts', 14, MUTED)
    d.rect(242, y+16, 132, 44, '#FFFFFF', 10, BLUE)
    d.ic('plus', 254, y+29, 18, BLUE)
    d.text(278, y+44, 'Add contact', 14, BLUE, 500)
    d.raw(f'<rect x="242" y="{y+16}" width="132" height="44" fill="none" role="button" aria-label="Add contact"/>')
    row_y=y+72
    d.rect(16, row_y, 358, 60, '#FFFFFF', 10, LINE)
    d.av(30, row_y+12, 'KA' if teaching else 'TA', 'lilac' if teaching else 'mint', 36)
    d.text(80, row_y+25, 'Kemi Adewale' if teaching else 'Tomi Adebayo', 14, INK, 500)
    d.text(80, row_y+46, 'Saved contact', 13, MUTED)
    d.ic('close', 344, row_y+22, 16, MUTED)
    d.hit(330, row_y+8, 'Remove selected contact')
    count_y=y+144
    d.text(16, count_y+19, 'Others without names', 14, INK)
    d.text(16, count_y+40, 'Optional · proposed', 13, MUTED)
    d.rect(270, count_y, 104, 44, '#FFFFFF', 10, LINE)
    d.text(284, count_y+28, 'Count', 16, MUTED)
    d.text(16, y+211, 'Adding a contact does not invite them.', 13, MUTED)
    return y+211


def _create_meeting(meeting_type):
    prayer=meeting_type=='Prayer'
    # Heights preserve readable mobile controls; content scrolls in an844px viewport.
    d=Draw(height=1173 if prayer else 1111)
    d.back('Create meeting')
    d.text(16,130,f'{meeting_type} meeting',24,INK,500,-.5)
    d.text(16,156,'Create the shared meeting and your report.',13,MUTED)
    d.section(195,'Meeting details')
    field(d,16,224,171,'Meeting type',meeting_type,'down')
    field(d,203,224,171,'Date','13 Oct 2026','calendar')
    if prayer:
        field(d,16,309,358,'Venue','Yaba fellowship hall, Lagos')
        field(d,16,394,171,'Start · Lagos (WAT)','6:00 pm','clock')
        field(d,203,394,171,'End · Lagos (WAT)','7:15 pm','clock')
        shared_end=450
    else:
        field(d,16,309,358,'Meeting subject','The life of faith')
        d.text(16,388,'Shown when others choose this meeting.',13,MUTED)
        shared_end=388
    y=shared_end+40
    d.section(y,'Your report');d.chip(248,y-21,'Led the meeting','blue',126)
    attended_y=y+44
    attendance(d,attended_y)
    end=people_brought(d,attended_y+96,teaching=not prayer)
    totals_y=end+36
    d.section(totals_y,'Meeting totals')
    field(d,16,totals_y+29,358,'Total meeting attendance','Enter total',placeholder=True)
    d.text(16,totals_y+108,'Includes you and everyone present.',13,MUTED)
    extra_y=totals_y+140
    d.rect(16,extra_y,358,44,'#FFFFFF',10,LINE)
    d.text(30,extra_y+28,'Additional details · optional',14,INK)
    d.ic('down',342,extra_y+14,16,MUTED)
    d.bottom_cta('Create meeting & save report',icon='check')
    return d.svg()


def _existing_summary(d,prayer):
    d.text(16,126,'EXISTING MEETING',12,MUTED,500,.3)
    d.text(374,126,'Change meeting',13,BLUE,500,anchor='end')
    d.text(16,166,'Prayer meeting' if prayer else 'The life of faith',24,INK,500,-.4)
    height=190 if prayer else 146
    d.rect(16,194,358,height,SOFT,12)
    d.chip(32,210,'Prayer' if prayer else 'Teaching','blue' if prayer else 'lilac')
    d.ic('lock',338,214,16,MUTED)
    d.text(32,267,'Tue, 13 Oct 2026',14,INK,500)
    if prayer:
        d.text(32,294,'Yaba fellowship hall, Lagos',14,INK)
        d.text(32,320,'6:00–7:15 pm · Lagos (WAT)',13,MUTED)
        d.text(32,357,'Created by Kunle Adebayo',13,MUTED)
    else:
        d.text(32,310,'Created by Ruth Akinola',13,MUTED)
    d.text(16,194+height+28,'Meeting details are read-only.',13,MUTED)
    return 194+height+28


def _join_meeting(meeting_type):
    prayer=meeting_type=='Prayer'
    d=Draw(height=1058 if prayer else 1014)
    d.back('Report attendance')
    end=_existing_summary(d,prayer)
    role_y=end+40
    field(d,16,role_y,358,'Your part in this meeting','Disciple' if prayer else 'Worker','down')
    d.text(16,role_y+77,'Worker · Disciple',13,MUTED)
    attended_y=role_y+114
    attendance(d,attended_y)
    end=people_brought(d,attended_y+96,teaching=not prayer)
    extra_y=end+32
    d.rect(16,extra_y,358,44,'#FFFFFF',10,LINE)
    d.text(30,extra_y+28,'Additional details · optional',14,INK)
    d.ic('down',342,extra_y+14,16,MUTED)
    d.bottom_cta('Save my attendance report',icon='check')
    return d.svg()


def prayer_attendee():return _join_meeting('Prayer')
def prayer_led():return _create_meeting('Prayer')
def teaching_attendee():return _join_meeting('Teaching')
def teaching_led():return _create_meeting('Teaching')

SCREENS=[
    ('Pleros-report-teaching-led','Teaching · Create the meeting',teaching_led),
    ('Pleros-report-prayer-led','Prayer · Create the meeting',prayer_led),
    ('Pleros-report-teaching-attendee','Teaching · Worker joins',teaching_attendee),
    ('Pleros-report-prayer-attendee','Prayer · Disciple joins',prayer_attendee),
]
if __name__=='__main__':
    for stem,_,factory in SCREENS:render_svg(stem,factory())
