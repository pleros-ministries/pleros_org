"""Adaptive learning surfaces, using the shared premium Pleros design system."""
from core import *


def _header():
    d = Draw(height=1020)
    d.root('you')
    d.text(20, 182, 'Good morning, Tolu', 21, INK, 500, -.4)
    return d


def _reports(d, y=548):
    d.text(20, y, 'My reports', 15, INK, 500)
    d.text(370, y, 'View day', 13, BLUE, 500, anchor='end')
    rows = [
        ('book', 'Devotional', '3 activities logged', 'Not confirmed', 'amber', 120),
        ('heart', 'Ministry', 'No report submitted', 'Not reported', 'neutral', 104),
        ('people', 'Meetings', '1 meeting recorded', 'Reported', 'green', 84),
    ]
    for i, (icon, title, subtitle, state, style, width) in enumerate(rows):
        top = y + 12 + i * 72
        d.ic(icon, 20, top + 16, 20, MUTED)
        d.text(56, top + 26, title, 14, INK, 500)
        d.text(56, top + 48, subtitle, 13, MUTED)
        d.chip(370 - width, top + 8, state, style, width)
        if i < 2:
            d.line(56, top + 66, 370, top + 66)
    d.text(20, y + 260, 'My support', 15, INK, 500)
    d.av(20, y + 280, 'ED', 'mint', 36)
    d.text(68, y + 293, 'Efe Daniels', 14, INK, 500)
    d.text(68, y + 315, 'Your discipler · Connected', 13, MUTED)
    d.raw(f'<g role="button" aria-label="Message Efe Daniels"><rect x="298" y="{y + 274}" width="72" height="44" fill="none"/>')
    d.text(370, y + 301, 'Message', 14, BLUE, 500, anchor='end')
    d.raw('</g>')
    d.bottom()


def home_start():
    d = _header()
    d.text(20, 238, 'Your next step', 15, INK, 500)
    d.rect(20, 250, 350, 232, BLUE, 16)
    d.text(40, 282, 'SOGP', 13, '#D8E4FF')
    d.text(40, 320, 'Make room to grow', 24, '#FFFFFF', 500, -.4)
    d.text(40, 352, 'Choose a daily pace that fits your life.', 14, '#E1EAFF')
    d.text(40, 376, 'Traditional tracks or podcast episodes.', 14, '#E1EAFF')
    d.btn(40, 414, 310, 'Start SOGP', 'arrow', fill='#FFFFFF', color=BLUE, h=48)
    d.ic('clock', 20, 518, 20, MUTED)
    d.text(56, 528, '1 hour, 30 minutes or 15 minutes a day', 13, INK)
    d.text(56, 552, 'You’ll choose before starting.', 13, MUTED)
    d.line(20, 584, 370, 584)
    _reports(d, 624)
    return d.svg()


def _progress(d, x, y, w, progress, position, total, white=False):
    # The white parameter remains for compatibility; every current player uses
    # the same high-contrast white surface and its own saved playback position.
    d.rect(x, y, w, 4, LINE, 2)
    d.rect(x, y, w * progress, 4, BLUE, 2)
    d.circle(x + w * progress, y + 2, 4, BLUE)
    d.text(x, y + 28, position, 13, MUTED)
    d.text(x + w, y + 28, total, 13, MUTED, anchor='end')


def home_hour():
    d = _header()
    d.text(20, 238, 'Continue learning', 15, INK, 500)
    d.text(370, 238, 'View plan', 13, BLUE, 500, anchor='end')
    d.rect(20, 250, 350, 232, '#FFFFFF', 16, LINE)
    d.text(40, 282, 'Traditional track · 1 hr/day', 13, MUTED)
    d.text(40, 320, 'Track 03', 24, INK, 500, -.4)
    _progress(d, 40, 356, 310, 1122 / 3600, '18:42 elapsed', '1:00:00 total')
    d.btn(40, 414, 310, 'Resume track', 'play', h=48)
    d.ic('book', 20, 518, 20, MUTED)
    d.text(56, 528, '2 traditional tracks completed', 14, INK, 500)
    d.text(56, 552, 'Your place in Track 03 is saved.', 13, MUTED)
    d.ic('right', 350, 524, 16, MUTED)
    d.raw('<rect x="334" y="510" width="44" height="44" fill="none" role="button" aria-label="View traditional track progress"/>')
    d.line(20, 584, 370, 584)
    _reports(d, 624)
    return d.svg()


def home_thirty():
    d = _header()
    d.text(20, 238, 'Continue learning', 15, INK, 500)
    d.text(370, 238, 'View plan', 13, BLUE, 500, anchor='end')
    d.rect(20, 250, 350, 316, '#FFFFFF', 16, LINE)
    d.text(40, 282, 'Podcast plan · 30 min/day', 13, MUTED)
    d.text(40, 320, 'Today’s two episodes', 24, INK, 500, -.4)
    d.text(40, 348, 'The Reality of God’s Purpose', 14, MUTED)
    d.ic('check', 40, 374, 16, '#52694D')
    d.text(68, 387, 'Part 1 · 15:33', 14, INK, 500)
    d.text(350, 387, 'Completed', 13, '#52694D', anchor='end')
    d.line(40, 406, 350, 406)
    d.text(40, 434, 'Part 2', 15, INK, 500)
    d.text(350, 434, 'In progress', 13, MUTED, anchor='end')
    _progress(d, 40, 454, 310, 285 / 853, '04:45 elapsed', '14:13 total')
    d.btn(40, 498, 310, 'Resume episode 02', 'play', h=48)
    _reports(d, 618)
    return d.svg()


def home_fifteen():
    d = _header()
    d.text(20, 238, 'Continue learning', 15, INK, 500)
    d.text(370, 238, 'View plan', 13, BLUE, 500, anchor='end')
    d.rect(20, 250, 350, 264, '#FFFFFF', 16, LINE)
    d.text(40, 282, 'Podcast plan · 15 min/day', 13, MUTED)
    d.text(40, 318, 'The Reality of', 24, INK, 500, -.4)
    d.text(40, 348, 'God’s Purpose', 24, INK, 500, -.4)
    d.text(40, 376, 'Part 3 · 1 episode today', 13, MUTED)
    _progress(d, 40, 400, 310, 480 / 814, '08:00 elapsed', '13:34 total')
    d.btn(40, 446, 310, 'Resume episode', 'play', h=48)
    d.ic('headphones', 20, 550, 20, MUTED)
    d.text(56, 560, 'Your podcast path', 14, INK, 500)
    d.text(56, 584, 'Part 3 · 08:00 of 13:34 listened', 13, MUTED)
    d.ic('right', 350, 556, 16, MUTED)
    d.raw('<rect x="334" y="542" width="44" height="44" fill="none" role="button" aria-label="View your podcast path"/>')
    _reports(d, 632)
    return d.svg()


SCREENS = [
    ('Pleros-home-start-sogp', home_start),
    ('Pleros-home-1hour', home_hour),
    ('Pleros-home-30min', home_thirty),
    ('Pleros-home-15min', home_fifteen),
]

if __name__ == '__main__':
    for name, fn in SCREENS:
        render_svg(name, fn())
    board(
        'Pleros-Adaptive-Learning-Board',
        'Your pace. Your next listen.',
        'Each home player follows the selected SOGP path and saves its own content position.',
        [('1 hour · Traditional track', home_hour()),
         ('30 minutes · Two-episode queue', home_thirty()),
         ('15 minutes · One daily episode', home_fifteen())],
        'SOGP / ADAPTIVE HOME PLAYERS'
    )
