"""Unified ministry reporting UI. Optional outcomes remain a proposal; no metrics are removed."""
from core import *


def _activity_tabs(d,y,selected):
    d.rect(16,y,358,48,SOFT,11)
    for x,w,label in [(20,171,'Evangelism'),(199,171,'Discipleship')]:
        active=label==selected
        if active:d.rect(x,y+4,w,40,'#FFFFFF',8,LINE)
        d.raw(f'<g role="tab" aria-selected="{str(active).lower()}">')
        d.text(x+w/2,y+30,label,14,BLUE if active else MUTED,500 if active else 400,anchor='middle')
        d.raw('</g>')


def _person(d,y,initials,name,sub,color):
    d.av(16,y,initials,color,36)
    d.text(64,y+15,name,14,INK,500)
    d.text(64,y+37,sub,13,MUTED)
    d.hit(326,y-4,'Edit person details');d.text(370,y+23,'Details',13,BLUE,500,anchor='end')
    d.line(64,y+52,374,y+52)


def _collapse(d,y,title,summary,icon):
    d.rect(16,y,358,60,SOFT,12)
    d.ic(icon,32,y+19,20,MUTED)
    d.text(64,y+25,title,14,INK,500)
    d.text(64,y+46,summary,13,MUTED)
    d.ic('right',342,y+22,16,MUTED)


def _ministry_form(kind):
    d=Draw(height=1100);d.back('Record ministry')
    d.text(16,124,'Today · Tue, 13 Oct',13,MUTED);d.text(374,124,'Change date',13,BLUE,500,anchor='end')
    d.text(16,166,'One simple report',24,INK,500,-.4)
    _activity_tabs(d,200,kind)
    d.field(290,'How did you connect?','In person' if kind=='Evangelism' else 'Mixed methods',right='down')
    d.field(378,'Where?' if kind=='Evangelism' else 'Context · optional','Yaba, Lagos' if kind=='Evangelism' else 'Personal follow-up')
    d.section(476,'People')
    d.text(16,523,'People reached' if kind=='Evangelism' else 'People involved',14,INK,500)
    d.rect(274,492,100,48,'#FFFFFF',11,LINE)
    d.text(290,523,'12' if kind=='Evangelism' else '3',16,INK)
    d.text(16,569,'Named people are included in this total.',13,MUTED)
    d.text(16,591,'You can report a count without saving contacts.',13,MUTED)
    d.section(632,'Named people')
    d.raw('<g role="button" aria-label="Add a contact inline">')
    d.rect(242,604,132,44,'#E4EBFD',10);d.ic('plus',254,618,16,BLUE);d.text(278,632,'Add contact',14,BLUE,500)
    d.raw('</g>')
    d.search(660,'Find a saved contact')
    if kind=='Evangelism':
        _person(d,728,'AO','Amara Okafor','In person · Follow-up requested','apricot')
        _person(d,794,'DE','Dayo Eze','In person · Add details','blue')
    else:
        _person(d,728,'AO','Amara Okafor','Phone call · Add details','apricot')
        _person(d,794,'DE','Dayo Eze','WhatsApp · Add details','blue')
    _collapse(d,878,'Outcomes · optional','Saved, filled, healed and follow-ups','circlecheck')
    d.text(16,968,'Add an overall note',14,BLUE,500);d.hit(16,942,'Add an overall note')
    d.bottom_cta('Save ministry report',icon='check')
    return d.svg()


def ministry_evangelism():return _ministry_form('Evangelism')
def ministry_discipleship():return _ministry_form('Discipleship')


def inline_add_contact():
    d=Draw(height=1088)
    d.rect(0,0,390,1088,'#DDE2EA')
    d.text(27,26,'9:41',13,INK,600)
    d.text(195,74,'Record ministry',14,'#657083',500,anchor='middle')
    d.text(195,112,'Evangelism · In person',13,'#657083',anchor='middle')
    d.rect(0,160,390,928,'#FFFFFF',20)
    d.rect(173,172,44,4,LINE,2)
    d.hit(326,190,'Close add contact');d.ic('close',338,202,20,MUTED)
    d.text(16,243,'Add a contact',24,INK,500,-.4)
    d.text(16,274,'Save and use in this report.',14,MUTED)
    def entry(y,label,value):
        d.text(16,y,label,13,INK,500)
        d.rect(16,y+12,358,44,'#FFFFFF',11,LINE)
        d.text(32,y+40,value,14,INK)
    entry(324,'Full name · required','Adaeze Bello')
    entry(412,'Phone number · required','+234 800 000 0102')
    entry(500,'Email · optional','adaeze@example.com')
    d.text(16,588,'Contact note · optional',13,INK,500)
    d.rect(16,600,358,116,'#FFFFFF',11,LINE)
    d.text(32,630,'Met at the community gathering.',14,INK)
    d.text(32,652,'Would like a follow-up call.',14,INK)
    d.note(748,['This saved contact is private to you.','They’ll be selected for this report.','No account or invitation is created;','no message is sent.'],'blue','people')
    d.text(16,896,'You’ll return to your report after saving.',13,MUTED)
    d.bottom_cta('Save & add to report',icon='check')
    return d.svg()


def ministry_outcomes():
    d=Draw(height=1100);d.back('Ministry outcomes')
    d.text(16,126,'EVANGELISM · OPTIONAL DETAILS',12,MUTED,500,.3)
    d.text(16,166,'Record what happened',24,INK,500,-.4)
    d.text(16,199,'Add the results you want to keep.',14,MUTED)
    d.rect(16,232,358,72,SOFT,12)
    d.text(32,260,'12 people reached',15,INK,500)
    d.text(32,285,'2 named contacts · In person',13,MUTED)
    d.section(348,'Optional totals')
    for y,label,value in [(376,'Gave their lives to Christ','2'),(444,'Not saved','—'),(512,'Filled with the Holy Spirit','1'),(580,'Healed','—'),(648,'Follow-ups','3')]:
        d.text(16,y+30,label,14,INK)
        d.rect(286,y,88,48,'#FFFFFF',11,LINE);d.text(302,y+31,value,16,MUTED if value=='—' else INK)
        if y<648:d.line(16,y+59,374,y+59)
    d.text(16,735,'Leave blank when you are not recording a result.',13,MUTED)
    d.text(16,783,'Overall note · optional',13,INK,500)
    d.rect(16,795,358,108,'#FFFFFF',11,LINE)
    d.text(32,825,'A few people asked to stay in touch.',16,INK)
    d.text(32,853,'Arrange a follow-up this week.',16,INK)
    d.text(16,945,'Named details remain available on each person.',13,MUTED)
    d.bottom_cta('Apply to report',icon='check')
    return d.svg()


SCREENS=[('Pleros-report-ministry-evangelism',ministry_evangelism),('Pleros-report-ministry-discipleship',ministry_discipleship),('Pleros-report-inline-add-contact',inline_add_contact),('Pleros-report-ministry-outcomes',ministry_outcomes)]
if __name__=='__main__':
    for name,fn in SCREENS:render_svg(name,fn())
    board('Pleros-Ministry-Reporting-Board','One form. The people stay close.','Activity and people, with quick contact capture. Optional outcomes remain a proposal.', [('Evangelism · unified form',ministry_evangelism()),('Add a contact inline',inline_add_contact()),('Optional ministry outcomes',ministry_outcomes())],'REPORTING / MINISTRY')
