# Reporting forms for review

## Unified ministry flow
Choose Evangelism or Discipleship, describe the interaction, record people, then optionally expand outcomes or add a note. Add contact stays beside the people picker and returns the saved contact to the report. Counts can be recorded without creating contacts. Saving does not create an account, send an invitation or confirm meeting attendance.

Existing ministry metrics remain available in optional details. The optional-outcome proposal reorganises them; it does not decide which metrics should be removed. Per-person methods and details remain accessible. Online reach and mixed-channel variants still need a detailed field review.

## Settled meeting model
The person who led reports first and creates one shared meeting record. Their report includes personal attendance, people brought and total meeting attendance, including themselves and everyone present.

Workers and disciples then select that existing meeting. They see its details read-only and submit only their personal attendance and people brought. They do not enter another meeting name, subject, date, venue, time or total.

Teaching creation uses “Meeting subject,” replacing both “Meeting name” and “What was taught.” Prayer has no subject; its shared record includes venue and start/end times. Examples use Lagos (WAT).

If the record is absent, the screen says exactly “Meeting not listed yet.” It asks the person to return later and provides no request-creation or notification action.

## Implementation decisions still open
Worker/Disciple labels reflect the user’s current terminology; mapping them to existing Member/Worker permissions must be resolved without granting new access. Optional unnamed counts, outcome visibility, overlapping outcomes, online reach definitions, validation and overnight meeting handling still need confirmation. Blank fields are not forced to zero. Named contacts and unnamed people remain distinct; brought counts across reporters are not unique meeting attendance.

These are editable design concepts using fictional people. No live meeting records, reports or contacts have been saved.
