from core import *

def control_centre():
 d=Draw();d.back('SOGP')
 d.label(126,'COORDINATOR · ALL ENROLLEES');d.text(16,166,'Control centre',24,INK,500)
 for x,v,label in [(16,'156','Enrollees'),(140,'152','Assigned'),(270,'4','Requests')]:
  d.text(x,224,v,26,INK,500);d.text(x,248,label,13,MUTED)
 d.rect(16,280,302,44,SOFT,11);d.ic('search',32,294,16,MUTED);d.text(60,309,'Find an enrollee',14,MUTED);d.rect(330,280,44,44,'#FFFFFF',11,LINE);d.ic('filter',342,292,20,MUTED);d.hit(330,280,'Filter enrollees')
 for x,label in [(16,'All'),(67,'Unassigned'),(175,'Assigned'),(266,'Requests · 4')]:
  d.rect(x-8,340,104 if x==266 else 90,44,'none');d.text(x,368,label,13,INK if x==16 else MUTED,500 if x==16 else 400)
 d.line(16,384,374,384);d.rect(16,382,22,2,BLUE,1)
 d.section(424,'October cohort');d.text(374,424,'Recent first',13,MUTED,anchor='end')
 rows=[('AO','apricot','Amara Okafor','Direct join · Lagos','Assigned','green','Owner: Nneka Adeyemi · Area leader'),('MI','lilac','Miriam Ibe','Referral link · Today','Requested change','amber','Owner: Efe Daniels'),('DE','blue','Dayo Eze','Referral code · Today','Assigned','green','Owner: Nneka Adeyemi')]
 for i,(initials,col,name,sub,state,style,owner) in enumerate(rows):
  y=448+i*112;d.av(16,y,initials,col,36);d.text(64,y+15,name,14,INK,500);d.text(64,y+37,sub,13,MUTED);d.ic('right',354,y+10,16,MUTED);d.hit(340,y-4,'Open enrollee details');d.chip(64,y+52,state,style);d.text(64,y+99,owner,13,MUTED);d.line(16,y+112,374,y+112)
 d.bottom();return d.svg()

def enrollee():
 d=Draw();d.back('Enrollee details');d.av(16,111,'MI','lilac',44);d.text(76,132,'Miriam Ibe',24,INK,500);d.text(76,155,'SOGP · October cohort',13,MUTED);d.chip(16,176,'Reassignment requested','amber')
 d.note(220,['“I’d prefer someone in my time zone.”','Requested today at 8:45 am'],'amber','chat');d.section(316,'Follow-up owner');d.rect(16,332,358,104,'#fff',16,LINE);d.av(32,348,'ED','mint',36);d.text(80,363,'Efe Daniels',14,INK,500);d.text(80,386,'Assigned by referral link',13,MUTED);d.text(32,418,'Change owner',14,BLUE,500);d.ic('arrow',338,401,20,BLUE)
 d.section(474,'Enrolment')
 for i,(label,value) in enumerate([('Joined','12 Oct · 3:42 pm'),('Source','Efe’s referral link'),('Last contact','12 Oct · In-app message')]):
  y=505+i*36;d.text(16,y,label,13,MUTED);d.text(374,y,value,13,INK,anchor='end');d.line(16,y+14,374,y+14) if i<2 else None
 d.section(627,'Owner history');d.circle(24,653,3,BLUE);d.text(40,658,'Assigned to Efe Daniels',14,INK,500);d.text(40,680,'12 Oct · Referral link',13,MUTED);d.line(24,661,24,700,LINE,2);d.circle(24,709,3,'#9D8254');d.text(40,714,'Requested someone else',14,INK,500);d.text(40,736,'13 Oct · Awaiting review',13,MUTED);d.bottom_cta('Review reassignment',icon='arrow');return d.svg()

def change_owner():
 d=Draw();d.back('Change follow-up owner');d.label(117,'REASSIGNMENT REQUEST');d.text(16,151,'Choose someone to help',24,INK,500);d.text(16,178,'Miriam Ibe · Currently Efe Daniels',13,MUTED);d.search(198,'Search follow-up owners');d.text(16,275,'People in your assignment scope',14,INK,500)
 for i,(initials,col,name,sub,selected) in enumerate([('NA','blue','Nneka Adeyemi','8 enrollees · Lagos',True),('DO','apricot','Daniel Okoye','11 enrollees · Abuja',False),('RA','lilac','Ruth Adebayo','6 enrollees · London',False)]):
  y=293+i*76;d.rect(16,y,358,64,'#F2F5FC' if selected else '#fff',12,'#B8CAEE' if selected else LINE);d.av(32,y+14,initials,col,36);d.text(80,y+27,name,14,INK,500);d.text(80,y+48,sub,13,MUTED);d.circle(348,y+32,9,BLUE if selected else '#fff',None if selected else LINE);d.ic('check',342,y+26,12,'#fff') if selected else None
 d.field(548,'Reason for the change','Enrollee requested a change',right='down');d.note(626,['Miriam moves to Nneka’s enrollee list.','Keep learning and follow-up history.','Group membership stays separate.'],'blue','shield');d.bottom_cta('Confirm reassignment',sub='Efe Daniels → Nneka Adeyemi');return d.svg()

def my_enrollees():
 d=Draw();d.back('My enrollees');d.label(118,'YOUR FOLLOW-UP');d.text(16,151,'People you support',24,INK,500);d.text(16,180,'Your assigned enrollees, across all sources.',13,MUTED)
 d.rect(16,204,358,116,SOFT,16);d.text(32,232,'Your referral',13,MUTED);d.text(32,264,'NNEKA26',22,BLUE,500);d.btn(254,228,104,'Share',icon='arrow',fill='#fff',color=BLUE);d.text(32,298,'Code assigns directly. Link offers a choice.',12,MUTED)
 d.text(16,360,'To follow up',14,BLUE,500);d.text(162,360,'All enrollees',14,MUTED);d.line(16,379,374,379);d.rect(16,377,102,2,BLUE,1);d.text(16,409,'3 need your attention',13,MUTED)
 for i,(initials,col,name,sub,state,style) in enumerate([('DE','blue','Dayo Eze','Your referral code · Today','New','blue'),('MI','lilac','Miriam Ibe','Reassigned to you · Today','New owner','blue'),('TA','mint','Tosin Ade','Last contact · 3 days ago','Follow up','amber')]):
  y=431+i*98;d.av(16,y,initials,col,36);d.text(64,y+15,name,14,INK,500);d.text(64,y+38,sub,13,MUTED);d.chip(64,y+50,state,style);d.ic('right',354,y+12,16,MUTED);d.line(16,y+86,374,y+86)
 d.note(751,['Showing your assigned enrollees.'],'blue','shield');d.bottom();return d.svg()

def referral_code():
 d=Draw();d.back('Welcome to SOGP');d.chip(16,112,'Joined with a code','blue');d.circle(195,198,34,'#EDF2EB');d.ic('circlecheck',177,180,36,'#52694D');d.text(195,270,'You’re in, Dayo.',24,INK,500,anchor='middle');d.text(195,299,'Your SOGP journey starts here.',14,MUTED,anchor='middle')
 d.rect(16,330,358,165,SOFT,16);d.text(32,359,'Your follow-up person',13,MUTED);d.av(32,377,'NA','blue',44);d.text(92,395,'Nneka Adeyemi',15,INK,500);d.text(92,418,'Here to help you settle in',13,MUTED);d.line(32,440,358,440);d.text(32,475,'Referral code',13,MUTED);d.text(358,475,'NNEKA26',14,BLUE,500,anchor='end')
 d.text(16,539,'You’ve been assigned to Nneka because',14,INK);d.text(16,561,'you joined with her referral code.',14,INK);d.note(595,['Your follow-up assignment is ready.','Group invitations are a separate step.'],'blue','people');d.text(195,711,'Need help with your assignment?',14,BLUE,500,anchor='middle');d.bottom_cta('Start learning',icon='arrow');return d.svg()

def referral_link():
 d=Draw();d.back('Welcome to SOGP');d.chip(16,112,'Joined through a link','blue');d.text(16,166,'Meet your follow-up person',24,INK,500);d.text(16,195,'You joined through Efe’s invitation link.',13,MUTED)
 d.rect(16,220,358,188,SOFT,16);d.av(173,240,'ED','mint',44);d.text(195,320,'Efe Daniels',24,INK,500,anchor='middle');d.text(195,345,'Assigned from your referral link',13,MUTED,anchor='middle');d.chip(117,365,'Awaiting your choice','amber')
 d.text(16,451,'Would you like Efe to follow up with you?',14,INK,500);d.text(16,478,'Accept Efe, or ask for someone else.',14,MUTED);d.btn(16,508,358,'Accept Efe','check');d.rect(16,564,358,44,'#fff',11,LINE);d.text(195,592,'Request someone else',14,BLUE,500,anchor='middle');d.note(632,['This choice is for follow-up support.','Joining a group is a separate step.'],'blue','shield');d.text(195,750,'Start learning now',14,BLUE,500,anchor='middle');d.text(195,777,'You can make this choice later.',13,MUTED,anchor='middle');d.bottom();return d.svg()

def request_pending():
 d=Draw();d.back('Follow-up request');d.circle(195,154,30,'#F6EFE2');d.ic('clock',179,138,32,'#785B2C');d.text(195,218,'Request received',24,INK,500,anchor='middle');d.text(195,249,'Your request is with a coordinator.',14,MUTED,anchor='middle');d.chip(131,272,'Request pending','amber')
 d.rect(16,325,358,174,'#fff',16,LINE);d.text(32,355,'Your request',13,MUTED);d.text(32,387,'“I’d prefer someone in my time zone.”',14,INK);d.text(32,414,'Sent today at 8:45 am',13,MUTED);d.line(32,437,358,437);d.text(32,474,'Current owner',13,MUTED);d.text(358,474,'Efe Daniels',14,INK,500,anchor='end')
 d.section(542,'What happens next');d.circle(26,571,10,'#EDF2FB');d.text(26,575,'1',12,BLUE,500,anchor='middle');d.text(52,577,'A coordinator reviews your request.',14,INK);d.circle(26,624,10,'#EDF2FB');d.text(26,628,'2',12,BLUE,500,anchor='middle');d.text(52,623,'Your updated follow-up assignment',14,INK);d.text(52,645,'will appear here.',14,INK);d.note(672,['Efe continues to follow up with you','until your assignment changes.'],'blue','people');d.bottom_cta('Continue learning',icon='arrow');return d.svg()

SCREENS={'control-centre':control_centre,'enrollee-details':enrollee,'change-owner':change_owner,'my-enrollees':my_enrollees,'referral-code':referral_code,'referral-link':referral_link,'reassignment-pending':request_pending}
if __name__=='__main__':
 for name,fn in SCREENS.items():render_svg('Pleros-'+name,fn())
 board('Pleros-SOGP-Operations','Give every enrollee a follow-up owner.','Coordinator review, reassignment and the personal enrollee list.', [('Review an enrollee',enrollee()),('Reassign with context',change_owner()),('See only your enrollees',my_enrollees())], 'SOGP / PEOPLE & ASSIGNMENT')
 board('Pleros-SOGP-Referral-Journeys','Two ways in. A thoughtful handover.','A code assigns directly. A link introduces the owner and asks for a choice.', [('Referral code · assigned',referral_code()),('Referral link · choose',referral_link()),('Ask for someone else',request_pending())], 'SOGP / REFERRAL JOURNEYS')
