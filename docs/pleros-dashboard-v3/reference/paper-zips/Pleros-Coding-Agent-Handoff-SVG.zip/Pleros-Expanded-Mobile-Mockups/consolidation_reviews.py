"""Weekly group-review concepts for the settled Pleros learning paths.

Static, fictional data. Both traditional and podcast learners attend required
weekly group reviews. The discipler schedules; the session leader confirms
attendance on the shared review session. Choosing a make-up does not prove
attendance or award certification. No attendance target, equivalence formula,
rescheduling rule, or correction permission is introduced here.
"""
from core import Draw, BLUE, INK, MUTED, LINE, SOFT, render_svg, board

GROUP = 'Tolu’s discipleship group'


def field(d, y, label, value, icon=None, x=16, w=358):
    d.text(x, y, label, 13, INK, 500)
    d.rect(x, y+12, w, 44, '#FFFFFF', 10, LINE)
    d.text(x+14, y+40, value, 16, INK)
    if icon:
        d.ic(icon, x+w-32, y+26, 16, MUTED)
    d.raw(f'<rect x="{x}" y="{y+12}" width="{w}" height="44" fill="none" role="combobox" aria-label="{label}"/>')


def note(d, y, lines):
    d.rect(16, y, 358, 24+len(lines)*20, SOFT, 12)
    for i, line in enumerate(lines):
        d.text(32, y+25+i*20, line, 13, MUTED)


def summary(d, y, *, makeup=False):
    """One read-only shared session, reused by the leader and learner."""
    d.rect(16, y, 358, 178, SOFT, 12)
    d.text(32, y+29, 'Week 2 · The life of faith', 17, INK, 500)
    d.text(32, y+55, GROUP, 13, MUTED)
    d.line(32, y+73, 358, y+73)
    d.text(32, y+102, 'Sat, 10 Oct 2026 · 5:00–6:00 pm', 14, INK)
    d.text(32, y+126, 'Yaba fellowship hall · Lagos (WAT)', 13, MUTED)
    d.text(32, y+153, 'Session leader · Tolu', 13, MUTED)
    d.ic('lock', 338, y+137, 16, MUTED)
    d.raw('<g data-shared-review="tolu-week-2-2026-10-10"/>')


def learner_reviews():
    d = Draw(1060)
    d.back('Group reviews')
    d.text(16, 132, 'Weekly group reviews', 24, INK, 500, -.5)
    d.text(16, 160, GROUP, 13, MUTED)
    note(d, 192, [
        'Required for traditional and podcast paths.',
        'Your session leader confirms attendance.',
        'You can keep learning between reviews.',
    ])
    d.section(320, 'Next group review')
    d.rect(16, 338, 358, 212, '#FFFFFF', 12, LINE)
    d.chip(32, 354, 'Scheduled', 'blue')
    d.text(32, 410, 'Week 3 · Living by faith', 18, INK, 500, -.3)
    d.text(32, 438, 'Sat, 17 Oct 2026 · 5:00–6:00 pm', 14, INK)
    d.text(32, 462, 'Lagos (WAT)', 13, MUTED)
    d.text(32, 491, 'Yaba fellowship hall', 14, INK)
    d.text(32, 522, 'Session leader · Tolu', 13, MUTED)
    d.section(594, 'Your attendance')
    d.rect(16, 612, 358, 146, '#FFFFFF', 12, LINE)
    d.text(32, 642, 'Week 2 · The life of faith', 15, INK, 500)
    d.text(32, 666, 'Sat, 10 Oct 2026', 13, MUTED)
    d.chip(32, 684, 'Missed', 'amber')
    d.text(32, 738, 'Choose a make-up', 14, BLUE, 500)
    d.ic('right', 338, 721, 20, BLUE)
    d.raw('<rect x="16" y="612" width="358" height="146" fill="none" role="button" aria-label="Choose a make-up for the missed Week 2 review"/>')
    d.rect(16, 774, 358, 126, '#FFFFFF', 12, LINE)
    d.text(32, 804, 'Week 1 · Getting started', 15, INK, 500)
    d.text(32, 828, 'Sat, 3 Oct 2026', 13, MUTED)
    d.chip(32, 846, 'Confirmed', 'green')
    d.text(153, 865, 'by Tolu', 13, MUTED)
    d.text(16, 940, 'View certification readiness', 14, BLUE, 500)
    d.ic('right', 354, 923, 20, BLUE)
    d.bottom_cta('Continue learning', icon='arrow')
    return d.svg()


def schedule_review():
    d = Draw(1096)
    d.back('Schedule group review')
    d.text(16, 132, 'Plan your weekly review', 24, INK, 500, -.5)
    d.chip(16, 154, 'Discipler', 'lilac')
    d.section(220, 'Group')
    d.rect(16, 238, 358, 70, SOFT, 11)
    d.text(32, 267, GROUP, 15, INK, 500)
    d.text(32, 290, 'Traditional and podcast learners', 13, MUTED)
    d.section(352, 'Review details')
    field(d, 386, 'Review title', 'Week 3 · Living by faith')
    field(d, 474, 'Date', '17 Oct 2026', 'calendar')
    field(d, 562, 'Start · Lagos (WAT)', '5:00 pm', 'clock', w=171)
    field(d, 562, 'End · Lagos (WAT)', '6:00 pm', 'clock', x=203, w=171)
    field(d, 650, 'Venue', 'Yaba fellowship hall')
    field(d, 738, 'Session leader', 'Tolu', 'down')
    note(d, 826, [
        'The session leader confirms attendance',
        'on this review after it takes place.',
        'Scheduling does not confirm attendance.',
    ])
    d.text(16, 949, 'The same review appears in the group’s list.', 13, MUTED)
    d.bottom_cta('Schedule group review', icon='calendar')
    return d.svg()


def _attendance_row(d, y, initials, name, path, present, color):
    d.av(16, y, initials, color, 36)
    d.text(64, y+15, name, 14, INK, 500)
    d.text(64, y+37, path, 13, MUTED)
    for x, label, selected in [(16, 'Attended', present), (201, 'Missed', not present)]:
        d.rect(x, y+55, 173, 44, BLUE if selected else '#FFFFFF', 10, None if selected else LINE)
        d.text(x+86.5, y+83, label, 14, '#FFFFFF' if selected else INK, 500, anchor='middle')
        d.raw(f'<rect x="{x}" y="{y+55}" width="173" height="44" fill="none" role="radio" aria-label="{name}: {label}" aria-checked="{str(selected).lower()}"/>')


def leader_attendance():
    d = Draw(1120)
    d.back('Confirm attendance')
    d.text(16, 132, 'Record group attendance', 24, INK, 500, -.5)
    d.chip(16, 154, 'Session leader', 'lilac')
    summary(d, 212)
    d.text(16, 418, 'You’re confirming the existing review session.', 13, MUTED)
    d.section(462, 'Learners')
    _attendance_row(d, 484, 'AO', 'Amara Okafor', 'Traditional path', False, 'apricot')
    d.line(16, 603, 374, 603)
    _attendance_row(d, 627, 'KA', 'Kemi Adewale', 'One podcast a day', True, 'lilac')
    d.line(16, 746, 374, 746)
    _attendance_row(d, 770, 'DM', 'David Mensah', 'Two podcasts a day', True, 'mint')
    note(d, 901, [
        'Learners do not confirm their own reviews.',
        'A missed review can be made up.',
        'Learning continues while make-up is pending.',
    ])
    d.bottom_cta('Confirm attendance', icon='check')
    return d.svg()


def _makeup_option(d, y, date, selected):
    d.rect(16, y, 358, 100, '#FFFFFF', 12, BLUE if selected else LINE)
    d.circle(40, y+29, 9, '#FFFFFF', BLUE if selected else MUTED)
    if selected:
        d.circle(40, y+29, 5, BLUE)
    d.text(60, y+34, date, 14, INK, 500)
    d.text(32, y+62, '6:00–7:00 pm · Lagos (WAT)', 13, MUTED)
    d.text(32, y+84, 'Yaba fellowship hall · Leader: Tolu', 13, MUTED)
    d.raw(f'<rect x="16" y="{y}" width="358" height="100" fill="none" role="radio" aria-label="Make-up session on {date}" aria-checked="{str(selected).lower()}"/>')


def makeup_review():
    d = Draw(1136)
    d.back('Make up a review')
    d.text(16, 132, 'You can make this up', 24, INK, 500, -.5)
    d.chip(16, 154, 'Missed review', 'amber')
    summary(d, 212)
    note(d, 422, [
        'Keep learning while your make-up is pending.',
        'This missed review stays in your history.',
    ])
    d.section(530, 'Choose a make-up session')
    d.text(16, 557, 'For Week 2 · The life of faith', 13, MUTED)
    _makeup_option(d, 579, 'Wed, 14 Oct 2026', True)
    _makeup_option(d, 695, 'Thu, 15 Oct 2026', False)
    d.section(839, 'Attendance status')
    d.chip(16, 857, 'Make-up pending', 'amber')
    d.text(16, 916, 'Choosing a session doesn’t confirm attendance.', 13, MUTED)
    d.text(16, 938, 'The session leader confirms it after the review.', 13, MUTED)
    d.text(16, 984, 'Continue learning', 14, BLUE, 500)
    d.ic('arrow', 350, 967, 20, BLUE)
    d.bottom_cta('Choose this make-up', icon='check')
    return d.svg()


def certification_readiness():
    d = Draw(970)
    d.back('Certification')
    d.text(16, 132, 'Your readiness', 24, INK, 500, -.5)
    d.text(16, 160, 'Amara Okafor · Traditional path', 13, MUTED)
    note(d, 192, [
        'Certification requires review attendance',
        'alongside your learning requirements.',
    ])
    d.section(300, 'Learning')
    d.rect(16, 318, 358, 128, '#FFFFFF', 12, LINE)
    d.text(32, 350, 'Your selected learning path', 15, INK, 500)
    d.chip(32, 368, 'In progress', 'blue')
    d.text(32, 423, 'Continue from your next unfinished lesson.', 13, MUTED)
    d.section(490, 'Weekly group reviews')
    d.rect(16, 508, 358, 182, '#FFFFFF', 12, LINE)
    d.text(32, 540, 'Attendance required', 15, INK, 500)
    d.chip(32, 558, 'Make-up pending', 'amber')
    d.text(32, 613, 'Week 2 · The life of faith', 14, INK)
    d.text(32, 637, 'Confirmed by the session leader after', 13, MUTED)
    d.text(32, 658, 'you attend your make-up review.', 13, MUTED)
    d.text(16, 734, 'View reviews and make-up options', 14, BLUE, 500)
    d.ic('right', 354, 717, 20, BLUE)
    note(d, 772, [
        'Your learning stays available while review',
        'attendance is pending.',
    ])
    d.bottom_cta('Continue learning', icon='arrow')
    return d.svg()


SCREENS = [
    ('Pleros-review-learner-list', 'Learner · Weekly group reviews', learner_reviews),
    ('Pleros-review-discipler-schedule', 'Discipler · Schedule group review', schedule_review),
    ('Pleros-review-leader-attendance', 'Session leader · Confirm attendance', leader_attendance),
    ('Pleros-review-missed-makeup', 'Learner · Choose a make-up review', makeup_review),
    ('Pleros-review-certification', 'Learner · Certification readiness', certification_readiness),
]

if __name__ == '__main__':
    for stem, _, factory in SCREENS:
        render_svg(stem, factory())
    board('Pleros-Group-Review-Operations-Board',
          'One review. Clear responsibilities.',
          'Both learning paths attend weekly group reviews. The discipler schedules; the session leader confirms attendance.',
          [('Learner · Review list', learner_reviews()),
           ('Discipler · Schedule', schedule_review()),
           ('Session leader · Confirm attendance', leader_attendance())],
          'WEEKLY GROUP REVIEWS')
    board('Pleros-Group-Review-Makeup-Board',
          'Make up missed reviews. Keep learning.',
          'A make-up choice is separate from confirmed attendance. Certification reflects the review requirement without an invented target.',
          [('Learner · Choose a make-up', makeup_review()),
           ('Learner · Certification readiness', certification_readiness()),
           ('Learner · Weekly group reviews', learner_reviews())],
          'REVIEW CONTINUITY & CERTIFICATION')
