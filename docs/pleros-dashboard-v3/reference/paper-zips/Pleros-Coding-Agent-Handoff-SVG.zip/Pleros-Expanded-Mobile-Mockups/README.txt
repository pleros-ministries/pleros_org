LEAN SVG HANDOFF
This copy omits redundant rendered PNG previews to reduce attachment size. All 71 editable SVG screens, source generators, fonts, branding assets, design contract and current truth handoff remain included. Run render_all.py to regenerate PNGs.

PLEROS — EXPANDED MOBILE MOCKUPS
13 October 2026

Start with Pleros-Design-Implementation-Contract-2026-10-13.md for implementation rules and design acceptance checks.
Use Pleros-Current-Truth-Addendum-2026-10-13.md for settled product decisions.
Open index.html for the visual gallery.
71 individual mobile screens. Root and new onboarding content can scroll beyond an 844px viewport. Board and phone exports show the full design content.
PNGs are exported at 2×. Phone screens are 390 CSS pixels wide; content heights vary. Boards contain full-content previews.
SVGs are editable. Python source and original logo/font assets are included.
paper_native.py is the optional SVG-to-native-HTML import converter (requires lxml), supplied for typography and import-reference context.

DESIGN CHANGES
- A single-row home header centres the text-only You / Community tabs between menu and notification controls. Profile access lives in the sidebar.
- Home headers omit the redundant logo; centred You / Community tabs remain the primary navigation. Actual Pleros branding is retained on presentation boards and in the asset pack.
- On You, a prominent blue Start SOGP card appears before enrolment; a blue Continue lesson card occupies the learning area once enrolled. White buttons restore the preferred earlier treatment without decorative flourishes.
- SOGP control centre, ownership, referrals and personal enrollee lists.
- Start SOGP → required daily commitment → path preview → tracklist builder (podcast paths) → first day.
- 1 hr/day = traditional one-hour tracks; 30 min/day = two podcasts/day; 15 min/day = one podcast/day.
- Editable 30-day podcast defaults optionally begin with the verified Purpose series: 60 episode slots for the 30-minute path, 30 slots for the 15-minute path.
- The You learning card and player depend on the selected path, with saved playback positions for each content item.
- Status pills use a stronger pastel adaptation of verified EOS web semantic colours. Amber marks pending states, green marks completed states, and neutral labels retain Nil/Not reported/Unlinked distinctions. The shared palette is in pill-palette.json.
- Canonical Lucide icons use a constant 1.75px visible stroke at 16/20/24px. Decorative sun, stars, orbital curves and lesson artwork are removed.
- Major section gap 32px, heading-to-content 12px, within-section gaps 12/16px; scrolling is allowed. Home uses 20px gutters/card padding. Primary actions are 48px high.
- Unified Evangelism/Discipleship entry and inline Add contact, with optional outcomes still proposed.
- Leader-first shared meetings: the person who led creates the record; workers and disciples select it and report personal attendance/people brought without editing meeting details. Teaching has Meeting subject; Prayer has venue/time and no subject. Total attendance is creator-only. Missing records show Meeting not listed yet.
- Pastor, branch pastor, unit leader and ordinary worker views.
- Saved contacts, proposed editable contact collections, and a move flow retaining history.

INTERACTION BOUNDARIES
- Code join: automatic assignment to the code owner, without the link-specific acceptance prompt.
- Link join: automatic assignment to the link owner, followed by Accept / Request someone else.
- Follow-up assignment and accepted group membership are separate.
- Pastor manages all branches. Branch pastors manage their assigned branches. Unit leaders view direct workers; they do not appoint leaders or assign workers. Workers see their own placement/reports.
- Church hierarchy does not grant access to private discipleship notes, check-ins or contact history.
- Name and phone are required for saved contacts; email is optional. Contacts are private initially. Saving/moving does not automatically send a message, create an account or accept group membership.
- Existing accounts receive in-app group invitations; non-account contacts can receive a WhatsApp invitation link. Membership requires explicit acceptance.
- Direct SOGP joins route to their geographical leader. Current follow-up continues while reassignment is pending.
- Weekly group reviews are required for both paths and certification. Discipler schedules; session leader confirms attendance. Make-up does not block learning. No certificate threshold is invented.
- Missed learning waits. Path switching preserves history; one/two podcast pace changes regroup remaining content. Traditional and podcast completion do not automatically transfer.
- Each podcast episode has its own listened mark; two-episode days require both. Questions are optional; no podcast quiz/reflection is required.
- See CONSOLIDATION-REVIEW.md for design boundaries and retained-product mapping.
- Contact collections are private organisational labels, separate from community and discipleship groups. Collection names are editable examples. Bulk import is an optional proposed alternative to four-step branch, branch-pastor, unit-leader and worker setup.

People, counts and contact details are synthetic examples. Branch and group labels are informed by repository fixtures; no live database was read. Fullness of Christ Church and Pleros are the product context. No live enrolments, assignments, contacts or permissions were changed.

BRAND SOURCE
Repository: pleros-ministries/pleros_org
Commit: 939482b3d5aa8ba4486f580ee92662c2fd5dfb09
Asset: public/site/sogp/pleros-logo-dark.png
https://github.com/pleros-ministries/pleros_org/blob/939482b3d5aa8ba4486f580ee92662c2fd5dfb09/public/site/sogp/pleros-logo-dark.png

RENDERING
Requires Python 3 and Inkscape. Run python3 render_all.py. Be Vietnam Pro font files are included. For design editing, open the SVGs directly in a vector editor.
