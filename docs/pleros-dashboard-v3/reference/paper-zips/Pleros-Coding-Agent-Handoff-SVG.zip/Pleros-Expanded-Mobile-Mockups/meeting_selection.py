"""Shared-meeting selection concepts for workers and disciples.

A meeting is created by the person who led it. Choosing a meeting opens the
person's own report; it does not confirm attendance. Missing meetings have no
creation, request, or notification action. All displayed people are fictional.
"""
from core import Draw, BLUE, INK, MUTED, LINE, SOFT, render_svg


def intro(d):
    d.back('Meeting report')
    d.text(16, 132, 'Choose a meeting', 24, INK, 500, spacing=-.5)
    d.text(16, 159, 'For workers and disciples. Choose a meeting', 13, MUTED)
    d.text(16, 179, 'created by the person who led it.', 13, MUTED)


def search(d, query=None):
    d.rect(16, 211, 358, 48, SOFT, 11)
    d.ic('search', 32, 225, 20, MUTED)
    d.text(64, 241, query or 'Search meetings or venues', 14, INK if query else MUTED)
    if query:
        d.hit(326, 213, 'Clear search')
        d.ic('close', 338, 227, 16, MUTED)
    d.raw('<rect x="16" y="211" width="310" height="48" fill="none" role="searchbox" aria-label="Search meetings or venues"/>')


def meeting(d, y, kind, title, time, creator):
    prayer=kind=='Prayer';height=240 if prayer else 176
    d.rect(16,y,358,height,'#FFFFFF',14,LINE)
    d.chip(32,y+16,kind,'lilac' if kind=='Teaching' else 'blue')
    d.text(32,y+78,title,20,INK,500,spacing=-.3);d.ic('right',342,y+59,20,MUTED)
    d.ic('calendar',32,y+97,16,MUTED);d.text(60,y+111,'Tuesday, 13 Oct 2026',13,MUTED)
    if prayer:
        d.ic('clock',32,y+129,16,MUTED);d.text(60,y+143,time,13,MUTED)
        d.ic('building',32,y+161,16,MUTED);d.text(60,y+175,'Yaba fellowship hall, Lagos',13,MUTED)
    line_y=y+(192 if prayer else 128)
    d.line(32,line_y,358,line_y);d.ic('people',32,line_y+15,16,MUTED)
    d.text(60,line_y+30,'Created by '+creator,13,MUTED)
    d.raw(f'<rect x="16" y="{y}" width="358" height="{height}" fill="none" rx="14" role="button" aria-label="Select {title}; meeting details are read-only"/>')


def selection():
    d=Draw(844)
    intro(d)
    search(d)
    d.section(300, 'Existing meetings')
    d.text(374, 300, '2 meetings', 13, MUTED, anchor='end')
    meeting(d, 320, 'Teaching', 'The life of faith', None, 'Ruth Akinola')
    meeting(d, 512, 'Prayer', 'Prayer meeting', '6:00–7:15 pm · Lagos (WAT)', 'Kunle Adebayo')
    d.ic('shield', 16, 778, 16, MUTED)
    d.text(44, 792, 'Choose a meeting to open your own report.', 13, MUTED)
    d.text(44, 812, 'You’ll confirm your attendance there.', 13, MUTED)
    d.bottom()
    return d.svg()


def missing():
    d=Draw(844)
    intro(d)
    search(d, 'Yaba evening meeting')
    d.circle(195, 361, 38, SOFT)
    d.ic('calendar', 181, 347, 28, MUTED)
    d.text(195, 438, 'Meeting not listed yet', 23, INK, 500, spacing=-.5, anchor='middle')
    for i, text in enumerate([
        'The person who led the meeting must',
        'create it before you can add your report.',
        'Return later to select it.',
    ]):
        d.text(195, 473+i*22, text, 14, MUTED, anchor='middle')
    d.btn(16, 565, 358, 'Back to meetings', 'left', h=48)
    d.bottom()
    return d.svg()


SCREENS = [
    ('Pleros-report-meeting-select', 'Choose an existing meeting', selection),
    ('Pleros-report-meeting-missing', 'Meeting not listed yet', missing),
]

if __name__ == '__main__':
    for stem, _, factory in SCREENS:
        render_svg(stem, factory())
