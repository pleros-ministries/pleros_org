from pathlib import Path
from html import escape
import base64, subprocess, os, re
p=Path(__file__).resolve().parent
import json
icons = json.loads((p/'assets/lucide-icons.json').read_text())

BLUE="#2056D6"; INK="#252B33"; MUTED="#63676D"; LINE="#E7E9EC"; SOFT="#F6F7F8"; CANVAS="#FFFFFF"; SURFACE="#FFFFFF"
PILL_STYLES = json.loads((p/'pill-palette.json').read_text())['styles']

class Draw:

    def __init__(self, height=844):
        self.a = []
        self.height = height
        self._root_content_open = False

    def raw(self, s):
        self.a.append(s)

    def rect(self, x, y, w, h, fill='#fff', r=0, stroke=None, sw=1):
        self.a.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}"' + (f' stroke="{stroke}" stroke-width="{sw}"' if stroke else '') + '/>')

    def text(self, x, y, s, size=12, color=INK, weight=400, spacing=None, anchor=None):
        weight = min((400, 500, 600, 700), key=lambda w: abs(w-weight)) if weight != 550 else 600
        self.a.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{weight}"' + (f' letter-spacing="{spacing}"' if spacing else '') + (f' text-anchor="{anchor}"' if anchor else '') + '>' + escape(s) + '</text>')

    def line(self, x, y, x2, y2, color=LINE, sw=1):
        self.raw(f'<path d="M{x} {y}H{x2}" stroke="{color}" stroke-width="{sw}"/>' if y == y2 else f'<path d="M{x} {y}L{x2} {y2}" stroke="{color}" stroke-width="{sw}"/>')

    def circle(self, x, y, r, fill, stroke=None):
        self.raw(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}"' + (f' stroke="{stroke}"' if stroke else '') + '/>')

    def ic(self, n, x, y, size=20, color=MUTED):
        old_size=size
        size=24 if n in ('play','pause','rewind','forward') else (16 if size<=18 else 20)
        x+=(old_size-size)/2;y+=(old_size-size)/2
        self.raw(f'<svg x="{x}" y="{y}" width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" color="{color}" stroke="{color}" stroke-width="{1.75*24/size:g}" stroke-linecap="round" stroke-linejoin="round" data-icon="lucide-{n}">{icons[n]}</svg>')

    def hit(self,x,y,label):
        self.raw(f'<rect x="{x}" y="{y}" width="44" height="44" fill="none" role="button" aria-label="{label}"/>')

    def av(self,x,y,initials,color='blue',size=36):
        fills={'blue':('#E8EEF7','#4B6584'),'mint':('#EDF2EB','#52694D'),'apricot':('#F6EFE2','#785B2C'),'lilac':('#F0ECF3','#756580')};bg,fg=fills[color]
        self.circle(x+size/2,y+size/2,size/2,bg);self.text(x+size/2,y+size*.63,initials,12 if size<45 else 16,fg,500,anchor='middle')

    def chip(self,x,y,s,style='blue',w=None):
        token=PILL_STYLES[style];bg,fg=token['background'],token['text']
        w=max(w or 0,len(s)*6.8+16);self.rect(x,y,w,26,bg,6);self.text(x+8,y+18,s,12,fg,500);return w

    def tile(self,n,x,y,style='blue',size=36):
        self.ic(n,x+(size-20)/2,y+(size-20)/2,20,MUTED)

    def btn(self,x,y,w,s,icon='arrow',fill=BLUE,color='#fff',h=44):
        h=max(48,h);self.rect(x,y,w,h,fill,11);self.text(x+16,y+(h+14)/2-1,s,14,color,500)
        if icon:self.ic(icon,x+w-36,y+(h-20)/2,20,color)

    def section(self,y,s,link=None):
        self.text(16,y,s,15,INK,500)
        if link:self.text(374,y,link,13,BLUE,500,anchor='end')

    def base(self, left_clock=True):
        self.rect(0, 0, 390, self.height, CANVAS)
        if left_clock:self.text(27, 26, '9:41', 13, INK, 600)
        self.raw('<path d="M292 20h3v6h-3zm5-3h3v9h-3zm5-3h3v12h-3zm5-3h3v15h-3z" fill="#172B47"/>')
        self.raw('<path d="M318 16q8-7 16 0m-13 4q5-4 10 0m-7 3q2-2 4 0" fill="none" stroke="#172B47" stroke-width="2" stroke-linecap="round"/>')
        self.rect(341, 13, 22, 12, 'none', 3, INK)
        self.rect(343, 15, 18, 8, INK, 1.5)
        self.rect(365, 17, 2, 4, INK, 1)

    def bottom(self):
        if self._root_content_open:
            self.raw('</g>');self._root_content_open=False
        self.rect(0, self.height-27, 390, 27, CANVAS)
        self.rect(135, self.height-12, 120, 4, '#1D2E48', 3)

    def logo(self, x, y, w=78):
        b64=base64.b64encode((p/'assets/pleros-logo-dark.png').read_bytes()).decode()
        self.raw(f'<image x="{x}" y="{y}" width="{w}" height="{w*292/518}" xlink:href="data:image/png;base64,{b64}"/>')
    def root(self,selected):
        # Compact single-row shell. Remove the former44px tab row from body flow.
        self.height=max(844,self.height-44)
        self.base();self.hit(4,42,'Open menu');self.hit(338,42,'Notifications')
        self.ic('menu',16,54,20,INK);self.ic('bell',350,54,20,INK);self.circle(367,54,2.5,BLUE)
        for key,label,cx,x,w in [('you','You',132,96,72),('community','Community',236,178,116)]:
            active=selected==key
            self.raw(f'<g role="tab" aria-selected="{str(active).lower()}">')
            self.rect(x,41,w,44,'none',8)
            self.text(cx,68,label,14,INK if active else MUTED,600 if active else 400,anchor='middle')
            self.raw('</g>')
        self.raw('<g transform="translate(0,-44)">');self._root_content_open=True
    def label(self,y,s):self.text(16,y,s,12,MUTED,500,.3)

    def field(self,y,label,value='',placeholder=False,right=None):
        self.text(16,y,label,13,INK,500);self.rect(16,y+12,358,44,SURFACE,11,LINE);self.text(32,y+40,value,16,MUTED if placeholder else INK)
        if right:self.ic(right,342,y+26,16,MUTED)

    def note(self,y,lines,style='blue',icon='shield'):
        colors={'blue':(SOFT,MUTED),'amber':('#F6EFE2','#785B2C'),'green':('#EDF2EB','#52694D')};bg,fg=colors[style]
        self.rect(16,y,358,len(lines)*20+24,bg,12);self.ic(icon,32,y+14,16,fg)
        for i,line in enumerate(lines):self.text(60,y+25+i*20,line,13,fg)

    def bottom_cta(self,label,sub=None,icon='check'):
        offset=self.height-844
        self.rect(0,offset+(728 if sub else 748),390,90 if sub else 70,CANVAS);self.line(16,offset+(729 if sub else 749),374,offset+(729 if sub else 749))
        if sub:self.text(195,offset+750,sub,12,MUTED,anchor='middle')
        self.btn(16,offset+764,358,label,icon,h=44);self.bottom()
    def row(self,y,title,sub=None,initials=None,color='blue',icon=None,tag=None):
        if initials:self.av(16,y,initials,color,36)
        elif icon:self.tile(icon,16,y,color,36)
        self.text(64,y+15,title,14,INK,500);self.text(64,y+36,sub or '',13,MUTED);self.ic('right',354,y+10,16,MUTED)
        if tag:self.chip(280,y+5,tag)

    def search(self,y,label='Search people'):
        self.rect(16,y,358,44,SOFT,11);self.ic('search',32,y+14,16,MUTED);self.text(60,y+29,label,14,MUTED)

    def back(self,title):
        self.base();self.hit(4,42,'Back');self.hit(340,42,'More options');self.ic('left',16,54,20,INK);self.text(195,71,title,14,INK,500,anchor='middle');self.ic('more',352,54,20,INK);self.line(16,90,374,90)

    def svg(self):
        return f'<metadata data-content-height="{self.height}"/>'+''.join(self.a)

def page_svg(content,w=390,h=844):
    if w==390 and h==844:h=content_height(content)
    return f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{w}" height="{h}" viewBox="0 0 {w} {h}" font-family="Be Vietnam Pro, sans-serif">{content}</svg>'
def render_svg(name,content,w=390,h=844,scale=2):
    if w==390 and h==844:h=content_height(content)
    (p/'fonts.conf').write_text(f'<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><dir>{p}/assets</dir><dir>/usr/share/fonts</dir><cachedir>/tmp/pleros-font-cache</cachedir></fontconfig>')
    src=p/(name+'.svg');src.write_text(page_svg(content,w,h));r=subprocess.run(['inkscape',str(src),'--export-type=png',f'--export-width={w*scale}',f'--export-filename={p/(name+".png")}'],capture_output=True,text=True,env={**os.environ,'FONTCONFIG_FILE':str(p/'fonts.conf')});print(name,r.returncode,flush=True)
    if r.returncode: print(r.stderr[-1500:])
def content_height(content):
    m=re.search(r'data-content-height="(\d+)"',content)
    return int(m.group(1)) if m else 844

def board(name,title,subtitle,screen_items,section='ROLE FLOWS'):
    max_h=max(content_height(c) for _,c in screen_items);board_h=max_h+276
    d=Draw();d.rect(0,0,1440,board_h,'#F6F7F8');d.text(66,51,'PLEROS / '+section,9,'#7187A6',600,1.5);d.text(66,91,title,30,INK,500,spacing=-.6);d.text(66,118,subtitle,12,'#7E93AF');d.logo(1300,41,75)
    for i,(label,content) in enumerate(screen_items):
        x=66+i*459;y=153;h=content_height(content);d.rect(x-1,y-1,392,h+2,LINE,32);d.raw(f'<defs><clipPath id="phone-{i}"><rect x="0" y="0" width="390" height="{h}" rx="31"/></clipPath></defs><g transform="translate({x},{y})"><g clip-path="url(#phone-{i})">{content}</g></g>');d.text(x+2,max_h+185,f'{i+1:02}',9,'#99AAC0',500);d.text(x+31,max_h+185,label,12,'#526D8F',500)
    d.text(66,max_h+237,'DESIGN CONCEPT · FICTIONAL PEOPLE AND DEMO DATA',8,'#93A5BC',500,.3);d.text(1374,max_h+237,'PLEROS / MOBILE FIRST',8,'#93A5BC',500,.5,anchor='end');render_svg(name,d.svg(),1440,board_h)
