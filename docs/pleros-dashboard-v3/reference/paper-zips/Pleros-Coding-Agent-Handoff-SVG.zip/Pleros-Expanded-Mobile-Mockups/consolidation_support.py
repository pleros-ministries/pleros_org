"""Settled SOGP dashboard, personal referrals and reassignment request states."""
from core import *

def my_sogp():
    d=Draw(height=1130);d.back('My SOGP')
    d.text(16,137,'Your learning, your pace',24,INK,500)
    d.text(16,166,'Your current plan and history stay with you.',14,MUTED)
    d.rect(16,198,358,196,BLUE,16)
    d.text(36,230,'30 min/day · Podcast path',13,'#E1EAFF')
    d.text(36,269,'Day 4 is waiting for you',21,'#FFFFFF',500)
    d.text(36,299,'1 of 2 episodes marked listened',14,'#E1EAFF')
    d.btn(36,326,318,'Resume learning','play',fill='#FFFFFF',color=BLUE)
    d.text(16,430,'Missed a day? Your next listen waits.',14,INK)
    d.text(16,454,'Unfinished episodes are never skipped.',13,MUTED)
    for y,title,sub in [(494,'Your tracklist','Edit episodes or switch your path'),(574,'Learning history','7 episodes listened · Positions saved'),(654,'Weekly group reviews','Required on traditional and podcast paths')]:
        d.text(16,y,title,15,INK,500);d.text(16,y+24,sub,13,MUTED);d.ic('right',350,y-4,16,MUTED);d.hit(338,y-16,title);d.line(16,y+44,374,y+44)
    d.section(752,'Your follow-up person')
    d.av(16,776,'ED','mint',36);d.text(64,792,'Efe Daniels',14,INK,500);d.text(64,816,'Lagos · Assigned by your location',13,MUTED)
    d.text(16,850,'Joined directly · Geographical leader',13,MUTED)
    d.rect(16,870,358,48,'#FFFFFF',11,LINE);d.text(32,901,'Request someone else',14,BLUE,500);d.ic('right',338,886,16,BLUE)
    d.section(966,'Invite someone to SOGP')
    d.text(16,992,'Your personal referral code and link',13,MUTED)
    d.btn(16,1016,358,'Share my referral','arrow')
    d.bottom();return d.svg()

def share_referral():
    d=Draw(height=1000);d.back('Your SOGP referral')
    d.text(16,137,'Grow with someone',24,INK,500)
    d.text(16,166,'Your own code and link, ready to share.',14,MUTED)
    d.section(218,'Your referral code')
    d.rect(16,242,358,108,SOFT,16);d.text(36,282,'TOLU26',24,INK,500);d.text(36,316,'Copy code',14,BLUE,500);d.ic('right',338,298,16,BLUE)
    d.text(16,390,'Code joins are assigned to you.',14,INK)
    d.section(452,'Your referral link')
    d.rect(16,476,358,92,'#FFFFFF',12,LINE);d.text(32,506,'Your personal invitation link',14,INK,500);d.text(32,542,'Copy link',14,BLUE,500);d.ic('right',338,525,16,BLUE)
    d.text(16,610,'Link joins are assigned to you, then asked',14,INK)
    d.text(16,632,'to accept you or request someone else.',14,INK)
    d.note(676,['Following up and group membership','are separate. Group invitations need','the person’s acceptance.'],'blue','people')
    d.text(16,802,'Available to every SOGP enrollee.',13,MUTED)
    d.bottom_cta('Share referral link',icon='arrow');return d.svg()

def request_reassignment():
    d=Draw(height=920);d.back('Your follow-up person')
    d.text(16,137,'Request someone else',24,INK,500)
    d.text(16,166,'Tell a coordinator what would help.',14,MUTED)
    d.rect(16,198,358,108,SOFT,16);d.av(32,218,'ED','mint',36);d.text(80,235,'Efe Daniels',14,INK,500);d.text(80,258,'Your current follow-up person',13,MUTED);d.text(32,287,'Assigned by location · Lagos',13,MUTED)
    d.text(16,350,'Reason for your request',13,INK,500)
    d.rect(16,362,358,152,'#FFFFFF',11,LINE);d.text(32,394,'I’d prefer someone who can meet',16,INK);d.text(32,420,'with me in the evening.',16,INK)
    d.section(562,'While your request is reviewed')
    d.text(16,594,'Efe continues to follow up with you',14,INK)
    d.text(16,616,'until a coordinator changes the assignment.',14,INK)
    d.text(16,652,'Your learning and history continue.',14,MUTED)
    d.note(690,['This request does not change','your accepted group memberships.'],'blue','people')
    d.bottom_cta('Send reassignment request',icon='arrow');return d.svg()

SCREENS=[('Pleros-my-sogp',my_sogp),('Pleros-share-referral',share_referral),('Pleros-request-reassignment',request_reassignment)]
if __name__=='__main__':
    for name,fn in SCREENS:render_svg(name,fn())
    board('Pleros-Consolidated-Support-Board','Your path. Your support.','Continue where you left off, share your referral and request a different follow-up person.', [('My SOGP · Direct join',my_sogp()),('Every enrollee · Share referral',share_referral()),('Dashboard · Request reassignment',request_reassignment())], 'SOGP / EVERYDAY SUPPORT')
