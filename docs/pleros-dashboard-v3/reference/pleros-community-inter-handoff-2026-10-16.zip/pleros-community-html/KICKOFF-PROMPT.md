# Ready-to-paste implementation prompt

Implement the retained Pleros Community redesign from `/Users/letroot/Documents/Codex/2026-10-16/task/pleros-community-html` in the Pleros repository. First read `README.md`, `FIDELITY-CONTRACT.md`, and `HANDOFF.md`, then inspect the current branch and all mapped source files again before editing because behavior and permissions may have moved.

Use the standalone HTML/CSS and `screenshots/` as the visual source, with `references/` only for approved You/feed composition continuity. Daniel’s latest typography decision is authoritative: use the existing `components/dashboard/v3/font.ts` Inter variable configuration with optical sizing. Do not use Be Vietnam Pro, synthesize weights, or create a competing token system.

Preserve all current routes, actions, permissions, privacy, server checks, errors, pagination, and conditional visibility. In particular: peers expose only first name/join month/coarse stage; under-18 members remain excluded from messaging with the server-side eligibility recheck; blocking is not disclosed; Report targets one incoming message; restricted sending uses the server-provided reason; Share/Message/composer/moderation/leader actions retain current guards; Ask Pleros anonymity remains structurally isolated.

Resolve the header mismatch by restyling inner Community routes into the shared white v3 contextual header while preserving title/dropdown destinations, Messages access, unread state, centered You/Community navigation, notifications, and focused-thread back/options. Add no navigation destinations.

Implement mobile-first, then verify at 320, 390, and 430 CSS pixels: no horizontal overflow, all visible interactive targets at least 44 × 44, visible keyboard focus, no clipped primary action, and the approved Inter 400/500 weight system (400 body, 500 hierarchy/actions; no default 600/700). Compare screenshots for You, feed, unit, messages, new-message dialog, conversation, restricted conversation, and post detail. Run focused tests for the preserved permission and privacy paths before claiming completion.

Do not overwrite unrelated dirty work, switch branches, pull over ongoing work, create fixtures with real private data, weaken guards, or deploy without separate authorization.

