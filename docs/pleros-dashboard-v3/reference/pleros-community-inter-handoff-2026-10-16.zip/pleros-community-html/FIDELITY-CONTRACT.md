# Fidelity contract

## Reference precedence

Use sources in this order when they disagree:

1. Daniel’s latest explicit decisions, including **Inter variable with optical sizing**.
2. Current behavior and permissions in `codex/dashboard-v3-baseline` at inspected commit `9173bc8bb5d71c997d58860486a8963ca0ed4f8d`.
3. These standalone mockups and their screenshots.
4. Approved You/feed Paper checkpoints in `references/` for composition and palette continuity.
5. The 2026-10-13 addendum, implementation contract, and older Paper/reference-pack material.

The older Be Vietnam Pro styling is stale. Do not carry it into implementation.

## Typography

- Family: Inter, variable weight 100–900, optical sizing enabled.
- Production configuration: `components/dashboard/v3/font.ts` using `next/font/google`, `weight: "variable"`, `axes: ["opsz"]`.
- Body: 14px with 1.5 line-height unless a component role below overrides it.
- Contextual title: 18px / 26px, 500.
- Card/section titles: 15–16px / 22–24px, 500, `letter-spacing: -0.02em`.
- Identity names: 13px / 20px, 500.
- Compact actions: 12px / 18px, 500.
- Status badges: 10–11px, 500.
- Approved weight system: 400 body/copy and 500 hierarchy/actions. No default 600 or 700 role.
- Do not synthesize missing weights or silently fall back to another family.

## Shared visual rules

- Canvas: `#F6F7F8`.
- Surface: `#FFFFFF`.
- Primary text: `#252B33`.
- Secondary text: `#63676D`.
- Uniform edge: `#E7E9EC`.
- Functional action/state blue: `#2056D6`; dark interaction state `#1948B8`.
- Soft blue pair: `#E4EBFD` / `#2331AE`.
- Soft violet pair: `#E9DFFA` / `#6D28D9`.
- You status violet: `#DEC8FA` / `#56209C`.
- You status green: `#D8F7BD` / `#205E20`.
- Cards: 16px radius, one uniform 1px edge, no directional rail and no heavy shadow.
- Context header: white, one neutral bottom edge, no legacy blue bar.
- Interactive pill: visible 28px capsule, 10px horizontal inset, inside an actual non-overlapping 44px target.
- Noninteractive status badge: 18–20px high and content-snug.
- Icon-only actions, tabs, inline text actions, and dialog actions: at least 44 × 44 actual target.
- Focus: visible 3px `rgba(32,86,214,.24)` ring.

## Responsive and capture contract

- Mobile-first baseline: 390 × 844 CSS pixels.
- Verified widths: 320, 390, and 430 CSS pixels.
- Acceptance at each width: no horizontal document overflow, no clipped primary action, and no visible interactive target under 44 × 44.
- Default content gutter is 16px; You learning surface preserves its approved composition.
- Keep text reflow natural. Do not reduce type below the roles above to force a single line.
- The post-detail screen is vertically scrollable; the 844px screenshot intentionally shows the first viewport.

## Header and state contract

- Preserve centered You/Community destinations and notifications access.
- Inner Community routes preserve contextual title/dropdown, Messages destination, and unread state.
- Use the same header geometry on feed, unit, messages, and post detail.
- Conversation retains its focused thread header, back action, participant/unit context, and options.
- Blue is functional, not decorative: active tab, unread, official, selected/liked, and primary actions only.

## Verification record

- Every screen loaded the bundled Inter family with `document.fonts.status === "loaded"`.
- `document.fonts.check` passed for the approved 400 and 500 roles on every screen.
- Computed `font-family` was `Inter`; no element computed to Be Vietnam Pro.
- Context title computed to 18/26 at weight 500; headings computed to 500 with −2% tracking.
- Keyboard Tab focus produced the specified visible ring.
- 320/390/430 width audit found no horizontal overflow and zero undersized visible interactive targets.

