# Implementation handoff

## Boundary and inspected baseline

Design only. No application file, branch, commit, remote, or deployment was changed.

The local repository inspected was `/Users/letroot/code/fcc/pleros_org`, on `codex/dashboard-v3-baseline` at `9173bc8bb5d71c997d58860486a8963ca0ed4f8d`, exactly matching its tracked remote at inspection time. Existing dirty and untracked work was left untouched.

Inspected sources included:

- live/recorded v3 Community home and retained feed/unit/messages evidence under `docs/pleros-dashboard-v3/evidence/`;
- `/tmp/pleros-v3-design/Pleros-Expanded-Mobile-Mockups`, including `screen-index.json`, the 2026-10-13 addendum, and implementation contract;
- `app/globals.css`, v3 shell/primitives, `components/dashboard/v3/font.ts`, and the current Inter build output;
- `components/community/community-hub.tsx`, `community-sidebar.tsx`, `post-card.tsx`, and `community-unit-page.tsx`;
- `components/community/messages/conversation-list.tsx`, `messages-shell.tsx`, `message-thread.tsx`, and `new-message-dialog.tsx`;
- the feed, unit, messages, conversation, and post-detail route surfaces.

## Screen-to-component/action mapping

| Mockup | Existing implementation contract preserved |
| --- | --- |
| `you` | Approved v3 You composition, centered area tabs, notifications, lesson progress and actions, plan/review rows and states, support contact. Only the requested snug badges and stronger approved violet/green state differentiation are added. |
| `feed` | `community-hub.tsx`: composer, All/Official/Discussions filters, sort, loading/error/empty flow. `post-card.tsx`: author metadata, official/pinned states, overflow, counts, Like, Comment, Share, report, and existing moderator-only actions. |
| `unit` | `community-unit-page.tsx`: unit name/count, pastor/leader context, Message leader, Discussions/Members/About tabs, conditional composer, discussion cards, and existing leader/admin controls. Telegram/About destinations remain unchanged. |
| `messages` | `conversation-list.tsx`: New message, participant/unit context, preview, timestamp, unread badge, empty/error states, and open-conversation navigation. |
| `messages&state=new-message` | `new-message-dialog.tsx`: first-name search, eligible-result presentation, and conversation creation. The helper states that only eligible contacts appear; UI is not a substitute for the existing server recheck. |
| `conversation` | `messages-shell.tsx` and `message-thread.tsx`: back, participant/unit identity, options, load earlier, incoming/outgoing bubbles, timestamps, composer, send, per-incoming-message Report, and block/unblock option. |
| `conversation&state=restricted` | Same thread with the composer replaced by the current server-provided restriction reason. Do not hard-code the sample reason. |
| `post` | `/dashboard/community/post/[postId]` in shared `post-card.tsx` language: post metadata/state/counts/actions, comments, conditional Message/Report/moderation actions, and comment composer. Share remains subject to the existing global/unit rule. |

## Header resolution

The legacy inner-route solid blue `CommunityTopBar` is replaced visually by the shared v3 white contextual header. This is a restyle, not a routing change. Preserve:

- the current contextual title;
- the existing title/dropdown destinations;
- Messages access and unread count;
- centered You/Community destinations and notifications;
- focused-thread back/options behavior.

Do not add navigation destinations.

## Privacy, permissions, and conditional states

These are behavior requirements, not sample-copy suggestions:

- Peer identity exposes first name, join month, and coarse stage only.
- Under-18 members remain excluded from message search; keep the current server-side eligibility recheck when starting a conversation.
- Blocking is not disclosed to the other participant.
- Report acts on one incoming message, never the entire conversation.
- A send restriction uses the server-provided reason and replaces the composer.
- Composer, Message, Share, leader, moderator, and report controls remain conditional on current implementation checks. Do not infer permissions from the mock data.
- Ask Pleros anonymity is structurally isolated and untouched. Never reuse peer/message identity UI inside Ask Pleros or expose responder identity.
- Existing message/report visibility and unit membership checks remain authoritative.

## Mock data versus behavior

Names, timestamps, counts, unit names, post copy, lesson progress, and unread values in this artifact are representative only. The design shows layout and state treatment. It does not authorize fixture creation, persistence changes, new permissions, or new destinations.

The mockup JavaScript demonstrates menus/dialogs and screen states only. Production implementation must reuse existing mutations, queries, guards, errors, focus management, pagination, and optimistic-state behavior after a fresh source audit.

## Implementation acceptance checklist

- Use the existing v3 shell and tokens; do not introduce a second production token system.
- Use `dashboardFont`/Inter variable with optical sizing. Older Be Vietnam Pro references are superseded.
- Match `FIDELITY-CONTRACT.md` at 320, 390, and 430px.
- Preserve every action and conditional state mapped above.
- Exercise ordinary learner, under-18 restriction, blocked/restricted sending, unread, incoming-message reporting, unit posting permission, and moderation visibility with safe fixtures or mocks.
- Confirm Ask Pleros remains anonymous through data flow and rendered output.
- Compare implementation screenshots with every file under `screenshots/` and the approved composition checkpoints under `references/`.
- Run relevant focused tests and accessibility checks before claiming functional completion.

## Paper status and remaining reconciliation

Paper file `01M4TACCHKAMJY1BYTABRBNBMS`, page `23 · Community content`, remains useful historical context, but the finished standalone artifact is the current design handoff.

Paper’s weekly MCP quota prevented completing and re-verifying all retained screens there. The verified feed checkpoint exists; the unit insertion was not visually verified; messages/conversation/post remained incomplete shells. Two native-UI fallback message-list vectors (`Mobile messages list` and `White message list`) are stale and unverified. Reconcile or remove those when Paper access returns. Do not treat them as approved implementation input.

## Missing or intentionally unverified inputs

- The attached image library ID supplied at the beginning was optional context; current implementation remained the source of truth.
- No live database writes or permission-changing actions were performed, so functional persistence and negative permission paths were not re-tested in this design-only task.
- No application build, tests, commit, push, or deployment was performed.

