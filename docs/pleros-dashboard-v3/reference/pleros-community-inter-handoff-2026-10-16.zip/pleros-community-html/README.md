# Pleros retained Community mockups

Standalone mobile-first HTML/CSS mockups for the retained Pleros Community surfaces. This folder is a design and implementation-handoff artifact; it does not modify the application repository.

## Open locally

From this directory:

```sh
python3 -m http.server 8765 --bind 127.0.0.1
```

Then open `http://127.0.0.1:8765/?screen=feed`.

## Screens

| Screen | URL |
| --- | --- |
| Updated You home | `?screen=you` |
| Community feed | `?screen=feed` |
| Community unit | `?screen=unit` |
| Messages list | `?screen=messages` |
| Conversation | `?screen=conversation` |
| Post detail | `?screen=post` |
| New-message dialog | `?screen=messages&state=new-message` |
| Restricted conversation | `?screen=conversation&state=restricted` |

The left-hand prototype navigator appears on wider viewports. At mobile widths the requested screen fills the viewport.

## Included evidence

- `screenshots/`: verified 780 × 1688 exports (2× captures of a 390 × 844 CSS viewport) for every listed screen/state.
- `references/`: the prior approved Paper checkpoints for You and Community feed.
- `FIDELITY-CONTRACT.md`: visual and responsive implementation rules.
- `HANDOFF.md`: exact component/action and privacy mapping.
- `KICKOFF-PROMPT.md`: ready-to-paste implementation-agent prompt.

## Current source of truth

Daniel’s latest decision is authoritative: authenticated dashboard typography is **Inter variable with optical sizing**, using 400 for body/copy and 500 for emphasis, headings, names, buttons, selected tabs, pills, and the feed switcher. There is no default 600/700 role. This supersedes older Be Vietnam Pro references in Paper and the supplied reference pack. `assets/fonts/Inter-Variable-Latin.woff2` is the exact Latin variable asset emitted by the current local build configured in `components/dashboard/v3/font.ts`; the mockup has no Be Vietnam Pro asset or fallback typography.

