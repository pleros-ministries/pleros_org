const params = new URLSearchParams(location.search);
const requested = params.get('screen') || location.hash.replace('#','') || 'feed';
const capture = params.get('capture') === '1';
const requestedState = params.get('state') || 'default';

const screens = [...document.querySelectorAll('.screen')];
const links = [...document.querySelectorAll('[data-screen-link]')];

function showScreen(name) {
  const safe = screens.some((screen) => screen.dataset.screen === name) ? name : 'feed';
  screens.forEach((screen) => {
    const active = screen.dataset.screen === safe;
    screen.classList.toggle('is-active', active);
    screen.setAttribute('aria-hidden', String(!active));
    screen.dataset.state = active ? requestedState : 'default';
  });
  links.forEach((link) => link.setAttribute('aria-current', link.dataset.screenLink === safe ? 'page' : 'false'));
  document.title = `Pleros · ${safe.replace('-', ' ')}`;
}

if (capture) document.body.classList.add('capture');
showScreen(requested);

document.addEventListener('click', (event) => {
  const switcher = event.target.closest('[data-header-switcher]');
  if (switcher) {
    const menu = switcher.parentElement.querySelector('.header-menu');
    const open = !menu.classList.contains('is-open');
    document.querySelectorAll('.header-menu').forEach((item) => item.classList.remove('is-open'));
    menu.classList.toggle('is-open', open);
    switcher.setAttribute('aria-expanded', String(open));
    return;
  }

  const action = event.target.closest('[data-action]')?.dataset.action;
  if (action === 'new-message') openDialog('new-message-dialog');
  if (action === 'report-message') openDialog('report-dialog');
  if (action === 'thread-options') {
    const popover = document.querySelector('[data-thread-popover]');
    popover.classList.toggle('is-open');
  }
  if (action === 'close-dialog') closeDialogs();
  if (action === 'toggle-restricted') {
    const thread = document.querySelector('[data-screen="conversation"]');
    thread.dataset.state = thread.dataset.state === 'restricted' ? 'default' : 'restricted';
  }

  if (!event.target.closest('.context-header')) {
    document.querySelectorAll('.header-menu').forEach((item) => item.classList.remove('is-open'));
  }
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') closeDialogs();
});

function openDialog(id) {
  closeDialogs();
  const backdrop = document.getElementById(id);
  backdrop.classList.add('is-open');
  backdrop.setAttribute('aria-hidden','false');
  const first = backdrop.querySelector('input, textarea') ?? backdrop.querySelector('button');
  first?.focus();
}

function closeDialogs() {
  document.querySelectorAll('.dialog-backdrop').forEach((item) => {
    item.classList.remove('is-open');
    item.setAttribute('aria-hidden','true');
  });
}

if (requestedState === 'new-message') openDialog('new-message-dialog');
if (requestedState === 'report') openDialog('report-dialog');

